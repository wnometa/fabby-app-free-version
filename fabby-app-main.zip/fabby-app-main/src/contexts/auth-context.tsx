"use client";

import { createBrowserClient, isSupabaseConfigured } from "@/lib/supabase/client";
import { useRouter } from "next/navigation";
import { ReactNode, createContext, useContext, useEffect, useState } from "react";
import type { AuthChangeEvent, Session, User } from "@supabase/supabase-js";

type AuthContextType = {
  user: User | null;
  session: Session | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  authStateReady: boolean;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const router = useRouter();
  const isConfigured = isSupabaseConfigured();

  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(() => !isConfigured);
  const [authStateReady, setAuthStateReady] = useState<boolean>(() => !isConfigured);

  const updateAuthState = (nextSession: Session | null) => {
    setSession(nextSession);
    setUser(nextSession?.user ?? null);
    setAuthStateReady(true);
  };

  useEffect(() => {
    if (!isConfigured) {
      console.error(
        "Supabase is not configured. Make sure NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY are set."
      );
      return;
    }

    const handleAuthStateEvent = (event: Event) => {
      const customEvent = event as CustomEvent<{ session: Session | null } | undefined>;
      const nextSession = customEvent.detail?.session ?? null;
      updateAuthState(nextSession);
    };

    window.addEventListener("fabby-auth-state", handleAuthStateEvent);

    // Initialize auth state
    const initializeAuth = async () => {
      let subscription: { unsubscribe: () => void } | undefined;

      try {
        const supabase = createBrowserClient();

        // Get initial session
        const { data, error: sessionError } = await supabase.auth.getSession();
        if (sessionError) {
          console.error("Failed to get session:", sessionError);
          throw sessionError;
        }

        updateAuthState(data.session);

        // Listen for auth state changes
        const authState = supabase.auth.onAuthStateChange(async (event: AuthChangeEvent, currentSession: Session | null) => {
          updateAuthState(currentSession);

          // Handle different auth events
          if (event === "SIGNED_IN") {
            console.log("User signed in");
            router.refresh();
          } else if (event === "SIGNED_OUT") {
            console.log("User signed out");
            router.push("/login");
            router.refresh();
          } else if (event === "USER_UPDATED") {
            console.log("User updated");
            router.refresh();
          }
        });

        subscription = authState.data.subscription;

        // Cleanup subscription on unmount
        return () => {
          subscription?.unsubscribe();
        };
      } catch (err) {
        console.error("Failed to initialize auth:", err);
        setAuthStateReady(true);
        return undefined;
      } finally {
        setIsLoading(false);
      }
    };

    const cleanupPromise = initializeAuth();

    return () => {
      window.removeEventListener("fabby-auth-state", handleAuthStateEvent);
      void cleanupPromise.then((cleanupFn) => cleanupFn?.());
    };
  }, [isConfigured, router]);

  const handleSignOut = async () => {
    try {
      const supabase = createBrowserClient();
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      setUser(null);
      setSession(null);
      router.push("/login");
      router.refresh();
    } catch (error) {
      console.error("Sign out error:", error);
      throw error;
    }
  };

  const value: AuthContextType = {
    user,
    session,
    isLoading,
    isAuthenticated: !!session,
    authStateReady,
    signOut: handleSignOut,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
