import { createServerClient } from "@supabase/ssr";
import type { Database } from "@/lib/supabase/database.types";
import { NextResponse, type NextRequest } from "next/server";

// All routes that require authentication
const protectedPaths = [
  "/dashboard",
  "/invoices",
  "/reports",
  "/insights",
  "/goals",
  "/business-vs-personal",
  "/settings",
  "/team",
  "/integrations",
  "/compliance",
  "/incidents",
  "/remediation",
  "/income",
  "/expenses",
  "/business-goals",
  "/ask-fabby",
];

// Routes that should redirect to dashboard if already authenticated
const authRoutes = [
  "/login",
  "/signup",
  "/forgot-password",
  "/reset-password",
  "/verify-email",
];

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  // If Supabase is not configured, allow all requests
  if (!url || !anonKey) {
    return NextResponse.next({
      request: {
        headers: request.headers,
      },
    });
  }

  // Create response to set cookies
  const response = NextResponse.next({
    request: {
      headers: request.headers,
    },
  });

  // Create Supabase client
  const supabase = createServerClient<Database>(url, anonKey, {
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      setAll(cookiesToSet) {
        cookiesToSet.forEach(({ name, value, options }) => {
          response.cookies.set(name, value, options);
        });
      },
    },
  });

  // Get the authenticated user
  const {
    data: { user },
  } = await supabase.auth.getUser();

  // Check if the current path is protected
  const isProtectedRoute = protectedPaths.some(
    (route) => pathname === route || pathname.startsWith(`${route}/`),
  );

  // Check if the current path is an auth route
  const isAuthRoute = authRoutes.some(
    (route) => pathname === route || pathname.startsWith(`${route}/`),
  );

  // CASE 1: User trying to access protected route without authentication
  if (isProtectedRoute && !user) {
    // Redirect to login with the original URL as a return path
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("redirectTo", pathname);
    return NextResponse.redirect(loginUrl);
  }

  // CASE 2: User trying to access auth routes while already authenticated
  if (isAuthRoute && user) {
    // Redirect to dashboard
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  // CASE 3: User accessing the home page while authenticated
  if (pathname === "/" && user) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  // CASE 4: Unauthenticated user accessing home page - show login
  if (pathname === "/" && !user) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  // All other cases - allow the request
  return response;
}

export const config = {
  matcher: [
    // Protected routes
    "/dashboard/:path*",
    "/transactions/:path*",
    "/invoices/:path*",
    "/reports/:path*",
    "/insights/:path*",
    "/cash-flow/:path*",
    "/goals/:path*",
    "/business-vs-personal/:path*",
    "/settings/:path*",
    "/team/:path*",
    "/integrations/:path*",
    "/compliance/:path*",
    "/incidents/:path*",
    "/remediation/:path*",
    "/income/:path*",
    "/expenses/:path*",
    "/business-goals/:path*",
    "/ask-fabby/:path*",
    // Auth routes
    "/login",
    "/signup",
    "/forgot-password",
    "/reset-password",
    "/verify-email",
    "/auth/callback",
    // Home
    "/",
  ],
};
