import Image from "next/image";

export function BrandMark({ className = "" }: { className?: string }) {
  return (
    <Image
      src="/brand/fabby-mark.svg"
      alt="FABBY"
      width={56}
      height={56}
      className={className}
      priority
    />
  );
}

export function BrandWordmark({ className = "" }: { className?: string }) {
  return (
    <Image
      src="/brand/fabby-wordmark.svg"
      alt="FABBY wordmark"
      width={180}
      height={48}
      className={className}
      priority
    />
  );
}

export function BrandLogo({ className = "", compact = false }: { className?: string; compact?: boolean }) {
  if (compact) {
    return <BrandMark className={className} />;
  }

  return (
    <div className="flex items-center gap-3">
      <BrandMark className={className || "h-11 w-11 shrink-0"} />
      <BrandWordmark className="h-6 w-auto" />
    </div>
  );
}

export function BrandFooter({ className = "" }: { className?: string }) {
  return (
    <div className={`text-center text-xs leading-5 text-[#7c5f63] ${className}`}>
      <div>Powered by Wiltecon Technologies</div>
      <div>Founded by Wilson Nometa</div>
    </div>
  );
}
