"use client";

import { useEffect, useMemo, useState } from "react";
import { type LedgerEntry } from "@/lib/financial-ledger";

type Period = "today" | "week" | "month" | "lastMonth" | "quarter" | "lastQuarter" | "year" | "lastYear" | "custom";
type ExpenseFilter = "All" | "Business" | "Personal";
type PaymentMethod = "Bank transfer" | "Credit card" | "Cash" | "Cheque" | "Mobile money" | "Other";

const currency = new Intl.NumberFormat("en-NG", {
  style: "currency",
  currency: "NGN",
  maximumFractionDigits: 0,
});

const PERIOD_LABELS: Record<Period, string> = {
  today: "Today",
  week: "This week",
  month: "This month",
  lastMonth: "Last month",
  quarter: "This quarter",
  lastQuarter: "Last quarter",
  year: "This year",
  lastYear: "Last year",
  custom: "Custom range",
};

const BUSINESS_CATEGORIES = [
  "Software",
  "Marketing",
  "Advertising",
  "Payroll",
  "Contractors",
  "Office supplies",
  "Rent",
  "Utilities",
  "Transportation",
  "Professional services",
  "Equipment",
  "Taxes",
  "Insurance",
  "Other business",
];

const PERSONAL_CATEGORIES = [
  "Groceries",
  "Housing",
  "Transportation",
  "Entertainment",
  "Shopping",
  "Healthcare",
  "Education",
  "Personal subscriptions",
  "Other personal",
];

function formatMoney(value: number) {
  return currency.format(value);
}

function safeDate(value: string | undefined) {
  if (!value) return null;
  const parsed = new Date(`${value}T00:00:00`);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function getDateRange(period: Period, customStart?: string, customEnd?: string) {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  if (period === "custom") {
    return {
      start: customStart ? safeDate(customStart) : null,
      end: customEnd ? new Date(`${customEnd}T23:59:59`) : null,
    };
  }

  if (period === "today") {
    return { start: today, end: new Date(today.getTime() + 86400000 - 1) };
  }

  if (period === "week") {
    const start = new Date(today);
    const diff = (start.getDay() === 0 ? -6 : 1 - start.getDay());
    start.setDate(start.getDate() + diff);
    const end = new Date(start);
    end.setDate(start.getDate() + 6);
    end.setHours(23, 59, 59, 999);
    return { start, end };
  }

  if (period === "month") {
    return {
      start: new Date(now.getFullYear(), now.getMonth(), 1),
      end: new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999),
    };
  }

  if (period === "lastMonth") {
    return {
      start: new Date(now.getFullYear(), now.getMonth() - 1, 1),
      end: new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999),
    };
  }

  if (period === "quarter") {
    const quarterStart = Math.floor(now.getMonth() / 3) * 3;
    return {
      start: new Date(now.getFullYear(), quarterStart, 1),
      end: new Date(now.getFullYear(), quarterStart + 3, 0, 23, 59, 59, 999),
    };
  }

  if (period === "lastQuarter") {
    const quarterStart = Math.floor(now.getMonth() / 3) * 3;
    return {
      start: new Date(now.getFullYear(), quarterStart - 3, 1),
      end: new Date(now.getFullYear(), quarterStart, 0, 23, 59, 59, 999),
    };
  }

  if (period === "year") {
    return {
      start: new Date(now.getFullYear(), 0, 1),
      end: new Date(now.getFullYear(), 11, 31, 23, 59, 59, 999),
    };
  }

  return {
    start: new Date(now.getFullYear() - 1, 0, 1),
    end: new Date(now.getFullYear() - 1, 11, 31, 23, 59, 59, 999),
  };
}

function filterEntriesByRange(entries: LedgerEntry[], period: Period, customStart?: string, customEnd?: string) {
  const range = getDateRange(period, customStart, customEnd);

  return entries.filter((entry) => {
    const entryDate = safeDate(entry.date);
    if (!entryDate) return false;

    const matchesStart = range.start ? entryDate >= range.start : true;
    const matchesEnd = range.end ? entryDate <= range.end : true;
    return matchesStart && matchesEnd;
  });
}

function suggestCategory(description: string): string {
  const text = description.toLowerCase();

  if (text.includes("software") || text.includes("app") || text.includes("subscription") || text.includes("hosting")) return "Software";
  if (text.includes("ad") || text.includes("marketing") || text.includes("campaign")) return "Marketing";
  if (text.includes("payroll") || text.includes("salary") || text.includes("wages")) return "Payroll";
  if (text.includes("contractor") || text.includes("freelance")) return "Contractors";
  if (text.includes("office") || text.includes("supplies")) return "Office supplies";
  if (text.includes("rent") || text.includes("lease") || text.includes("housing")) return "Rent";
  if (text.includes("electric") || text.includes("water") || text.includes("utility")) return "Utilities";
  if (text.includes("transport") || text.includes("fuel") || text.includes("delivery")) return "Transportation";
  if (text.includes("professional") || text.includes("law") || text.includes("account")) return "Professional services";
  if (text.includes("equipment") || text.includes("machine")) return "Equipment";
  if (text.includes("tax")) return "Taxes";
  if (text.includes("insurance")) return "Insurance";

  if (text.includes("grocery") || text.includes("groceries") || text.includes("food")) return "Groceries";
  if (text.includes("entertainment") || text.includes("movie") || text.includes("cinema")) return "Entertainment";
  if (text.includes("shopping") || text.includes("store")) return "Shopping";
  if (text.includes("health") || text.includes("medical") || text.includes("hospital")) return "Healthcare";
  if (text.includes("education") || text.includes("school") || text.includes("course")) return "Education";

  return "";
}

function suggestClassification(description: string, category: string): "Business" | "Personal" {
  const text = description.toLowerCase();
  const businessKeywords = ["invoice", "client", "business", "marketing", "advertising", "payroll", "contractor", "equipment", "software"];
  const personalKeywords = ["personal", "family", "home", "groceries", "shopping", "entertainment", "healthcare"];

  const businessScore = businessKeywords.filter((keyword) => text.includes(keyword)).length;
  const personalScore = personalKeywords.filter((keyword) => text.includes(keyword)).length;

  if (businessScore > personalScore) return "Business";
  if (personalScore > businessScore) return "Personal";

  return BUSINESS_CATEGORIES.includes(category) ? "Business" : "Personal";
}

function getCategoryBreakdown(entries: LedgerEntry[]) {
  const totals = new Map<string, { amount: number; count: number }>();
  for (const entry of entries) {
    const current = totals.get(entry.category) ?? { amount: 0, count: 0 };
    current.amount += Number(entry.amount ?? 0);
    current.count += 1;
    totals.set(entry.category, current);
  }

  const total = Array.from(totals.values()).reduce((sum, item) => sum + item.amount, 0);
  return Array.from(totals.entries())
    .map(([category, value]) => ({
      category,
      amount: value.amount,
      count: value.count,
      percent: total === 0 ? 0 : (value.amount / total) * 100,
    }))
    .sort((a, b) => b.amount - a.amount);
}

export function ExpensesModule({
  entries: initialEntries,
  onAddEntry,
  onUpdateEntry,
  onDeleteEntry,
  userId,
}: {
  entries: LedgerEntry[];
  onAddEntry?: (entry: LedgerEntry) => Promise<boolean>;
  onUpdateEntry?: (entryId: string, updates: Partial<LedgerEntry>) => Promise<boolean>;
  onDeleteEntry?: (entryId: string) => Promise<boolean>;
  userId?: string;
}) {
  const [entries, setEntries] = useState<LedgerEntry[]>(initialEntries);
  const [period, setPeriod] = useState<Period>("month");
  const [customStart, setCustomStart] = useState("");
  const [customEnd, setCustomEnd] = useState("");
  const [filterType, setFilterType] = useState<ExpenseFilter>("All");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [paymentMethodFilter, setPaymentMethodFilter] = useState("All");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedExpense, setSelectedExpense] = useState<LedgerEntry | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [amountInput, setAmountInput] = useState("");
  const [categoryInput, setCategoryInput] = useState("");
  const [dateInput, setDateInput] = useState("");
  const [merchantInput, setMerchantInput] = useState("");
  const [paymentMethodInput, setPaymentMethodInput] = useState<PaymentMethod>("Bank transfer");
  const [descriptionInput, setDescriptionInput] = useState("");
  const [moneyTypeInput, setMoneyTypeInput] = useState<"Business" | "Personal">("Business");
  const [notesInput, setNotesInput] = useState("");
  const [referenceInput, setReferenceInput] = useState("");
  const [suggestionCategory, setSuggestionCategory] = useState("");
  const [suggestionClassification, setSuggestionClassification] = useState<"Business" | "Personal">("Business");
  const [aiQuestion, setAiQuestion] = useState("");
  const [aiAnswer, setAiAnswer] = useState("");

  const filteredEntries = useMemo(() => {
    let result = filterEntriesByRange(entries, period, customStart || undefined, customEnd || undefined);

    if (filterType !== "All") {
      result = result.filter((entry) => entry.moneyType === filterType);
    }

    if (categoryFilter !== "All") {
      result = result.filter((entry) => entry.category === categoryFilter);
    }

    if (paymentMethodFilter !== "All") {
      result = result.filter((entry) => entry.paymentMethod === paymentMethodFilter);
    }

    if (searchTerm) {
      const lowerSearch = searchTerm.toLowerCase();
      result = result.filter((entry) =>
        entry.description.toLowerCase().includes(lowerSearch) ||
        entry.category.toLowerCase().includes(lowerSearch) ||
        (entry.vendor ?? "").toLowerCase().includes(lowerSearch) ||
        (entry.reference ?? "").toLowerCase().includes(lowerSearch),
      );
    }

    return result.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [entries, period, customStart, customEnd, filterType, categoryFilter, paymentMethodFilter, searchTerm]);

  const totalExpenses = useMemo(() => filteredEntries.reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0), [filteredEntries]);
  const businessExpenses = useMemo(() => filteredEntries.filter((e) => e.moneyType === "Business").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0), [filteredEntries]);
  const personalExpenses = useMemo(() => filteredEntries.filter((e) => e.moneyType === "Personal").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0), [filteredEntries]);
  const averageExpense = filteredEntries.length ? totalExpenses / filteredEntries.length : 0;
  const categoryBreakdown = useMemo(() => getCategoryBreakdown(filteredEntries), [filteredEntries]);

  const allPaymentMethods = useMemo(() => {
    const methods = new Set(entries.map((e) => e.paymentMethod).filter(Boolean));
    return Array.from(methods) as PaymentMethod[];
  }, [entries]);

  const allCategories = useMemo(() => {
    const categories = new Set(entries.map((e) => e.category));
    return Array.from(categories).sort();
  }, [entries]);

  const saveExpense = async () => {
    if (!amountInput || !categoryInput || !dateInput || !descriptionInput) {
      return;
    }
    if (!userId) {
      console.error("Expense save blocked: no authenticated user.");
      return;
    }

    const newEntry: LedgerEntry = {
      id: crypto.randomUUID(),
      userId,
      type: "Expense",
      amount: Number(amountInput),
      category: categoryInput,
      date: dateInput,
      description: descriptionInput,
      vendor: merchantInput,
      paymentMethod: paymentMethodInput,
      notes: notesInput,
      reference: referenceInput,
      moneyType: moneyTypeInput,
      status: "Recorded",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    // Call parent callback to persist the entry
    if (onAddEntry) {
      const didAdd = await onAddEntry(newEntry);
      if (didAdd) {
        setEntries((current) => [newEntry, ...current]);
      }
    } else {
      // Fallback if callback not provided
      setEntries((current) => [newEntry, ...current]);
    }

    setAmountInput("");
    setCategoryInput("");
    setDateInput("");
    setMerchantInput("");
    setPaymentMethodInput("Bank transfer");
    setDescriptionInput("");
    setMoneyTypeInput("Business");
    setNotesInput("");
    setReferenceInput("");
    setSuggestionCategory("");
    setSuggestionClassification("Business");
    setShowAddForm(false);
  };

  const updateExpense = async (id: string, updates: Partial<LedgerEntry>) => {
    // Call parent callback to update the entry
    if (onUpdateEntry) {
      const didUpdate = await onUpdateEntry(id, updates);
      if (didUpdate) {
        setEntries((current) =>
          current.map((entry) => (entry.id === id ? { ...entry, ...updates, updatedAt: new Date().toISOString() } : entry)),
        );

        if (selectedExpense?.id === id) {
          setSelectedExpense({ ...selectedExpense, ...updates, updatedAt: new Date().toISOString() });
        }
      }
    } else {
      // Fallback if callback not provided
      setEntries((current) =>
        current.map((entry) => (entry.id === id ? { ...entry, ...updates, updatedAt: new Date().toISOString() } : entry)),
      );

      if (selectedExpense?.id === id) {
        setSelectedExpense({ ...selectedExpense, ...updates, updatedAt: new Date().toISOString() });
      }
    }
  };

  const deleteExpense = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this expense?")) return;

    // Call parent callback to delete the entry
    if (onDeleteEntry) {
      const didDelete = await onDeleteEntry(id);
      if (didDelete) {
        setEntries((current) => current.filter((entry) => entry.id !== id));
        setSelectedExpense(null);
      }
    } else {
      // Fallback if callback not provided
      setEntries((current) => current.filter((entry) => entry.id !== id));
      setSelectedExpense(null);
    }
  };

  const askAi = () => {
    const cleaned = aiQuestion.trim().toLowerCase();
    if (!cleaned) return;

    if (cleaned.includes("where am i spending") || cleaned.includes("biggest expenses") || cleaned.includes("spending the most")) {
      const topCategories = categoryBreakdown.slice(0, 3);
      const summary = topCategories.map((cat) => `${cat.category} (${formatMoney(cat.amount)})`).join(", ");
      setAiAnswer(topCategories.length ? `Your biggest expenses are: ${summary}.` : "No expense data available for this period.");
      return;
    }

    if (cleaned.includes("business expenses")) {
      setAiAnswer(`Your total business expenses for this period are ${formatMoney(businessExpenses)}.`);
      return;
    }

    if (cleaned.includes("personal expenses")) {
      setAiAnswer(`Your total personal expenses for this period are ${formatMoney(personalExpenses)}.`);
      return;
    }

    if (cleaned.includes("how much did i spend")) {
      if (cleaned.includes("software")) {
        const softwareTotal = filteredEntries.filter((e) => e.category === "Software").reduce((sum, e) => sum + Number(e.amount ?? 0), 0);
        setAiAnswer(`You spent ${formatMoney(softwareTotal)} on software this period.`);
        return;
      }
      setAiAnswer(`Your total expenses for this period are ${formatMoney(totalExpenses)}.`);
      return;
    }

    if (cleaned.includes("reduced") || cleaned.includes("reduce") || cleaned.includes("cut spending")) {
      const topCategory = categoryBreakdown[0];
      if (topCategory) {
        setAiAnswer(`Your largest expense category is ${topCategory.category} at ${formatMoney(topCategory.amount)}. Consider reviewing expenses in this category to identify savings opportunities.`);
        return;
      }
      setAiAnswer("You have no expenses recorded yet to analyze.");
      return;
    }

    if (cleaned.includes("categories growing") || cleaned.includes("increased")) {
      const categories = categoryBreakdown.slice(0, 2);
      if (categories.length > 0) {
        setAiAnswer(`Your fastest-growing expense categories are ${categories.map((c) => c.category).join(", ")}.`);
        return;
      }
      setAiAnswer("No expense data available to analyze trends.");
      return;
    }

    if (cleaned.includes("spending too much")) {
      const hasHighExpenses = totalExpenses > 500000;
      setAiAnswer(hasHighExpenses ? "Your expenses are relatively high. Review the largest categories to find savings." : "Your spending appears reasonable for this period.");
      return;
    }

    setAiAnswer("FABBY can analyze your real expenses. Try asking: 'Where am I spending the most?' or 'What are my biggest business expenses?'");
  };

  const handleDescriptionInput = (value: string) => {
    setDescriptionInput(value);
    const suggested = suggestCategory(value);
    if (suggested) {
      setSuggestionCategory(suggested);
      setSuggestionClassification(suggestClassification(value, suggested));
    }
  };

  const acceptSuggestion = () => {
    if (suggestionCategory) {
      setCategoryInput(suggestionCategory);
      setMoneyTypeInput(suggestionClassification);
      setSuggestionCategory("");
    }
  };

  return (
    <div className="space-y-6">
      <div className="fabby-card rounded-[30px] p-5 md:p-6">
        <div className="mb-5 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Expenses</div>
            <h2 className="mt-2 text-3xl font-semibold text-[#2d1d1d]">Track your spending</h2>
          </div>
          <button
            type="button"
            onClick={() => setShowAddForm(true)}
            className="rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white"
          >
            + Add expense
          </button>
        </div>

        <div className="flex flex-wrap gap-2">
          {(["today", "week", "month", "lastMonth", "quarter", "lastQuarter", "year", "lastYear", "custom"] as Period[]).map((option) => (
            <button
              key={option}
              type="button"
              onClick={() => setPeriod(option)}
              className={`rounded-full px-3 py-1.5 text-xs font-medium ${
                period === option ? "bg-[#2d1d1d] text-white" : "border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] text-[#4b2d37]"
              }`}
            >
              {PERIOD_LABELS[option]}
            </button>
          ))}
        </div>

        {period === "custom" && (
          <div className="mt-4 grid gap-3 md:grid-cols-3">
            <input type="date" value={customStart} onChange={(e) => setCustomStart(e.target.value)} className="input-shell" />
            <input type="date" value={customEnd} onChange={(e) => setCustomEnd(e.target.value)} className="input-shell" />
            <button type="button" onClick={() => setPeriod("month")} className="rounded-full border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] px-3 py-2 text-sm font-medium text-[#4b2d37]">
              Reset range
            </button>
          </div>
        )}

        <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {[
            { label: "Total expenses", value: formatMoney(totalExpenses) },
            { label: "Business expenses", value: formatMoney(businessExpenses) },
            { label: "Personal expenses", value: formatMoney(personalExpenses) },
            { label: "Average expense", value: formatMoney(averageExpense) },
          ].map((card) => (
            <div key={card.label} className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
              <div className="text-[10px] uppercase tracking-[0.14em] text-[#7a5f60]">{card.label}</div>
              <div className="mt-3 text-xl font-semibold text-[#2d1d1d]">{card.value}</div>
            </div>
          ))}
        </div>
      </div>

      {showAddForm && (
        <div className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 flex items-center justify-between">
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">New expense</div>
            <button type="button" onClick={() => setShowAddForm(false)} className="text-sm font-medium text-[#8b5961]">
              Close
            </button>
          </div>

          <div className="space-y-4">
            <div className="grid gap-3 md:grid-cols-2">
              <input
                type="number"
                value={amountInput}
                onChange={(e) => setAmountInput(e.target.value)}
                placeholder="Amount"
                className="input-shell"
              />
              <select value={paymentMethodInput} onChange={(e) => setPaymentMethodInput(e.target.value as PaymentMethod)} className="input-shell">
                <option value="Bank transfer">Bank transfer</option>
                <option value="Credit card">Credit card</option>
                <option value="Cash">Cash</option>
                <option value="Cheque">Cheque</option>
                <option value="Mobile money">Mobile money</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              <input type="date" value={dateInput} onChange={(e) => setDateInput(e.target.value)} className="input-shell" />
              <input
                type="text"
                value={merchantInput}
                onChange={(e) => setMerchantInput(e.target.value)}
                placeholder="Merchant / Payee"
                className="input-shell"
              />
            </div>

            <textarea
              value={descriptionInput}
              onChange={(e) => handleDescriptionInput(e.target.value)}
              placeholder="Description (FABBY will suggest category)"
              className="input-shell min-h-[80px] resize-none"
            />

            {suggestionCategory && (
              <div className="rounded-[18px] border border-[rgba(45,29,29,0.08)] bg-[#fffcfb] p-4">
                <div className="text-sm font-medium text-[#2d1d1d]">FABBY suggests:</div>
                <div className="mt-2 flex flex-wrap gap-2">
                  <div className="rounded-full bg-[#f6e4e3] px-3 py-1.5 text-sm text-[#4b2d37]">
                    Category: {suggestionCategory}
                  </div>
                  <div className="rounded-full bg-[#f6e4e3] px-3 py-1.5 text-sm text-[#4b2d37]">
                    Type: {suggestionClassification}
                  </div>
                </div>
                <div className="mt-3 flex gap-2">
                  <button type="button" onClick={acceptSuggestion} className="rounded-full bg-[#2d1d1d] px-3 py-1.5 text-sm font-medium text-white">
                    Accept
                  </button>
                  <button type="button" onClick={() => setSuggestionCategory("")} className="rounded-full border border-[rgba(109,69,71,0.12)] px-3 py-1.5 text-sm font-medium text-[#4b2d37]">
                    Change
                  </button>
                </div>
              </div>
            )}

            <div className="grid gap-3 md:grid-cols-2">
              <select value={categoryInput} onChange={(e) => setCategoryInput(e.target.value)} className="input-shell">
                <option value="">Select category</option>
                <optgroup label="Business">
                  {BUSINESS_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </optgroup>
                <optgroup label="Personal">
                  {PERSONAL_CATEGORIES.map((cat) => (
                    <option key={cat} value={cat}>
                      {cat}
                    </option>
                  ))}
                </optgroup>
              </select>

              <div className="flex gap-2">
                <label className="flex flex-1 items-center rounded-full border border-[rgba(109,69,71,0.12)] px-3 py-2 cursor-pointer">
                  <input
                    type="radio"
                    name="moneyType"
                    value="Business"
                    checked={moneyTypeInput === "Business"}
                    onChange={() => setMoneyTypeInput("Business")}
                    className="mr-2"
                  />
                  <span className="text-sm font-medium text-[#4b2d37]">Business</span>
                </label>
                <label className="flex flex-1 items-center rounded-full border border-[rgba(109,69,71,0.12)] px-3 py-2 cursor-pointer">
                  <input
                    type="radio"
                    name="moneyType"
                    value="Personal"
                    checked={moneyTypeInput === "Personal"}
                    onChange={() => setMoneyTypeInput("Personal")}
                    className="mr-2"
                  />
                  <span className="text-sm font-medium text-[#4b2d37]">Personal</span>
                </label>
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-2">
              <input
                type="text"
                value={referenceInput}
                onChange={(e) => setReferenceInput(e.target.value)}
                placeholder="Reference / Receipt number (optional)"
                className="input-shell"
              />
              <input
                type="text"
                value={notesInput}
                onChange={(e) => setNotesInput(e.target.value)}
                placeholder="Notes (optional)"
                className="input-shell"
              />
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="rounded-full border border-[rgba(109,69,71,0.12)] px-4 py-2 text-sm font-medium text-[#4b2d37]"
              >
                Cancel
              </button>
              <button type="button" onClick={saveExpense} className="rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white">
                Save expense
              </button>
            </div>
          </div>
        </div>
      )}

      {filteredEntries.length === 0 ? (
        <div className="fabby-card rounded-[30px] p-8 text-center">
          <div className="text-3xl font-semibold text-[#2d1d1d]">No expenses recorded yet</div>
          <p className="mt-3 text-[#5a4547]">Start tracking your spending to understand where your money is going.</p>
          <button
            type="button"
            onClick={() => setShowAddForm(true)}
            className="mt-6 rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white"
          >
            + Add expense
          </button>
        </div>
      ) : (
        <>
          <div className="fabby-card rounded-[30px] p-5 md:p-6">
            <div className="mb-4 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Filters</div>
              <div className="flex flex-wrap gap-2">
                {(["All", "Business", "Personal"] as ExpenseFilter[]).map((option) => (
                  <button
                    key={option}
                    type="button"
                    className={`rounded-full px-3 py-1.5 text-xs font-medium ${
                      filterType === option ? "bg-[#2d1d1d] text-white" : "border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] text-[#4b2d37]"
                    }`}
                    onClick={() => setFilterType(option)}
                  >
                    {option}
                  </button>
                ))}
              </div>
            </div>

            <div className="grid gap-3 md:grid-cols-3">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by merchant, description, or reference"
                className="input-shell"
              />
              <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)} className="input-shell">
                <option value="All">All categories</option>
                {allCategories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
              <select value={paymentMethodFilter} onChange={(e) => setPaymentMethodFilter(e.target.value)} className="input-shell">
                <option value="All">All payment methods</option>
                {allPaymentMethods.map((method) => (
                  <option key={method} value={method}>
                    {method}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Expense breakdown by category</div>
              <div className="space-y-3">
                {categoryBreakdown.length ? (
                  categoryBreakdown.map((item) => (
                    <div key={item.category} className="rounded-[18px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-3">
                      <div className="flex items-center justify-between text-sm text-[#422d30]">
                        <span className="font-medium">{item.category}</span>
                        <span className="font-semibold">{formatMoney(item.amount)}</span>
                      </div>
                      <div className="mt-2 h-2.5 rounded-full bg-[#f6e7e5]">
                        <div className="h-full rounded-full bg-[#d98e95]" style={{ width: `${Math.min(item.percent, 100)}%` }} />
                      </div>
                      <div className="mt-2 flex items-center justify-between text-[11px] uppercase tracking-[0.12em] text-[#7a5f60]">
                        <span>{item.count} tx</span>
                        <span>{item.percent.toFixed(1)}%</span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-sm text-[#5e4748]">No category data available.</div>
                )}
              </div>
            </div>

            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Expense AI analyst</div>
              <div className="space-y-3">
                <textarea
                  value={aiQuestion}
                  onChange={(e) => setAiQuestion(e.target.value)}
                  placeholder="Ask: Where am I spending the most? What are my biggest business expenses?"
                  className="input-shell min-h-[100px] resize-none"
                />
                <button type="button" onClick={askAi} className="w-full rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white">
                  Ask FABBY
                </button>
              </div>
              {aiAnswer ? (
                <div className="mt-4 rounded-[20px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 text-sm leading-7 text-[#422b2c]">
                  {aiAnswer}
                </div>
              ) : null}
            </div>
          </div>

          <div className="fabby-card rounded-[30px] p-5">
            <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Expense list ({filteredEntries.length})</div>

            <div className="overflow-x-auto rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8]">
              <table className="min-w-full text-left text-sm">
                <thead className="bg-[#fdf1ee] text-[#584245]">
                  <tr>
                    <th className="px-4 py-3">Date</th>
                    <th className="px-4 py-3">Description</th>
                    <th className="px-4 py-3">Merchant</th>
                    <th className="px-4 py-3">Category</th>
                    <th className="px-4 py-3">Type</th>
                    <th className="px-4 py-3">Method</th>
                    <th className="px-4 py-3">Amount</th>
                    <th className="px-4 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredEntries.map((entry) => (
                    <tr key={entry.id} className="border-t border-[rgba(109,69,71,0.06)]">
                      <td className="px-4 py-3">{entry.date}</td>
                      <td className="px-4 py-3 font-medium text-[#2d1d1d]">{entry.description}</td>
                      <td className="px-4 py-3">{entry.vendor || "-"}</td>
                      <td className="px-4 py-3">{entry.category}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${entry.moneyType === "Business" ? "bg-[#dfeef7] text-[#294d74]" : "bg-[#fce5d9] text-[#7d4d2f]"}`}>
                          {entry.moneyType}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-xs text-[#5e4748]">{entry.paymentMethod || "-"}</td>
                      <td className="px-4 py-3 font-semibold text-[#3a2c2d]">{formatMoney(entry.amount)}</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-2">
                          <button
                            type="button"
                            onClick={() => setSelectedExpense(entry)}
                            className="text-xs font-medium text-[#4b2d37]"
                          >
                            View
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteExpense(entry.id)}
                            className="text-xs font-medium text-[#9c4d4d]"
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}

      {selectedExpense && (
        <div className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 flex items-center justify-between">
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Expense details</div>
            <button type="button" onClick={() => setSelectedExpense(null)} className="text-sm font-medium text-[#8b5961]">
              Close
            </button>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            {[
              { label: "Amount", value: formatMoney(selectedExpense.amount) },
              { label: "Date", value: selectedExpense.date },
              { label: "Merchant", value: selectedExpense.vendor || "-" },
              { label: "Category", value: selectedExpense.category },
              { label: "Type", value: selectedExpense.moneyType },
              { label: "Payment method", value: selectedExpense.paymentMethod || "-" },
              { label: "Reference", value: selectedExpense.reference || "-" },
              { label: "Status", value: selectedExpense.status || "Recorded" },
              { label: "Description", value: selectedExpense.description },
              { label: "Notes", value: selectedExpense.notes || "-" },
              { label: "Created", value: new Date(selectedExpense.createdAt).toLocaleString() },
              { label: "Updated", value: new Date(selectedExpense.updatedAt).toLocaleString() },
            ].map((item) => (
              <div key={item.label} className="rounded-[18px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
                <div className="text-xs uppercase tracking-[0.12em] text-[#7a5f60]">{item.label}</div>
                <div className="mt-2 text-sm font-medium text-[#2d1d1d]">{item.value}</div>
              </div>
            ))}
          </div>

          <div className="mt-4 flex gap-2">
            <button
              type="button"
              onClick={() => {
                const newClassification = selectedExpense.moneyType === "Business" ? "Personal" : "Business";
                updateExpense(selectedExpense.id, { moneyType: newClassification });
              }}
              className="rounded-full border border-[rgba(109,69,71,0.12)] px-4 py-2 text-sm font-medium text-[#4b2d37]"
            >
              Change classification
            </button>
            <button
              type="button"
              onClick={() => deleteExpense(selectedExpense.id)}
              className="rounded-full bg-[#d98e95] px-4 py-2 text-sm font-medium text-white"
            >
              Delete
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
