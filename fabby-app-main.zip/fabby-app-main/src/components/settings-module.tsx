"use client";

import { useEffect, useMemo, useState } from "react";
import { useAuth } from "@/contexts/auth-context";
import {
  addLearnedPreference,
  clearLearnedPreferences,
  readSettings,
  restoreDefaultSettings,
  saveSettings,
  type LearnedPreference,
  type SettingsState,
} from "@/lib/settings";

const currencyOptions = ["NGN", "USD", "GBP", "EUR", "KES", "GHS"];
const countryOptions = ["Nigeria", "United Kingdom", "United States", "Ghana", "Kenya", "South Africa", "Other"];
const timezoneOptions = ["Africa/Lagos", "UTC", "Europe/London", "America/New_York", "Africa/Accra", "Africa/Nairobi"];
const frequencies = ["Immediate", "Daily", "Weekly", "Monthly", "Off"];
const reportPeriods = ["week", "month", "lastMonth", "quarter", "lastQuarter", "year", "lastYear"];
const reportTypes = ["profit-loss", "income", "expense", "cash-flow", "balance", "performance"];

function clamp(v: string, max = 140) {
  return v.slice(0, max);
}

function Toggle({ enabled, onChange, label }: { enabled: boolean; onChange: (value: boolean) => void; label: string }) {
  return (
    <button
      type="button"
      aria-label={label}
      onClick={() => onChange(!enabled)}
      className={`flex h-7 w-12 items-center rounded-full border transition ${enabled ? "border-[#1f2937] bg-[#1f2937]" : "border-[#d7dfe8] bg-[#eef2f7]"}`}
    >
      <span className={`ml-1 h-5 w-5 rounded-full bg-white shadow-sm transition ${enabled ? "translate-x-5" : "translate-x-0"}`} />
    </button>
  );
}

export function SettingsModule() {
  const { signOut } = useAuth();
  const [settings, setSettings] = useState<SettingsState>(() => readSettings());
  const [search, setSearch] = useState("");
  const [newPreference, setNewPreference] = useState({ phrase: "", category: "", classification: "Business" as LearnedPreference["classification"] });

  useEffect(() => {
    saveSettings(settings);
  }, [settings]);

  const visibleSections = useMemo(() => {
    const lower = search.trim().toLowerCase();

    const sections = [
      { id: "account", title: "Account" },
      { id: "financial", title: "Financial preferences" },
      { id: "business-personal", title: "Business vs personal" },
      { id: "ai", title: "AI preferences" },
      { id: "learned", title: "Learned preferences" },
      { id: "notifications", title: "Notifications" },
      { id: "reporting", title: "Reporting preferences" },
      { id: "security", title: "Security" },
      { id: "privacy", title: "Privacy" },
      { id: "data", title: "Data management" },
      { id: "appearance", title: "Appearance" },
      { id: "integrations", title: "Integrations" },
    ];

    if (!lower) return sections;
    return sections.filter(({ title }) => title.toLowerCase().includes(lower) || lower.includes(title.toLowerCase().split(" ")[0] || ""));
  }, [search]);

  const updateProfile = (field: keyof SettingsState["profile"], value: string) => {
    setSettings((current) => ({
      ...current,
      profile: {
        ...current.profile,
        [field]: value,
      },
    }));
  };

  const updateFinancial = (field: keyof SettingsState["financial"], value: string) => {
    setSettings((current) => ({
      ...current,
      financial: {
        ...current.financial,
        [field]: value,
      },
    }));
  };

  const updateAi = (field: keyof SettingsState["ai"], value: boolean) => {
    setSettings((current) => ({
      ...current,
      ai: {
        ...current.ai,
        [field]: value,
      },
    }));
  };

  const updateNotifications = (field: keyof SettingsState["notifications"], value: string) => {
    setSettings((current) => ({
      ...current,
      notifications: {
        ...current.notifications,
        [field]: value,
      },
    }));
  };

  const updateReporting = (field: keyof SettingsState["reporting"], value: string | boolean) => {
    setSettings((current) => ({
      ...current,
      reporting: {
        ...current.reporting,
        [field]: value,
      },
    }));
  };

  const updatePrivacy = (field: keyof SettingsState["privacy"], value: boolean) => {
    setSettings((current) => ({
      ...current,
      privacy: {
        ...current.privacy,
        [field]: value,
      },
    }));
  };

  const updateAppearance = (field: keyof SettingsState["appearance"], value: string) => {
    setSettings((current) => ({
      ...current,
      appearance: {
        ...current.appearance,
        [field]: value,
      },
    }));
  };

  const updateIntegrations = (field: keyof SettingsState["integrations"], value: string | SettingsState["integrations"]["connectedServices"]) => {
    setSettings((current) => ({
      ...current,
      integrations: {
        ...current.integrations,
        ...(typeof value === "object"
          ? { connectedServices: value as SettingsState["integrations"]["connectedServices"] }
          : { [field]: value }),
      },
    }));
  };

  const handleClearLearned = () => {
    if (!window.confirm("Clear all learned preferences? This only removes the suggestion history, not your financial records.")) return;
    const next = clearLearnedPreferences();
    setSettings(next);
  };

  const handleRestoreDefaults = () => {
    if (!window.confirm("Restore default preferences? This will not delete your financial data.")) return;
    const next = restoreDefaultSettings();
    setSettings(next);
  };

  const handleAddLearnedPreference = () => {
    const trimmed = newPreference.phrase.trim();
    if (!trimmed) return;
    const next = addLearnedPreference(trimmed, newPreference.category || "General", newPreference.classification);
    setSettings(next);
    setNewPreference({ phrase: "", category: "", classification: "Business" });
  };

  const handleDeletePreference = (id: string) => {
    setSettings((current) => ({
      ...current,
      learnedPreferences: current.learnedPreferences.filter((item) => item.id !== id),
    }));
  };

  const handleTogglePreferenceEnabled = (id: string) => {
    setSettings((current) => ({
      ...current,
      learnedPreferences: current.learnedPreferences.map((item) => item.id === id ? { ...item, enabled: !item.enabled } : item),
    }));
  };

  const handleUpdateLearnedPreference = (id: string, patch: Partial<LearnedPreference>) => {
    setSettings((current) => ({
      ...current,
      learnedPreferences: current.learnedPreferences.map((item) => (item.id === id ? { ...item, ...patch } : item)),
    }));
  };

  return (
    <div className="space-y-6">
      <div className="fabby-card rounded-[30px] p-5 md:p-6">
        <div className="mb-5 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Settings</div>
            <h2 className="mt-2 text-3xl font-semibold text-[#2d1d1d]">FABBY control center</h2>
          </div>
          <div className="flex w-full max-w-md items-center gap-2 rounded-full border border-[rgba(109,69,71,0.1)] bg-[#fffaf8] px-3 py-2">
            <span className="text-lg text-[#7a5f60]">⌕</span>
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="Search settings..."
              className="w-full bg-transparent text-sm outline-none placeholder:text-[#876d71]"
            />
          </div>
        </div>

        <div className="flex flex-wrap gap-3">
          <button type="button" onClick={handleRestoreDefaults} className="rounded-full bg-[#1f2937] px-4 py-2 text-sm font-medium text-white">
            Restore default preferences
          </button>
          <button type="button" onClick={handleClearLearned} className="rounded-full border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] px-4 py-2 text-sm font-medium text-[#3f2d2f]">
            Clear all learned preferences
          </button>
        </div>
      </div>

      {!visibleSections.length && (
        <div className="fabby-card rounded-[30px] p-5 text-sm text-[#5b3e40]">No matching settings for “{search}”.</div>
      )}

      {visibleSections.includes({ id: "account", title: "Account" }) && (
        <div id="account" className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Account</div>
          <div className="grid gap-4 md:grid-cols-2">
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Name</span>
              <input value={settings.profile.name} onChange={(event) => updateProfile("name", event.target.value)} className="input-shell" />
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Email display</span>
              <input value={settings.profile.email} onChange={(event) => updateProfile("email", event.target.value)} className="input-shell" />
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Business name</span>
              <input value={settings.profile.businessName} onChange={(event) => updateProfile("businessName", event.target.value)} className="input-shell" />
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Phone number</span>
              <input value={settings.profile.phone} onChange={(event) => updateProfile("phone", clamp(event.target.value))} className="input-shell" />
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Country</span>
              <select value={settings.profile.country} onChange={(event) => updateProfile("country", event.target.value)} className="input-shell">
                {countryOptions.map((option) => (
                  <option key={option} value={option}>{option}</option>
                ))}
              </select>
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Currency</span>
              <select value={settings.profile.currency} onChange={(event) => updateProfile("currency", event.target.value)} className="input-shell">
                {currencyOptions.map((option) => (
                  <option key={option} value={option}>{option}</option>
                ))}
              </select>
            </label>
            <label className="space-y-2 text-sm text-[#563d3f] md:col-span-2">
              <span>Timezone</span>
              <select value={settings.profile.timezone} onChange={(event) => updateProfile("timezone", event.target.value)} className="input-shell">
                {timezoneOptions.map((option) => (
                  <option key={option} value={option}>{option}</option>
                ))}
              </select>
            </label>
          </div>
        </div>
      )}

      {visibleSections.includes({ id: "financial", title: "Financial preferences" }) && (
        <div id="financial" className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Financial preferences</div>
          <div className="grid gap-4 md:grid-cols-2">
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Default currency</span>
              <select value={settings.financial.defaultCurrency} onChange={(event) => updateFinancial("defaultCurrency", event.target.value)} className="input-shell">
                {currencyOptions.map((option) => (
                  <option key={option} value={option}>{option}</option>
                ))}
              </select>
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Default transaction type</span>
              <select value={settings.financial.defaultTransactionType} onChange={(event) => updateFinancial("defaultTransactionType", event.target.value as SettingsState["financial"]["defaultTransactionType"])} className="input-shell">
                <option value="Income">Income</option>
                <option value="Expense">Expense</option>
              </select>
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Default classification</span>
              <select value={settings.financial.defaultClassification} onChange={(event) => updateFinancial("defaultClassification", event.target.value as SettingsState["financial"]["defaultClassification"])} className="input-shell">
                <option value="Business">Business</option>
                <option value="Personal">Personal</option>
                <option value="Ask every time">Ask every time</option>
              </select>
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Default expense category</span>
              <input value={settings.financial.defaultExpenseCategory} onChange={(event) => updateFinancial("defaultExpenseCategory", event.target.value)} className="input-shell" />
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Default income category</span>
              <input value={settings.financial.defaultIncomeCategory} onChange={(event) => updateFinancial("defaultIncomeCategory", event.target.value)} className="input-shell" />
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Start of financial year</span>
              <input type="date" value={settings.financial.startOfFinancialYear} onChange={(event) => updateFinancial("startOfFinancialYear", event.target.value)} className="input-shell" />
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Date format</span>
              <select value={settings.financial.dateFormat} onChange={(event) => updateFinancial("dateFormat", event.target.value)} className="input-shell">
                <option value="DD/MM/YYYY">DD/MM/YYYY</option>
                <option value="MM/DD/YYYY">MM/DD/YYYY</option>
                <option value="YYYY-MM-DD">YYYY-MM-DD</option>
              </select>
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Number format</span>
              <select value={settings.financial.numberFormat} onChange={(event) => updateFinancial("numberFormat", event.target.value)} className="input-shell">
                <option value="1,234.56">1,234.56</option>
                <option value="1 234,56">1 234,56</option>
                <option value="1,234">1,234</option>
              </select>
            </label>
          </div>
        </div>
      )}

      {visibleSections.includes({ id: "business-personal", title: "Business vs personal" }) && (
        <div id="business-personal" className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Business vs personal</div>
          <div className="space-y-4">
            <div className="flex items-center justify-between rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
              <div>
                <div className="text-base font-medium text-[#2d1d1d]">Track personal expenses</div>
                <div className="mt-1 text-sm text-[#5b3e40]">When turned off, existing personal records remain saved, but new personal tracking is paused.</div>
              </div>
              <Toggle enabled={settings.businessVsPersonal.trackPersonalExpenses} onChange={(value) => setSettings((current) => ({ ...current, businessVsPersonal: { ...current.businessVsPersonal, trackPersonalExpenses: value } }))} label="Track personal expenses" />
            </div>

            <label className="block space-y-2 text-sm text-[#563d3f]">
              <span>Default transaction classification</span>
              <select value={settings.businessVsPersonal.defaultClassification} onChange={(event) => setSettings((current) => ({ ...current, businessVsPersonal: { ...current.businessVsPersonal, defaultClassification: event.target.value as SettingsState["financial"]["defaultClassification"] } }))} className="input-shell">
                <option value="Business">Business</option>
                <option value="Personal">Personal</option>
                <option value="Ask every time">Ask every time</option>
              </select>
            </label>
          </div>
        </div>
      )}

      {visibleSections.includes({ id: "ai", title: "AI preferences" }) && (
        <div id="ai" className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">AI preferences</div>
          <div className="grid gap-4 md:grid-cols-2">
            {[
              ["AI confirmation before save", "confirmationBeforeSave"],
              ["AI expense categorization", "expenseCategorization"],
              ["AI income categorization", "incomeCategorization"],
              ["AI financial insights", "financialInsights"],
              ["AI cash-flow analysis", "cashFlowAnalysis"],
              ["AI anomaly detection", "anomalyDetection"],
              ["AI receipt analysis", "receiptAnalysis"],
              ["AI proactive recommendations", "proactiveRecommendations"],
            ].map(([label, key]) => (
              <div key={key} className="flex items-center justify-between rounded-[20px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
                <span className="text-sm text-[#402d2f]">{label}</span>
                <Toggle enabled={settings.ai[key as keyof SettingsState["ai"]] as boolean} onChange={(value) => updateAi(key as keyof SettingsState["ai"], value)} label={label} />
              </div>
            ))}
          </div>
        </div>
      )}

      {visibleSections.includes({ id: "learned", title: "Learned preferences" }) && (
        <div id="learned" className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Learned preferences</div>
          <div className="space-y-4">
            <div className="grid gap-3 md:grid-cols-3">
              <input value={newPreference.phrase} onChange={(event) => setNewPreference((current) => ({ ...current, phrase: event.target.value }))} placeholder="Example: Fuel for delivery van" className="input-shell" />
              <input value={newPreference.category} onChange={(event) => setNewPreference((current) => ({ ...current, category: event.target.value }))} placeholder="Category" className="input-shell" />
              <select value={newPreference.classification} onChange={(event) => setNewPreference((current) => ({ ...current, classification: event.target.value as LearnedPreference["classification"] }))} className="input-shell">
                <option value="Business">Business</option>
                <option value="Personal">Personal</option>
                <option value="Needs Review">Needs Review</option>
              </select>
            </div>
            <button type="button" onClick={handleAddLearnedPreference} className="rounded-full bg-[#1f2937] px-4 py-2 text-sm font-medium text-white">
              Save learned preference
            </button>

            {settings.learnedPreferences.length === 0 ? (
              <div className="rounded-[20px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 text-sm text-[#563d3f]">
                No learned preferences yet. FABBY uses these to make future categorization suggestions.
              </div>
            ) : (
              <div className="space-y-3">
                {settings.learnedPreferences.map((item) => (
                  <div key={item.id} className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
                    <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                      <div>
                        <div className="font-medium text-[#2d1d1d]">“{item.phrase}” → {item.category}</div>
                        <div className="mt-1 text-xs uppercase tracking-[0.12em] text-[#7a5f60]">{item.classification}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Toggle enabled={item.enabled} onChange={() => handleTogglePreferenceEnabled(item.id)} label={`Enable ${item.phrase}`} />
                        <button type="button" onClick={() => handleDeletePreference(item.id)} className="rounded-full border border-[rgba(109,69,71,0.12)] bg-white px-3 py-1.5 text-xs font-medium text-[#3f2d2f]">
                          Delete
                        </button>
                      </div>
                    </div>
                    <div className="mt-3 flex flex-wrap gap-2">
                      <select value={item.classification} onChange={(event) => handleUpdateLearnedPreference(item.id, { classification: event.target.value as LearnedPreference["classification"] })} className="input-shell max-w-[180px]">
                        <option value="Business">Business</option>
                        <option value="Personal">Personal</option>
                        <option value="Needs Review">Needs Review</option>
                      </select>
                      <input value={item.category} onChange={(event) => handleUpdateLearnedPreference(item.id, { category: event.target.value })} className="input-shell max-w-[180px]" />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {visibleSections.includes({ id: "notifications", title: "Notifications" }) && (
        <div id="notifications" className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Notifications</div>
          <div className="grid gap-4 md:grid-cols-2">
            {Object.entries(settings.notifications).map(([key, value]) => (
              <label key={key} className="space-y-2 text-sm text-[#563d3f]">
                <span>{key.replace(/([A-Z])/g, " $1").replace(/^./, (letter) => letter.toUpperCase())}</span>
                <select value={value} onChange={(event) => updateNotifications(key as keyof SettingsState["notifications"], event.target.value)} className="input-shell">
                  {frequencies.map((option) => (
                    <option key={option} value={option}>{option}</option>
                  ))}
                </select>
              </label>
            ))}
          </div>
        </div>
      )}

      {visibleSections.includes({ id: "reporting", title: "Reporting preferences" }) && (
        <div id="reporting" className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Reporting preferences</div>
          <div className="grid gap-4 md:grid-cols-2">
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Default report period</span>
              <select value={settings.reporting.defaultReportPeriod} onChange={(event) => updateReporting("defaultReportPeriod", event.target.value)} className="input-shell">
                {reportPeriods.map((option) => (
                  <option key={option} value={option}>{option}</option>
                ))}
              </select>
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Default report currency</span>
              <select value={settings.reporting.defaultReportCurrency} onChange={(event) => updateReporting("defaultReportCurrency", event.target.value)} className="input-shell">
                {currencyOptions.map((option) => (
                  <option key={option} value={option}>{option}</option>
                ))}
              </select>
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Default report type</span>
              <select value={settings.reporting.defaultReportType} onChange={(event) => updateReporting("defaultReportType", event.target.value)} className="input-shell">
                {reportTypes.map((option) => (
                  <option key={option} value={option}>{option}</option>
                ))}
              </select>
            </label>
            <div className="flex items-center justify-between rounded-[20px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 text-sm text-[#402d2f]">
              <span>Include Business data</span>
              <Toggle enabled={settings.reporting.includeBusinessData} onChange={(value) => updateReporting("includeBusinessData", value)} label="Include Business data" />
            </div>
            <div className="flex items-center justify-between rounded-[20px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 text-sm text-[#402d2f]">
              <span>Include Personal data</span>
              <Toggle enabled={settings.reporting.includePersonalData} onChange={(value) => updateReporting("includePersonalData", value)} label="Include Personal data" />
            </div>
          </div>
        </div>
      )}

      {visibleSections.includes({ id: "security", title: "Security" }) && (
        <div id="security" className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Security</div>
          <div className="grid gap-4 md:grid-cols-2">
            <button type="button" className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 text-left text-sm text-[#402d2f]">
              <div className="font-medium text-[#2d1d1d]">Change password</div>
              <div className="mt-2 text-xs uppercase tracking-[0.12em] text-[#7a5f60]">Protected flow</div>
            </button>
            <button type="button" className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 text-left text-sm text-[#402d2f]">
              <div className="font-medium text-[#2d1d1d]">Session management</div>
              <div className="mt-2 text-xs uppercase tracking-[0.12em] text-[#7a5f60]">Current sessions</div>
            </button>
            <button type="button" onClick={() => signOut()} className="rounded-[22px] border border-[#e5c7c9] bg-[#fdf1f0] p-4 text-left text-sm font-medium text-[#402d2f]">
              Sign out
            </button>
            <button type="button" className="rounded-[22px] border border-[#e5c7c9] bg-[#fdf1f0] p-4 text-left text-sm font-medium text-[#402d2f]">
              Sign out of other sessions
            </button>
          </div>
        </div>
      )}

      {visibleSections.includes({ id: "privacy", title: "Privacy" }) && (
        <div id="privacy" className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Privacy</div>
          <div className="space-y-3">
            {[
              ["AI data usage", "aiDataUsage", "Controls whether your financial activity can be used for AI-assisted suggestions."],
              ["Financial data analysis", "financialDataAnalysis", "Determines whether FABBY can analyze your financial history for personalized insights."],
              ["AI learning", "aiLearning", "Allows beneficial learning from valid corrections while keeping explicit user choices in control."],
              ["Analytics preferences", "analyticsPreferences", "Controls non-essential product analytics and feature usage tracking."],
            ].map(([label, key, description]) => (
              <div key={key} className="flex flex-col gap-3 rounded-[20px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 md:flex-row md:items-center md:justify-between">
                <div>
                  <div className="text-sm font-medium text-[#2d1d1d]">{label}</div>
                  <div className="mt-1 text-sm text-[#5b3e40]">{description}</div>
                </div>
                <Toggle enabled={settings.privacy[key as keyof SettingsState["privacy"]] as boolean} onChange={(value) => updatePrivacy(key as keyof SettingsState["privacy"], value)} label={label} />
              </div>
            ))}
          </div>
        </div>
      )}

      {visibleSections.includes({ id: "data", title: "Data management" }) && (
        <div id="data" className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Data management</div>
          <div className="grid gap-4 md:grid-cols-2">
            <button type="button" className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 text-left text-sm text-[#402d2f]">
              <div className="font-medium text-[#2d1d1d]">Export financial data</div>
            </button>
            <button type="button" className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 text-left text-sm text-[#402d2f]">
              <div className="font-medium text-[#2d1d1d]">Export transactions</div>
            </button>
            <button type="button" className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 text-left text-sm text-[#402d2f]">
              <div className="font-medium text-[#2d1d1d]">Export reports</div>
            </button>
            <button type="button" onClick={handleClearLearned} className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 text-left text-sm text-[#402d2f]">
              <div className="font-medium text-[#2d1d1d]">Clear learned preferences</div>
            </button>
            <button type="button" className="rounded-[22px] border border-[#e5c7c9] bg-[#fdf1f0] p-4 text-left text-sm font-medium text-[#402d2f] md:col-span-2">
              Request account or data deletion
            </button>
          </div>
        </div>
      )}

      {visibleSections.includes({ id: "appearance", title: "Appearance" }) && (
        <div id="appearance" className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Appearance</div>
          <div className="grid gap-4 md:grid-cols-2">
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Theme</span>
              <select value={settings.appearance.theme} onChange={(event) => { updateAppearance("theme", event.target.value); }} className="input-shell">
                <option value="light">Light</option>
                <option value="dark">Dark</option>
                <option value="system">System</option>
              </select>
            </label>
            <label className="space-y-2 text-sm text-[#563d3f]">
              <span>Primary color</span>
              <input type="color" value={settings.appearance.primaryColor} onChange={(event) => updateAppearance("primaryColor", event.target.value)} className="h-12 w-full rounded-xl border border-[rgba(109,69,71,0.12)] bg-white p-1" />
            </label>
            <label className="space-y-2 text-sm text-[#563d3f] md:col-span-2">
              <span>Secondary color</span>
              <input type="color" value={settings.appearance.secondaryColor} onChange={(event) => updateAppearance("secondaryColor", event.target.value)} className="h-12 w-full rounded-xl border border-[rgba(109,69,71,0.12)] bg-white p-1" />
            </label>
          </div>
        </div>
      )}

      {visibleSections.includes({ id: "integrations", title: "Integrations" }) && (
        <div id="integrations" className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">API / Integrations</div>
          <div className="space-y-4">
            <label className="block space-y-2 text-sm text-[#563d3f]">
              <span>API key</span>
              <input value={settings.integrations.apiKey} onChange={(event) => updateIntegrations("apiKey", event.target.value)} className="input-shell" placeholder="••••••••••••" />
            </label>
            <label className="block space-y-2 text-sm text-[#563d3f]">
              <span>Webhook URL</span>
              <input value={settings.integrations.webhookUrl} onChange={(event) => updateIntegrations("webhookUrl", event.target.value)} className="input-shell" placeholder="https://example.com/webhook" />
            </label>
            <div className="grid gap-3 md:grid-cols-2">
              {Object.entries(settings.integrations.connectedServices).map(([key, value]) => (
                <div key={key} className="flex items-center justify-between rounded-[20px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 text-sm text-[#402d2f]">
                  <span>{key.charAt(0).toUpperCase() + key.slice(1)}</span>
                  <Toggle enabled={value} onChange={(checked) => updateIntegrations("connectedServices", { ...settings.integrations.connectedServices, [key]: checked })} label={`${key} integration`} />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
