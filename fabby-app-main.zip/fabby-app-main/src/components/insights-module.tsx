"use client";

import { useEffect, useMemo, useState } from "react";
import { type LedgerEntry } from "@/lib/financial-ledger";
import { buildInsights } from "@/lib/insights-data";

const currency = new Intl.NumberFormat("en-NG", {
  style: "currency",
  currency: "NGN",
  maximumFractionDigits: 0,
});

function formatMoney(value: number) {
  return currency.format(value);
}

const examplePrompts = [
  "How am I doing financially?",
  "Where am I wasting money?",
  "Why did my expenses increase?",
  "How much did my business make this month?",
  "What should I focus on?",
  "Compare this month to last month.",
  "How is my personal spending?",
  "Which business expenses should I review?",
];

export function InsightsModule({ entries: initialEntries = [] }: { entries?: LedgerEntry[] } = {}) {
  
  const [entries, setEntries] = useState<LedgerEntry[]>(initialEntries);
  const [query, setQuery] = useState("How am I doing financially?");
  const [selectedInsightId, setSelectedInsightId] = useState<string | null>(null);


  const insightData = useMemo(() => buildInsights(entries, { includeGoals: true, askFabbyPrompt: query }), [entries, query]);
  const selectedInsight = useMemo(
    () => insightData.insights.find((item) => item.id === selectedInsightId) ?? insightData.insights[0] ?? null,
    [insightData.insights, selectedInsightId],
  );

  const topCategories = useMemo(() => {
    const map = new Map<string, number>();

    for (const entry of entries) {
      if (entry.type !== "Expense") continue;
      map.set(entry.category, (map.get(entry.category) ?? 0) + Number(entry.amount ?? 0));
    }

    return Array.from(map.entries()).sort((a, b) => b[1] - a[1]).slice(0, 4);
  }, [entries]);

  const answerHighlights = [
    { label: "Income", value: formatMoney(insightData.totalIncome) },
    { label: "Expenses", value: formatMoney(insightData.totalExpenses) },
    { label: "Net cash flow", value: formatMoney(insightData.netCashFlow) },
    { label: "Largest expense", value: insightData.largestExpenseCategory ?? "Not enough data" },
  ];

  if (!insightData.hasEnoughData) {
    return (
      <div className="space-y-6">
        <div className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Insights</div>
          <h2 className="mt-2 text-3xl font-semibold text-[#2d1d1d]">FABBY needs more financial activity before it can provide meaningful insights.</h2>
          <p className="mt-4 max-w-2xl text-[#563d3f]">
            Add income and expenses to start building your financial picture. Once at least a few real transactions are recorded, FABBY can build trend, performance, and risk analysis from your actual data.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="fabby-card rounded-[30px] p-5 md:p-6">
        <div className="mb-5 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Insights</div>
            <h2 className="mt-2 text-3xl font-semibold text-[#2d1d1d]">AI financial intelligence</h2>
          </div>
          <div className="rounded-full bg-[#f7e2e1] px-3 py-1.5 text-xs font-medium text-[#4f2f32]">Powered by your real ledger</div>
        </div>

        <div className="grid gap-4 md:grid-cols-4">
          {answerHighlights.map((item) => (
            <div key={item.label} className="rounded-[24px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
              <div className="text-xs uppercase tracking-[0.14em] text-[#7a5f60]">{item.label}</div>
              <div className="mt-3 text-xl font-semibold text-[#2d1d1d]">{item.value}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="fabby-card rounded-[30px] p-5 md:p-6">
        <div className="mb-4 flex items-center justify-between">
          <div>
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">FABBY AI</div>
            <h3 className="mt-2 text-2xl font-semibold text-[#2d1d1d]">What is happening?</h3>
          </div>
        </div>

        <div className="rounded-[24px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
          <p className="text-sm leading-7 text-[#422d30]">{insightData.aiAnswer}</p>
        </div>

        <div className="mt-4 space-y-3 rounded-[24px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
          <textarea
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            rows={3}
            placeholder="Ask FABBY a financial question..."
            className="input-shell min-h-[96px] resize-none"
          />

          <div className="flex flex-wrap gap-2">
            {examplePrompts.map((example) => (
              <button
                key={example}
                type="button"
                onClick={() => setQuery(example)}
                className="rounded-full border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] px-2.5 py-1.5 text-xs font-medium text-[#4d3a3d] hover:bg-[#fbeae9]"
              >
                {example}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="grid gap-5 xl:grid-cols-2">
        {insightData.insights.map((insight) => (
          <div key={insight.id} className="fabby-card rounded-[28px] p-5">
            <div className="mb-3 flex items-center justify-between gap-3">
              <span className="rounded-full bg-[#f7e4e1] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#4b2d37]">
                {insight.category}
              </span>
              <span className="rounded-full bg-[#f5efe4] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-[0.18em] text-[#5a4d2f]">
                {insight.priority}
              </span>
            </div>

            <div className="text-xl font-semibold text-[#2d1d1d]">{insight.title}</div>
            <p className="mt-3 text-sm leading-6 text-[#523d3f]">{insight.explanation}</p>

            <div className="mt-4 rounded-[20px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-3">
              <div className="text-[11px] uppercase tracking-[0.14em] text-[#7a5f60]">Relevant metric</div>
              <div className="mt-2 text-lg font-semibold text-[#2d1d1d]">{insight.metric}</div>
            </div>

            <div className="mt-4 space-y-2 text-sm text-[#4d3d3f]">
              <div>
                <div className="font-semibold text-[#2d1d1d]">Why this matters</div>
                <div className="mt-1 leading-6">{insight.whyThisMatters}</div>
              </div>
              <div>
                <div className="font-semibold text-[#2d1d1d]">Recommended action</div>
                <div className="mt-1 leading-6">{insight.recommendedAction}</div>
              </div>
            </div>

            <button
              type="button"
              onClick={() => setSelectedInsightId(insight.id)}
              className="mt-5 rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white"
            >
              View details
            </button>
          </div>
        ))}
      </div>

      {selectedInsight && (
        <div className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 flex items-center justify-between gap-3">
            <div>
              <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Drill-down</div>
              <h3 className="mt-2 text-2xl font-semibold text-[#2d1d1d]">{selectedInsight.title}</h3>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-3">
            <div className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
              <div className="text-xs uppercase tracking-[0.14em] text-[#7a5f60]">Previous period</div>
              <div className="mt-2 text-xl font-semibold text-[#2d1d1d]">{formatMoney(selectedInsight.details.previousPeriod)}</div>
            </div>
            <div className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
              <div className="text-xs uppercase tracking-[0.14em] text-[#7a5f60]">Current period</div>
              <div className="mt-2 text-xl font-semibold text-[#2d1d1d]">{formatMoney(selectedInsight.details.currentPeriod)}</div>
            </div>
            <div className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
              <div className="text-xs uppercase tracking-[0.14em] text-[#7a5f60]">Difference</div>
              <div className="mt-2 text-xl font-semibold text-[#2d1d1d]">{formatMoney(selectedInsight.details.difference)}</div>
            </div>
          </div>

          <div className="mt-5">
            <div className="mb-3 text-sm font-semibold uppercase tracking-[0.14em] text-[#7a5f60]">Relevant categories</div>
            <div className="flex flex-wrap gap-2">
              {selectedInsight.details.relevantCategories.map((category) => (
                <span key={category} className="rounded-full bg-[#f6e7e5] px-2.5 py-1 text-xs font-medium text-[#4b2d37]">
                  {category}
                </span>
              ))}
            </div>
          </div>

          <div className="mt-5 overflow-x-auto rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8]">
            <table className="min-w-full text-left text-sm">
              <thead className="bg-[#fdf1ee] text-[#584245]">
                <tr>
                  <th className="px-4 py-3">Date</th>
                  <th className="px-4 py-3">Description</th>
                  <th className="px-4 py-3">Category</th>
                  <th className="px-4 py-3">Type</th>
                  <th className="px-4 py-3">Amount</th>
                </tr>
              </thead>
              <tbody>
                {selectedInsight.details.transactions.map((transaction) => (
                  <tr key={transaction.id} className="border-t border-[rgba(109,69,71,0.06)]">
                    <td className="px-4 py-3">{transaction.date}</td>
                    <td className="px-4 py-3 font-medium text-[#2d1d1d]">{transaction.description}</td>
                    <td className="px-4 py-3">{transaction.category}</td>
                    <td className="px-4 py-3">{transaction.moneyType}</td>
                    <td className="px-4 py-3 font-semibold text-[#2d1d1d]">{formatMoney(transaction.amount)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      <div className="fabby-card rounded-[30px] p-5 md:p-6">
        <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Expense profile</div>
        <div className="space-y-4">
          {topCategories.length === 0 ? (
            <p className="text-sm text-[#563d3f]">No expense data is available yet.</p>
          ) : (
            topCategories.map(([category, value]) => (
              <div key={category}>
                <div className="mb-2 flex items-center justify-between text-sm text-[#4f3f40]">
                  <span>{category}</span>
                  <span>{formatMoney(value)}</span>
                </div>
                <div className="h-2.5 rounded-full bg-[#f6e7e5]">
                  <div className="h-full rounded-full bg-[#d98d96]" style={{ width: `${Math.min(100, (value / Math.max(...topCategories.map(([, amount]) => amount), 1)) * 100)}%` }} />
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
