"use client";

import { useEffect, useMemo, useState } from "react";
import { calculateIncomeSummary, createIncomeRecord, DEFAULT_INCOME_CATEGORIES, DEFAULT_PAYMENT_METHODS, getIncomeForPeriod, type IncomeRecord, type IncomeStatus, type MoneyType } from "@/lib/income";

const defaultForm = {
  amount: "",
  category: "Sales",
  date: new Date().toISOString().slice(0, 10),
  customer: "",
  paymentMethod: "Bank transfer",
  description: "",
  notes: "",
  reference: "",
  status: "Received" as IncomeStatus,
  moneyType: "Business" as MoneyType,
};

const currency = new Intl.NumberFormat("en-NG", {
  style: "currency",
  currency: "NGN",
  maximumFractionDigits: 0,
});

function formatMoney(value: number) {
  return currency.format(value);
}

export function IncomeModule({
  records: initialRecords = [],
  onAddRecord,
  onUpdateRecord,
  onDeleteRecord,
  userId,
}: {
  records?: IncomeRecord[];
  onAddRecord?: (record: IncomeRecord) => Promise<boolean>;
  onUpdateRecord?: (recordId: string, updates: Partial<IncomeRecord>) => Promise<boolean>;
  onDeleteRecord?: (recordId: string) => Promise<boolean>;
  userId?: string;
} = {}) {
   // TODO: Get from Supabase Auth when available
  const [records, setRecords] = useState<IncomeRecord[]>(initialRecords);
  const [form, setForm] = useState(defaultForm);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [statusFilter, setStatusFilter] = useState("All");
  const [paymentFilter, setPaymentFilter] = useState("All");
  const [dateStart, setDateStart] = useState("");
  const [dateEnd, setDateEnd] = useState("");
  const [amountMin, setAmountMin] = useState("");
  const [amountMax, setAmountMax] = useState("");
  const [period, setPeriod] = useState<"today" | "week" | "month" | "quarter" | "year" | "custom">("month");
  const [sortKey, setSortKey] = useState<"date" | "amount" | "description" | "customer" | "category">("date");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const [errors, setErrors] = useState<Partial<Record<keyof typeof defaultForm | "amount", string>>>({});
  const [successMessage, setSuccessMessage] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const allCategories = useMemo(
    () =>
      Array.from(
        new Set([...DEFAULT_INCOME_CATEGORIES, ...records.map((record) => record.category)]),
      ),
    [records],
  );

  const allPaymentMethods = useMemo(
    () =>
      Array.from(new Set([...DEFAULT_PAYMENT_METHODS, ...records.map((record) => record.paymentMethod)])),
    [records],
  );

  const visibleRecords = useMemo(() => {
    const next = records.filter((record) => {
      const searchTarget = `${record.description} ${record.customer} ${record.category} ${record.reference}`.toLowerCase();
      const matchesSearch = searchTerm.trim() === "" || searchTarget.includes(searchTerm.toLowerCase());
      const matchesCategory = categoryFilter === "All" || record.category === categoryFilter;
      const matchesStatus = statusFilter === "All" || record.status === statusFilter;
      const matchesPayment = paymentFilter === "All" || record.paymentMethod === paymentFilter;
      const matchesDateStart = !dateStart || record.date >= dateStart;
      const matchesDateEnd = !dateEnd || record.date <= dateEnd;
      const matchesAmountMin = !amountMin || Number(record.amount) >= Number(amountMin);
      const matchesAmountMax = !amountMax || Number(record.amount) <= Number(amountMax);

      return (
        matchesSearch &&
        matchesCategory &&
        matchesStatus &&
        matchesPayment &&
        matchesDateStart &&
        matchesDateEnd &&
        matchesAmountMin &&
        matchesAmountMax
      );
    });

    next.sort((left, right) => {
      const direction = sortDirection === "asc" ? 1 : -1;
      const leftValue = left[sortKey];
      const rightValue = right[sortKey];

      if (typeof leftValue === "number" && typeof rightValue === "number") {
        return (leftValue - rightValue) * direction;
      }

      return String(leftValue).localeCompare(String(rightValue)) * direction;
    });

    return next;
  }, [amountMax, amountMin, categoryFilter, dateEnd, dateStart, paymentFilter, records, searchTerm, sortDirection, sortKey, statusFilter]);

  const summary = useMemo(() => calculateIncomeSummary(records), [records]);

  const currentPeriodSummary = useMemo(() => {
    const cohort = getIncomeForPeriod(records, period, dateStart || undefined, dateEnd || undefined);
    return calculateIncomeSummary(cohort);
  }, [dateEnd, dateStart, period, records]);

  const selectedRecord = records.find((record) => record.id === selectedId) ?? null;

  const resetForm = () => {
    setForm(defaultForm);
    setEditingId(null);
    setErrors({});
  };

  const validateForm = () => {
    const nextErrors: Partial<Record<keyof typeof defaultForm | "amount", string>> = {};

    const amount = Number(form.amount);
    if (!form.amount || Number.isNaN(amount) || amount <= 0) {
      nextErrors.amount = "Enter a valid amount greater than zero.";
    }
    if (!form.category.trim()) {
      nextErrors.category = "Choose an income category.";
    }
    if (!form.date) {
      nextErrors.date = "Select a date.";
    }
    if (!form.customer.trim()) {
      nextErrors.customer = "Add the customer or payer.";
    }
    if (!form.paymentMethod.trim()) {
      nextErrors.paymentMethod = "Choose a payment method.";
    }
    if (!form.description.trim()) {
      nextErrors.description = "Add a short description.";
    }

    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
    if (!userId) {
      console.error("Income save blocked: no authenticated user.");
      setSuccessMessage("You must be signed in to save income.");
      setTimeout(() => setSuccessMessage(""), 2500);
      return;
    }

    const payload = {
      userId,
      amount: Number(form.amount),
      category: form.category,
      date: form.date,
      customer: form.customer,
      paymentMethod: form.paymentMethod,
      description: form.description,
      notes: form.notes,
      reference: form.reference,
      status: form.status,
      moneyType: form.moneyType,
    };

    if (editingId) {
      // Update existing record
      const updates: Partial<IncomeRecord> = {
        ...payload,
        updatedAt: new Date().toISOString(),
      };
      if (onUpdateRecord) {
        const didUpdate = await onUpdateRecord(editingId, updates);
        if (didUpdate) {
          setRecords((current) =>
            current.map((record) =>
              record.id === editingId
                ? {
                    ...record,
                    ...updates,
                  }
                : record,
            ),
          );
          setSuccessMessage("Income updated successfully.");
        } else {
          setSuccessMessage("Failed to update income.");
        }
      }
    } else {
      // Create new record
      const created = createIncomeRecord(payload);
      if (onAddRecord) {
        const didAdd = await onAddRecord(created);
        if (didAdd) {
          setRecords((current) => [created, ...current]);
          setSuccessMessage("Income saved successfully.");
        } else {
          setSuccessMessage("Failed to save income.");
        }
      } else {
        // Fallback if no callback provided
        setRecords((current) => [created, ...current]);
        setSuccessMessage("Income saved successfully.");
      }
    }

    resetForm();
    setSelectedId(editingId ?? null);
    setTimeout(() => setSuccessMessage(""), 2500);
  };

  const handleEdit = (record: IncomeRecord) => {
    setEditingId(record.id);
    setSelectedId(record.id);
    setForm({
      amount: String(record.amount),
      category: record.category,
      date: record.date,
      customer: record.customer,
      paymentMethod: record.paymentMethod,
      description: record.description,
      notes: record.notes,
      reference: record.reference,
      status: record.status,
      moneyType: record.moneyType ?? "Unclassified",
    });
    setErrors({});
  };

  const handleDelete = async (record: IncomeRecord) => {
    const confirmed = window.confirm(`Delete income from ${record.customer}?`);
    if (!confirmed) return;

    if (onDeleteRecord) {
      const didDelete = await onDeleteRecord(record.id);
      if (didDelete) {
        setRecords((current) => current.filter((item) => item.id !== record.id));
        if (selectedId === record.id) {
          setSelectedId(null);
        }
        if (editingId === record.id) {
          resetForm();
        }
        setSuccessMessage("Income removed successfully.");
      } else {
        setSuccessMessage("Failed to delete income.");
      }
    } else {
      // Fallback if no callback provided
      setRecords((current) => current.filter((item) => item.id !== record.id));
      if (selectedId === record.id) {
        setSelectedId(null);
      }
      if (editingId === record.id) {
        resetForm();
      }
      setSuccessMessage("Income removed successfully.");
    }
    setTimeout(() => setSuccessMessage(""), 2500);
  };

  const handleSort = (field: typeof sortKey) => {
    if (sortKey === field) {
      setSortDirection((current) => (current === "asc" ? "desc" : "asc"));
      return;
    }
    setSortKey(field);
    setSortDirection(field === "amount" ? "desc" : "asc");
  };

  const resetFilters = () => {
    setSearchTerm("");
    setCategoryFilter("All");
    setStatusFilter("All");
    setPaymentFilter("All");
    setDateStart("");
    setDateEnd("");
    setAmountMin("");
    setAmountMax("");
  };

  const onSearch = (value: string) => setSearchTerm(value);

  return (
    <div className="space-y-6">
      <div className="fabby-card rounded-[30px] p-5 md:p-6">
        <div className="mb-5 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Income</div>
            <h2 className="mt-2 text-3xl font-semibold text-[#2d1d1d]">Income overview</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {[
              ["Today", "today"],
              ["This week", "week"],
              ["This month", "month"],
              ["This quarter", "quarter"],
              ["This year", "year"],
            ].map(([label, value]) => (
              <button
                key={value}
                type="button"
                onClick={() => setPeriod(value as typeof period)}
                className={`rounded-full px-3 py-1.5 text-xs font-medium transition ${
                  period === value ? "bg-[#2d1d1d] text-white" : "border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] text-[#4e3638]"
                }`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-6">
          {[
            { label: "Total income", value: formatMoney(summary.total) },
            { label: "This month", value: formatMoney(currentPeriodSummary.monthly) },
            { label: "This year", value: formatMoney(currentPeriodSummary.yearly) },
            { label: "Pending income", value: formatMoney(summary.pending) },
            { label: "Average income", value: formatMoney(summary.average) },
            { label: "Transactions", value: String(summary.count) },
          ].map((card) => (
            <div key={card.label} className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
              <div className="text-xs uppercase tracking-[0.14em] text-[#7a5f60]">{card.label}</div>
              <div className="mt-3 text-2xl font-semibold text-[#2d1d1d]">{card.value}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid gap-6 xl:grid-cols-[420px_minmax(0,1fr)]">
        <div className="fabby-card rounded-[30px] p-5">
          <div className="mb-4 flex items-center justify-between">
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">
              {editingId ? "Edit income" : "Add income"}
            </div>
            {editingId ? (
              <button type="button" onClick={resetForm} className="text-xs font-medium text-[#8b5961]">
                Cancel
              </button>
            ) : null}
          </div>

          <div className="space-y-4">
            <div>
              <label className="mb-2 block text-sm font-medium text-[#422d30]">Amount</label>
              <input
                type="number"
                min="0"
                step="0.01"
                value={form.amount}
                onChange={(event) => setForm((current) => ({ ...current, amount: event.target.value }))}
                className="input-shell"
                placeholder="0.00"
              />
              {errors.amount ? <div className="mt-1 text-xs text-[#9b4d4f]">{errors.amount}</div> : null}
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-medium text-[#422d30]">Category</label>
                <select
                  value={form.category}
                  onChange={(event) => setForm((current) => ({ ...current, category: event.target.value }))}
                  className="input-shell"
                >
                  {allCategories.map((category) => (
                    <option key={category} value={category}>{category}</option>
                  ))}
                </select>
                {errors.category ? <div className="mt-1 text-xs text-[#9b4d4f]">{errors.category}</div> : null}
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-[#422d30]">Date</label>
                <input
                  type="date"
                  value={form.date}
                  onChange={(event) => setForm((current) => ({ ...current, date: event.target.value }))}
                  className="input-shell"
                />
                {errors.date ? <div className="mt-1 text-xs text-[#9b4d4f]">{errors.date}</div> : null}
              </div>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-[#422d30]">Customer / payer</label>
              <input
                type="text"
                value={form.customer}
                onChange={(event) => setForm((current) => ({ ...current, customer: event.target.value }))}
                className="input-shell"
                placeholder="Client or payer name"
              />
              {errors.customer ? <div className="mt-1 text-xs text-[#9b4d4f]">{errors.customer}</div> : null}
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm font-medium text-[#422d30]">Payment method</label>
                <select
                  value={form.paymentMethod}
                  onChange={(event) => setForm((current) => ({ ...current, paymentMethod: event.target.value }))}
                  className="input-shell"
                >
                  {allPaymentMethods.map((method) => (
                    <option key={method} value={method}>{method}</option>
                  ))}
                </select>
                {errors.paymentMethod ? <div className="mt-1 text-xs text-[#9b4d4f]">{errors.paymentMethod}</div> : null}
              </div>

              <div>
                <label className="mb-2 block text-sm font-medium text-[#422d30]">Status</label>
                <select
                  value={form.status}
                  onChange={(event) => setForm((current) => ({ ...current, status: event.target.value as IncomeStatus }))}
                  className="input-shell"
                >
                  <option value="Received">Received</option>
                  <option value="Pending">Pending</option>
                </select>
              </div>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-[#422d30]">Money type</label>
              <select
                value={form.moneyType}
                onChange={(event) => setForm((current) => ({ ...current, moneyType: event.target.value as MoneyType }))}
                className="input-shell"
              >
                <option value="Business">Business</option>
                <option value="Personal">Personal</option>
                <option value="Unclassified">Unclassified</option>
              </select>
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-[#422d30]">Description</label>
              <input
                type="text"
                value={form.description}
                onChange={(event) => setForm((current) => ({ ...current, description: event.target.value }))}
                className="input-shell"
                placeholder="What was this income for?"
              />
              {errors.description ? <div className="mt-1 text-xs text-[#9b4d4f]">{errors.description}</div> : null}
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-[#422d30]">Notes</label>
              <textarea
                rows={3}
                value={form.notes}
                onChange={(event) => setForm((current) => ({ ...current, notes: event.target.value }))}
                className="input-shell resize-none"
                placeholder="Optional notes"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm font-medium text-[#422d30]">Reference / invoice</label>
              <input
                type="text"
                value={form.reference}
                onChange={(event) => setForm((current) => ({ ...current, reference: event.target.value }))}
                className="input-shell"
                placeholder="INV-1024"
              />
            </div>

            {successMessage ? (
              <div className="rounded-2xl border border-[#dfece5] bg-[#eefaf5] px-3 py-2 text-sm text-[#234d3d]">
                {successMessage}
              </div>
            ) : null}

            <button
              type="button"
              onClick={handleSubmit}
              className="flex w-full items-center justify-center rounded-full bg-[#2d1d1d] px-5 py-3 text-sm font-medium text-white"
            >
              {editingId ? "Update income" : "Save income"}
            </button>
          </div>
        </div>

        <div className="fabby-card rounded-[30px] p-5">
          <div className="mb-4 flex items-center justify-between gap-3">
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Income records</div>
            {records.length > 0 ? (
              <button type="button" onClick={resetFilters} className="text-xs font-medium text-[#8b5961]">
                Reset filters
              </button>
            ) : null}
          </div>

          <div className="space-y-3">
            <input
              value={searchTerm}
              onChange={(event) => onSearch(event.target.value)}
              placeholder="Search description, customer, category or reference"
              className="input-shell"
            />

            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              <select value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)} className="input-shell">
                <option value="All">All categories</option>
                {allCategories.map((category) => (
                  <option key={category} value={category}>{category}</option>
                ))}
              </select>

              <select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)} className="input-shell">
                <option value="All">All statuses</option>
                <option value="Received">Received</option>
                <option value="Pending">Pending</option>
              </select>

              <select value={paymentFilter} onChange={(event) => setPaymentFilter(event.target.value)} className="input-shell">
                <option value="All">All payment methods</option>
                {allPaymentMethods.map((method) => (
                  <option key={method} value={method}>{method}</option>
                ))}
              </select>
            </div>

            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
              <input type="date" value={dateStart} onChange={(event) => setDateStart(event.target.value)} className="input-shell" />
              <input type="date" value={dateEnd} onChange={(event) => setDateEnd(event.target.value)} className="input-shell" />
              <input type="number" min="0" value={amountMin} onChange={(event) => setAmountMin(event.target.value)} className="input-shell" placeholder="Min amount" />
              <input type="number" min="0" value={amountMax} onChange={(event) => setAmountMax(event.target.value)} className="input-shell" placeholder="Max amount" />
            </div>
          </div>

          {records.length === 0 ? (
            <div className="mt-6 rounded-[26px] border border-dashed border-[rgba(109,69,71,0.2)] bg-[#fffaf8] p-8 text-center">
              <div className="text-2xl font-semibold text-[#2d1d1d]">No income recorded yet</div>
              <p className="mt-2 text-sm text-[#5d4547]">
                Start tracking your business income to see your financial picture come to life.
              </p>
              <button
                type="button"
                onClick={() => setForm((current) => ({ ...current, date: new Date().toISOString().slice(0, 10) }))}
                className="mt-4 rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white"
              >
                + Add income
              </button>
            </div>
          ) : (
            <div className="mt-5 overflow-x-auto rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8]">
              <table className="min-w-full text-left text-sm">
                <thead className="bg-[#fdf1ee] text-[#584245]">
                  <tr>
                    {[
                      ["date", "Date"],
                      ["description", "Description"],
                      ["customer", "Customer"],
                      ["category", "Category"],
                      ["paymentMethod", "Payment method"],
                      ["amount", "Amount"],
                      ["status", "Status"],
                    ].map(([field, label]) => (
                      <th key={field} className="px-4 py-3">
                        <button type="button" onClick={() => handleSort(field as typeof sortKey)} className="font-semibold text-left">
                          {label}
                        </button>
                      </th>
                    ))}
                    <th className="px-4 py-3">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {visibleRecords.map((record) => (
                    <tr key={record.id} className="border-t border-[rgba(109,69,71,0.06)]">
                      <td className="px-4 py-3">{record.date}</td>
                      <td className="px-4 py-3">
                        <button type="button" onClick={() => setSelectedId(record.id)} className="font-medium text-[#2d1d1d] hover:underline">
                          {record.description}
                        </button>
                      </td>
                      <td className="px-4 py-3">{record.customer}</td>
                      <td className="px-4 py-3">{record.category}</td>
                      <td className="px-4 py-3">{record.paymentMethod}</td>
                      <td className="px-4 py-3 font-semibold text-[#2f7f67]">{formatMoney(record.amount)}</td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${record.moneyType === "Business" ? "bg-[#dfeef7] text-[#294d74]" : record.moneyType === "Personal" ? "bg-[#fce5d9] text-[#7d4d2f]" : "bg-[#f0eef7] text-[#5b536d]"}`}>
                          {record.moneyType ?? "Unclassified"}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${record.status === "Received" ? "bg-[#ddefea] text-[#2f7f67]" : "bg-[#f7e8d8] text-[#8f5c39]"}`}>
                          {record.status}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-wrap gap-2">
                          <button type="button" onClick={() => setSelectedId(record.id)} className="text-xs font-medium text-[#4b2d37]">
                            View
                          </button>
                          <button type="button" onClick={() => handleEdit(record)} className="text-xs font-medium text-[#5a3a3d]">
                            Edit
                          </button>
                          <button type="button" onClick={() => handleDelete(record)} className="text-xs font-medium text-[#9c4d4d]">
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      {selectedRecord ? (
        <div className="fabby-card rounded-[30px] p-5 md:p-6">
          <div className="mb-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Income details</div>
              <h3 className="mt-2 text-2xl font-semibold text-[#2d1d1d]">{selectedRecord.description}</h3>
            </div>
            <div className="flex flex-wrap gap-2">
              <button type="button" onClick={() => handleEdit(selectedRecord)} className="rounded-full border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] px-3 py-1.5 text-sm font-medium text-[#412a2d]">
                Edit
              </button>
              <button type="button" onClick={() => handleDelete(selectedRecord)} className="rounded-full border border-[#efb2b6] bg-[#fff3f3] px-3 py-1.5 text-sm font-medium text-[#6e3c41]">
                Delete
              </button>
            </div>
          </div>

          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {[
              ["Amount", formatMoney(selectedRecord.amount)],
              ["Date", selectedRecord.date],
              ["Category", selectedRecord.category],
              ["Customer", selectedRecord.customer],
              ["Payment method", selectedRecord.paymentMethod],
              ["Money type", selectedRecord.moneyType ?? "Unclassified"],
              ["Status", selectedRecord.status],
              ["Reference", selectedRecord.reference || "—"],
              ["Created", new Date(selectedRecord.createdAt).toLocaleString()],
              ["Updated", new Date(selectedRecord.updatedAt).toLocaleString()],
            ].map(([label, value]) => (
              <div key={label} className="rounded-[20px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
                <div className="text-xs uppercase tracking-[0.14em] text-[#7a5f60]">{label}</div>
                <div className="mt-2 text-base font-medium text-[#2d1d1d]">{String(value)}</div>
              </div>
            ))}
          </div>

          <div className="mt-5 grid gap-4 md:grid-cols-2">
            <div className="rounded-[20px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
              <div className="text-xs uppercase tracking-[0.14em] text-[#7a5f60]">Description</div>
              <p className="mt-2 text-[#3d2d2f]">{selectedRecord.description}</p>
            </div>
            <div className="rounded-[20px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
              <div className="text-xs uppercase tracking-[0.14em] text-[#7a5f60]">Notes</div>
              <p className="mt-2 text-[#3d2d2f]">{selectedRecord.notes || "No notes added."}</p>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
