"use client";

import { useEffect, useMemo, useState } from "react";
import { type LedgerEntry } from "@/lib/financial-ledger";

type Period = "today" | "week" | "month" | "lastMonth" | "quarter" | "lastQuarter" | "year" | "lastYear" | "custom";
type CashView = "All" | "Business" | "Personal";
type CategoryDrill = {
  type: "Income" | "Expense";
  category: string;
};

const currency = new Intl.NumberFormat("en-NG", {
  style: "currency",
  currency: "NGN",
  maximumFractionDigits: 0,
});

const PERIOD_LABELS: Record<Period, string> = {
  today: "Today",
  week: "This week",
  month: "This month",
  lastMonth: "Last month",
  quarter: "This quarter",
  lastQuarter: "Last quarter",
  year: "This year",
  lastYear: "Last year",
  custom: "Custom range",
};

function formatMoney(value: number) {
  return currency.format(value);
}

function getOpeningBalanceKey(userId: string) {
  return `fabby-opening-balance-${userId}`;
}

function readOpeningBalance(userId: string): number | null {
  if (typeof window === "undefined") return null;
  const value = window.localStorage.getItem(getOpeningBalanceKey(userId));
  if (!value) return null;
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

function writeOpeningBalance(userId: string, value: number) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(getOpeningBalanceKey(userId), String(value));
}

function safeDate(value: string | undefined) {
  if (!value) return null;
  const parsed = new Date(`${value}T00:00:00`);
  return Number.isNaN(parsed.getTime()) ? null : parsed;
}

function getDateRange(period: Period, customStart?: string, customEnd?: string) {
  const now = new Date();
  const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  if (period === "custom") {
    return {
      start: customStart ? safeDate(customStart) : null,
      end: customEnd ? new Date(`${customEnd}T23:59:59`) : null,
    };
  }

  if (period === "today") {
    return { start: today, end: new Date(today.getTime() + 86400000 - 1) };
  }

  if (period === "week") {
    const start = new Date(today);
    const diff = (start.getDay() === 0 ? -6 : 1 - start.getDay());
    start.setDate(start.getDate() + diff);
    const end = new Date(start);
    end.setDate(start.getDate() + 6);
    end.setHours(23, 59, 59, 999);
    return { start, end };
  }

  if (period === "month") {
    return {
      start: new Date(now.getFullYear(), now.getMonth(), 1),
      end: new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999),
    };
  }

  if (period === "lastMonth") {
    return {
      start: new Date(now.getFullYear(), now.getMonth() - 1, 1),
      end: new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999),
    };
  }

  if (period === "quarter") {
    const quarterStart = Math.floor(now.getMonth() / 3) * 3;
    return {
      start: new Date(now.getFullYear(), quarterStart, 1),
      end: new Date(now.getFullYear(), quarterStart + 3, 0, 23, 59, 59, 999),
    };
  }

  if (period === "lastQuarter") {
    const quarterStart = Math.floor(now.getMonth() / 3) * 3;
    return {
      start: new Date(now.getFullYear(), quarterStart - 3, 1),
      end: new Date(now.getFullYear(), quarterStart, 0, 23, 59, 59, 999),
    };
  }

  if (period === "year") {
    return {
      start: new Date(now.getFullYear(), 0, 1),
      end: new Date(now.getFullYear(), 11, 31, 23, 59, 59, 999),
    };
  }

  return {
    start: new Date(now.getFullYear() - 1, 0, 1),
    end: new Date(now.getFullYear() - 1, 11, 31, 23, 59, 59, 999),
  };
}

function filterEntriesByRange(entries: LedgerEntry[], period: Period, customStart?: string, customEnd?: string) {
  const range = getDateRange(period, customStart, customEnd);

  return entries.filter((entry) => {
    const entryDate = safeDate(entry.date);
    if (!entryDate) return false;

    const matchesStart = range.start ? entryDate >= range.start : true;
    const matchesEnd = range.end ? entryDate <= range.end : true;
    return matchesStart && matchesEnd;
  });
}

function getCategoryBreakdown(entries: LedgerEntry[], type: "Income" | "Expense") {
  const totals = new Map<string, { amount: number; count: number }>();
  for (const entry of entries) {
    if (entry.type !== type) continue;
    const current = totals.get(entry.category) ?? { amount: 0, count: 0 };
    current.amount += Number(entry.amount ?? 0);
    current.count += 1;
    totals.set(entry.category, current);
  }

  const total = Array.from(totals.values()).reduce((sum, item) => sum + item.amount, 0);
  return Array.from(totals.entries())
    .map(([category, value]) => ({
      category,
      amount: value.amount,
      count: value.count,
      percent: total === 0 ? 0 : (value.amount / total) * 100,
    }))
    .sort((a, b) => b.amount - a.amount);
}

function getBucketSeries(entries: LedgerEntry[], period: Period, customStart?: string, customEnd?: string) {
  const range = getDateRange(period, customStart, customEnd);
  const start = range.start ?? new Date(Date.now() - 30 * 86400000);
  const end = range.end ?? new Date();
  const bucketCount = 6;
  const totalSpan = Math.max(end.getTime() - start.getTime(), 86400000);
  const bucketSize = totalSpan / bucketCount;

  const buckets = Array.from({ length: bucketCount }, (_, index) => ({
    label: `${index + 1}`,
    moneyIn: 0,
    moneyOut: 0,
    net: 0,
  }));

  for (const entry of entries) {
    const dateValue = safeDate(entry.date);
    if (!dateValue) continue;
    const offset = Math.min(bucketCount - 1, Math.max(0, Math.floor((dateValue.getTime() - start.getTime()) / bucketSize)));
    const bucket = buckets[offset];
    if (!bucket) continue;

    if (entry.type === "Income") {
      bucket.moneyIn += Number(entry.amount ?? 0);
    } else {
      bucket.moneyOut += Number(entry.amount ?? 0);
    }
    bucket.net = bucket.moneyIn - bucket.moneyOut;
  }

  return buckets.map((bucket, index) => {
    const labelDate = new Date(start.getTime() + (index + 0.5) * bucketSize);
    return {
      ...bucket,
      label: labelDate.toLocaleDateString("en-NG", { month: "short", day: "numeric" }),
    };
  });
}

function getForecast(entries: LedgerEntry[], period: Period, customStart?: string, customEnd?: string) {
  const currentRange = getDateRange(period, customStart, customEnd);
  const periodLengthMs = Math.max(
    (currentRange.end?.getTime() ?? Date.now()) - (currentRange.start?.getTime() ?? Date.now() - 30 * 86400000),
    86400000,
  );

  const previousWindows: LedgerEntry[][] = [];
  for (let step = 1; step <= 3; step += 1) {
    const start = currentRange.start ? new Date(currentRange.start.getTime() - step * periodLengthMs) : new Date(Date.now() - 30 * 86400000 * step);
    const end = currentRange.start ? new Date(currentRange.start.getTime() - (step - 1) * periodLengthMs) : new Date(Date.now() - 30 * 86400000 * (step - 1));
    const historical = entries.filter((entry) => {
      const dateValue = safeDate(entry.date);
      return dateValue && dateValue >= start && dateValue <= end;
    });
    if (historical.length > 0) previousWindows.push(historical);
  }

  if (previousWindows.length < 2) {
    return {
      available: false,
      message: "FABBY needs more financial history to create a reliable cash-flow forecast.",
      expectedIn: 0,
      expectedOut: 0,
      projectedNet: 0,
      projectedBalance: null,
    };
  }

  const totalIn = previousWindows.reduce((sum, window) => sum + window.filter((entry) => entry.type === "Income").reduce((inner, item) => inner + Number(item.amount ?? 0), 0), 0);
  const totalOut = previousWindows.reduce((sum, window) => sum + window.filter((entry) => entry.type === "Expense").reduce((inner, item) => inner + Number(item.amount ?? 0), 0), 0);
  const avgIn = totalIn / previousWindows.length;
  const avgOut = totalOut / previousWindows.length;
  const projectedNet = avgIn - avgOut;

  return {
    available: true,
    expectedIn: avgIn,
    expectedOut: avgOut,
    projectedNet,
    projectedBalance: null,
    message: "Forecast based on the most recent available-period trend.",
  };
}

export function CashFlowModule({
  entries: initialEntries = [],
  onAddEntry,
  onUpdateEntry,
  onDeleteEntry,
}: {
  entries?: LedgerEntry[];
  onAddEntry?: (entry: LedgerEntry) => Promise<boolean>;
  onUpdateEntry?: (entryId: string, updates: Partial<LedgerEntry>) => Promise<boolean>;
  onDeleteEntry?: (entryId: string) => Promise<boolean>;
} = {}) {
  
  const [entries, setEntries] = useState<LedgerEntry[]>(initialEntries);
  const [period, setPeriod] = useState<Period>("month");
  const [customStart, setCustomStart] = useState("");
  const [customEnd, setCustomEnd] = useState("");
  const [moneyView, setMoneyView] = useState<CashView>("All");
  const [selectedCategory, setSelectedCategory] = useState<CategoryDrill | null>(null);
  const [openingBalanceInput, setOpeningBalanceInput] = useState("");
  const [aiQuestion, setAiQuestion] = useState("");
  const [aiAnswer, setAiAnswer] = useState("");

  const filteredEntries = useMemo(() => {
    const dateFiltered = filterEntriesByRange(entries, period, customStart || undefined, customEnd || undefined);
    return dateFiltered.filter((entry) => {
      if (moneyView === "All") return true;
      return entry.moneyType === moneyView;
    });
  }, [customEnd, customStart, entries, moneyView, period]);

  const openingBalance = null; // Opening balance disabled for now
  const moneyIn = useMemo(() => filteredEntries.filter((entry) => entry.type === "Income").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0), [filteredEntries]);
  const moneyOut = useMemo(() => filteredEntries.filter((entry) => entry.type === "Expense").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0), [filteredEntries]);
  const netCashFlow = moneyIn - moneyOut;
  const closingBalance = openingBalance === null ? null : openingBalance + netCashFlow;

  const businessEntries = useMemo(() => filteredEntries.filter((entry) => entry.moneyType === "Business"), [filteredEntries]);
  const personalEntries = useMemo(() => filteredEntries.filter((entry) => entry.moneyType === "Personal"), [filteredEntries]);
  const businessIn = businessEntries.filter((entry) => entry.type === "Income").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0);
  const businessOut = businessEntries.filter((entry) => entry.type === "Expense").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0);
  const personalIn = personalEntries.filter((entry) => entry.type === "Income").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0);
  const personalOut = personalEntries.filter((entry) => entry.type === "Expense").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0);

  const chartData = useMemo(() => getBucketSeries(filteredEntries, period, customStart || undefined, customEnd || undefined), [customEnd, customStart, filteredEntries, period]);
  const chartMax = Math.max(1, ...chartData.flatMap((item) => [item.moneyIn, item.moneyOut, item.net]));

  const inflowBreakdown = useMemo(() => getCategoryBreakdown(filteredEntries, "Income"), [filteredEntries]);
  const outflowBreakdown = useMemo(() => getCategoryBreakdown(filteredEntries, "Expense"), [filteredEntries]);
  const forecast = useMemo(() => getForecast(entries, period, customStart || undefined, customEnd || undefined), [customEnd, customStart, entries, period]);

  const alerts = useMemo(() => {
    const items: string[] = [];
    if (netCashFlow < 0) {
      items.push("Your net cash flow is negative in the selected period.");
    }

    const previousPeriodEntries = filterEntriesByRange(entries, period === "month" ? "lastMonth" : "month", customStart || undefined, customEnd || undefined);
    const previousMoneyOut = previousPeriodEntries.filter((entry) => entry.type === "Expense").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0);
    if (previousMoneyOut > 0 && moneyOut > 0 && previousMoneyOut > 0) {
      const increase = ((moneyOut - previousMoneyOut) / previousMoneyOut) * 100;
      if (increase > 15) {
        items.push(`Expenses increased ${increase.toFixed(1)}% compared with the previous period.`);
      }
    }

    if (forecast.available && forecast.projectedNet < 0) {
      items.push("Projected cash flow is negative, so the business may need tighter spending controls.");
    }

    return items.slice(0, 3);
  }, [entries, customEnd, customStart, forecast.available, forecast.projectedNet, moneyOut, netCashFlow, period]);

  const aiInsight = useMemo(() => {
    if (!filteredEntries.length) {
      return "Your cash flow will appear here as you record income and expenses.";
    }

    const topExpense = [...outflowBreakdown].sort((a, b) => b.amount - a.amount)[0];
    const topIncome = [...inflowBreakdown].sort((a, b) => b.amount - a.amount)[0];
    if (!topExpense || !topIncome) return "FABBY has enough data to continue monitoring your cash movement.";

    return `FABBY noticed that your cash outflow is mostly driven by ${topExpense.category}, while inflow is being led by ${topIncome.category}. This pattern shows where the business is spending and where the cash is coming from.`;
  }, [filteredEntries.length, inflowBreakdown, outflowBreakdown]);

  // const saveOpeningBalance = () => {
  //     const parsed = Number(openingBalanceInput);
  //     if (!Number.isFinite(parsed)) return;
  //     // Opening balance saving disabled
  //     setOpeningBalanceInput("");
  //   }

  const updateEntry = (id: string, updates: Partial<LedgerEntry>) => {
    setEntries((current) =>
      current.map((entry) => (entry.id === id ? { ...entry, ...updates, updatedAt: new Date().toISOString() } : entry)),
    );
  };

  const removeEntry = (id: string) => {
    setEntries((current) => current.filter((entry) => entry.id !== id));
    if (selectedCategory && selectedCategory.category) {
      setSelectedCategory(null);
    }
  };

  const askAi = () => {
    const cleaned = aiQuestion.trim().toLowerCase();
    if (!cleaned) return;

    if (cleaned.includes("cash flow") || cleaned.includes("how is my cash flow doing")) {
      setAiAnswer(`Your current cash flow for this period is ${formatMoney(netCashFlow)}. Inflow is ${formatMoney(moneyIn)} and outflow is ${formatMoney(moneyOut)}. Business net is ${formatMoney(businessIn - businessOut)} and personal net is ${formatMoney(personalIn - personalOut)}.`);
      return;
    }

    if (cleaned.includes("why is my cash balance falling") || cleaned.includes("cash balance falling")) {
      if (moneyOut > moneyIn) {
        const mainDrains = [...outflowBreakdown].slice(0, 2).map((item) => `${item.category} (${formatMoney(item.amount)})`).join(" and ");
        setAiAnswer(`FABBY reviewed your real records and saw that outflow exceeds inflow. The biggest cash drains are ${mainDrains}. That combination is driving the lower closing balance.`);
        return;
      }
      setAiAnswer("Your selected period does not currently show a negative net cash position, so the recent trend is stable rather than falling.");
      return;
    }

    if (cleaned.includes("biggest cash drains") || cleaned.includes("biggest expense") || cleaned.includes("cash drains")) {
      const topItem = [...outflowBreakdown].sort((a, b) => b.amount - a.amount)[0];
      setAiAnswer(topItem ? `The biggest real cash drain is ${topItem.category}, totaling ${formatMoney(topItem.amount)} across ${topItem.count} transaction(s).` : "FABBY does not currently have enough expense data to identify a largest cash drain.");
      return;
    }

    if (cleaned.includes("enough cash next month") || cleaned.includes("will i have enough cash")) {
      if (forecast.available) {
        setAiAnswer(`Using your recent historical trend, FABBY estimates ${formatMoney(forecast.expectedIn)} in inflow and ${formatMoney(forecast.expectedOut)} in outflow, producing a projected net of ${formatMoney(forecast.projectedNet)}. This is a forecast, not a guarantee.`);
        return;
      }
      setAiAnswer("FABBY needs more financial history to create a reliable cash-flow forecast for next month.");
      return;
    }

    if (cleaned.includes("business") && cleaned.includes("personal")) {
      setAiAnswer(`Business net cash flow is ${formatMoney(businessIn - businessOut)} while personal net cash flow is ${formatMoney(personalIn - personalOut)}. The difference is based on your actual classified transactions only.`);
      return;
    }

    if (cleaned.includes("improve my cash flow") || cleaned.includes("improve cash flow")) {
      const topDrains = [...outflowBreakdown].slice(0, 3).map((item) => `${item.category} (${formatMoney(item.amount)})`).join(", ");
      setAiAnswer(`FABBY recommends focusing on the largest expense categories: ${topDrains}. Reducing those outflows while keeping inflow stable is the clearest path to improving net cash flow.`);
      return;
    }

    setAiAnswer("FABBY can review your actual cash flow, business vs personal separation, expense categories, and forecast using your stored transaction data.");
  };

  const visibleDetailEntries = selectedCategory
    ? filteredEntries.filter((entry) => entry.type === selectedCategory.type && entry.category === selectedCategory.category)
    : [];

  return (
    <div className="space-y-6">
      <div className="fabby-card rounded-[30px] p-5 md:p-6">
        <div className="mb-5 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Cash flow</div>
            <h2 className="mt-2 text-3xl font-semibold text-[#2d1d1d]">Cash flow dashboard</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {(
              [
                "today",
                "week",
                "month",
                "lastMonth",
                "quarter",
                "lastQuarter",
                "year",
                "lastYear",
                "custom",
              ] as Period[]
            ).map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => setPeriod(option)}
                className={`rounded-full px-3 py-1.5 text-xs font-medium ${
                  period === option ? "bg-[#2d1d1d] text-white" : "border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] text-[#4b2d37]"
                }`}
              >
                {PERIOD_LABELS[option]}
              </button>
            ))}
          </div>
        </div>

        {period === "custom" && (
          <div className="mb-5 grid gap-3 md:grid-cols-3">
            <input type="date" value={customStart} onChange={(event) => setCustomStart(event.target.value)} className="input-shell" />
            <input type="date" value={customEnd} onChange={(event) => setCustomEnd(event.target.value)} className="input-shell" />
            <button type="button" onClick={() => setPeriod("month")} className="rounded-full border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] px-3 py-2 text-sm font-medium text-[#4b2d37]">
              Reset range
            </button>
          </div>
        )}

        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-6">
          {[
            { label: "Opening cash balance", value: openingBalance === null ? "Opening balance not configured" : formatMoney(openingBalance) },
            { label: "Total money in", value: formatMoney(moneyIn) },
            { label: "Total money out", value: formatMoney(moneyOut) },
            { label: "Net cash flow", value: formatMoney(netCashFlow) },
            { label: "Closing cash balance", value: closingBalance === null ? "Set opening balance" : formatMoney(closingBalance) },
            { label: "Business cash flow", value: formatMoney(businessIn - businessOut) },
          ].map((card) => (
            <div key={card.label} className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
              <div className="text-[10px] uppercase tracking-[0.14em] text-[#7a5f60]">{card.label}</div>
              <div className="mt-3 text-xl font-semibold text-[#2d1d1d]">{card.value}</div>
            </div>
          ))}
        </div>

        {openingBalance === null && (
          <div className="mt-5 flex flex-col gap-3 rounded-[22px] border border-dashed border-[rgba(109,69,71,0.18)] bg-[#fffaf8] p-4 md:flex-row md:items-center md:justify-between">
            <div className="text-sm text-[#4a3638]">Opening balance not configured.</div>
            <div className="flex gap-2">
              <input
                value={openingBalanceInput}
                onChange={(event) => setOpeningBalanceInput(event.target.value)}
                type="number"
                placeholder="Enter opening balance"
                className="input-shell w-full md:w-[220px]"
              />
              {/* <button type="button">Save (disabled)</button> */}
            </div>
          </div>
        )}
      </div>

      {filteredEntries.length === 0 ? (
        <div className="fabby-card rounded-[30px] p-8 text-center">
          <div className="text-3xl font-semibold text-[#2d1d1d]">Your cash flow will appear here as you record income and expenses.</div>
          <p className="mt-3 text-[#5a4547]">Add income or expense records to generate your real cash-flow dashboard.</p>
          <div className="mt-6 flex justify-center gap-3">
            <button type="button" className="rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white">Add income</button>
            <button type="button" className="rounded-full border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] px-4 py-2 text-sm font-medium text-[#4b2d37]">Add expense</button>
          </div>
        </div>
      ) : (
        <>
          <div className="grid gap-6 xl:grid-cols-[1.2fr_0.8fr]">
            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-4 flex items-center justify-between">
                <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Cash movement</div>
                <div className="flex gap-2">
                  {(["All", "Business", "Personal"] as CashView[]).map((option) => (
                    <button
                      key={option}
                      type="button"
                      className={`rounded-full px-3 py-1.5 text-xs font-medium ${
                        moneyView === option ? "bg-[#2d1d1d] text-white" : "border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] text-[#4b2d37]"
                      }`}
                      onClick={() => setMoneyView(option)}
                    >
                      {option}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex h-56 items-end gap-3 pt-3">
                {chartData.map((bucket) => (
                  <div key={bucket.label} className="flex flex-1 flex-col items-center justify-end gap-2">
                    <div className="flex h-full w-full items-end justify-center gap-1">
                      <div className="w-1/2 rounded-t-[10px] bg-[#d98f9a]" style={{ height: `${Math.max(12, (bucket.moneyIn / chartMax) * 100)}%` }} />
                      <div className="w-1/2 rounded-t-[10px] bg-[#f4b4a5]" style={{ height: `${Math.max(12, (bucket.moneyOut / chartMax) * 100)}%` }} />
                    </div>
                    <span className="text-[10px] text-[#68565a]">{bucket.label}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">AI cash-flow insight</div>
              <p className="text-base leading-7 text-[#422b2c]">{aiInsight}</p>
              <div className="mt-5 space-y-2 text-sm text-[#4d3639]">
                <div><span className="font-semibold">WHY IT MATTERS:</span> Inflow and outflow are being read directly from live transaction data.</div>
                <div><span className="font-semibold">WHAT CHANGED:</span> Cash movement is based on the selected period and filter.</div>
                <div><span className="font-semibold">WHAT TO WATCH:</span> Review the top expense categories and the projected balance.</div>
                <div><span className="font-semibold">POSSIBLE ACTION:</span> Reduce the top cash outflows or improve collections where possible.</div>
              </div>
            </div>
          </div>

          <div className="grid gap-6 xl:grid-cols-2">
            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Money in</div>
              <div className="space-y-3">
                {inflowBreakdown.length ? inflowBreakdown.map((item) => (
                  <button
                    key={item.category}
                    type="button"
                    onClick={() => setSelectedCategory({ type: "Income", category: item.category })}
                    className="block w-full rounded-[18px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-3 text-left"
                  >
                    <div className="flex items-center justify-between text-sm text-[#422d30]">
                      <span>{item.category}</span>
                      <span className="font-semibold">{formatMoney(item.amount)}</span>
                    </div>
                    <div className="mt-2 h-2.5 rounded-full bg-[#f6e7e5]">
                      <div className="h-full rounded-full bg-[#2f7f67]" style={{ width: `${Math.min(item.percent, 100)}%` }} />
                    </div>
                    <div className="mt-2 flex items-center justify-between text-[11px] uppercase tracking-[0.12em] text-[#7a5f60]">
                      <span>{item.count} tx</span>
                      <span>{item.percent.toFixed(1)}%</span>
                    </div>
                  </button>
                )) : <div className="text-sm text-[#5e4748]">No inflow data for the selected period.</div>}
              </div>
            </div>

            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Money out</div>
              <div className="space-y-3">
                {outflowBreakdown.length ? outflowBreakdown.map((item) => (
                  <button
                    key={item.category}
                    type="button"
                    onClick={() => setSelectedCategory({ type: "Expense", category: item.category })}
                    className="block w-full rounded-[18px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-3 text-left"
                  >
                    <div className="flex items-center justify-between text-sm text-[#422d30]">
                      <span>{item.category}</span>
                      <span className="font-semibold">{formatMoney(item.amount)}</span>
                    </div>
                    <div className="mt-2 h-2.5 rounded-full bg-[#f6e7e5]">
                      <div className="h-full rounded-full bg-[#d98e95]" style={{ width: `${Math.min(item.percent, 100)}%` }} />
                    </div>
                    <div className="mt-2 flex items-center justify-between text-[11px] uppercase tracking-[0.12em] text-[#7a5f60]">
                      <span>{item.count} tx</span>
                      <span>{item.percent.toFixed(1)}%</span>
                    </div>
                  </button>
                )) : <div className="text-sm text-[#5e4748]">No outflow data for the selected period.</div>}
              </div>
            </div>
          </div>

          <div className="grid gap-6 xl:grid-cols-3">
            <div className="fabby-card rounded-[30px] p-5">
              <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Business cash flow</div>
              <div className="mt-4 space-y-3 text-sm text-[#422d30]">
                <div className="flex items-center justify-between"><span>Business money in</span><span className="font-semibold">{formatMoney(businessIn)}</span></div>
                <div className="flex items-center justify-between"><span>Business money out</span><span className="font-semibold">{formatMoney(businessOut)}</span></div>
                <div className="flex items-center justify-between"><span>Business net</span><span className="font-semibold text-[#2f7f67]">{formatMoney(businessIn - businessOut)}</span></div>
              </div>
            </div>

            <div className="fabby-card rounded-[30px] p-5">
              <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Personal cash flow</div>
              <div className="mt-4 space-y-3 text-sm text-[#422d30]">
                <div className="flex items-center justify-between"><span>Personal money in</span><span className="font-semibold">{formatMoney(personalIn)}</span></div>
                <div className="flex items-center justify-between"><span>Personal money out</span><span className="font-semibold">{formatMoney(personalOut)}</span></div>
                <div className="flex items-center justify-between"><span>Personal net</span><span className="font-semibold text-[#b86738]">{formatMoney(personalIn - personalOut)}</span></div>
              </div>
            </div>

            <div className="fabby-card rounded-[30px] p-5">
              <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Forecast</div>
              <div className="mt-4 space-y-3 text-sm text-[#422d30]">
                {forecast.available ? (
                  <>
                    <div className="flex items-center justify-between"><span>Expected money in</span><span className="font-semibold">{formatMoney(forecast.expectedIn)}</span></div>
                    <div className="flex items-center justify-between"><span>Expected money out</span><span className="font-semibold">{formatMoney(forecast.expectedOut)}</span></div>
                    <div className="flex items-center justify-between"><span>Projected net</span><span className="font-semibold">{formatMoney(forecast.projectedNet)}</span></div>
                    <div className="flex items-center justify-between"><span>Projected balance</span><span className="font-semibold">{openingBalance === null ? "Set opening balance" : formatMoney((openingBalance ?? 0) + forecast.projectedNet)}</span></div>
                  </>
                ) : (
                  <div className="text-sm text-[#4d3639]">{forecast.message}</div>
                )}
              </div>
            </div>
          </div>

          {alerts.length > 0 && (
            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-3 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Low cash-flow alerts</div>
              <div className="space-y-3">
                {alerts.map((alert) => (
                  <div key={alert} className="rounded-[18px] border border-[#f0dccd] bg-[#fff9f1] p-3 text-sm text-[#4a362e]">
                    {alert}
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="fabby-card rounded-[30px] p-5">
            <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Cash-flow AI analyst</div>
            <div className="grid gap-3 md:grid-cols-[1fr_auto]">
              <textarea
                value={aiQuestion}
                onChange={(event) => setAiQuestion(event.target.value)}
                placeholder="Ask: How is my cash flow doing? Why is my cash balance falling?"
                className="input-shell min-h-[110px] resize-none"
              />
              <button type="button" onClick={askAi} className="rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white md:self-end">
                Ask FABBY
              </button>
            </div>
            {aiAnswer ? (
              <div className="mt-4 rounded-[20px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 text-sm leading-7 text-[#422b2c]">
                {aiAnswer}
              </div>
            ) : null}
          </div>

          {selectedCategory && (
            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-4 flex items-center justify-between">
                <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Transaction drill-down</div>
                <button type="button" onClick={() => setSelectedCategory(null)} className="text-sm font-medium text-[#8b5961]">
                  Close
                </button>
              </div>

              <div className="overflow-x-auto rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8]">
                <table className="min-w-full text-left text-sm">
                  <thead className="bg-[#fdf1ee] text-[#584245]">
                    <tr>
                      <th className="px-4 py-3">Date</th>
                      <th className="px-4 py-3">Description</th>
                      <th className="px-4 py-3">Amount</th>
                      <th className="px-4 py-3">Money type</th>
                      <th className="px-4 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {visibleDetailEntries.map((entry) => (
                      <tr key={entry.id} className="border-t border-[rgba(109,69,71,0.06)]">
                        <td className="px-4 py-3">{entry.date}</td>
                        <td className="px-4 py-3">{entry.description}</td>
                        <td className={`px-4 py-3 font-semibold ${entry.type === "Income" ? "text-[#2f7f67]" : "text-[#3a2c2d]"}`}>
                          {entry.type === "Income" ? "+" : "-"}
                          {formatMoney(entry.amount)}
                        </td>
                        <td className="px-4 py-3">
                          <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${entry.moneyType === "Business" ? "bg-[#dfeef7] text-[#294d74]" : entry.moneyType === "Personal" ? "bg-[#fce5d9] text-[#7d4d2f]" : "bg-[#f0eef7] text-[#5b536d]"}`}>
                            {entry.moneyType}
                          </span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex gap-2">
                            <button type="button" onClick={() => updateEntry(entry.id, { moneyType: entry.moneyType === "Business" ? "Personal" : "Business" })} className="text-xs font-medium text-[#4b2d37]">Edit</button>
                            <button type="button" onClick={() => removeEntry(entry.id)} className="text-xs font-medium text-[#9c4d4d]">Delete</button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
