"use client";

import { useMemo, useState, useEffect } from "react";
import { createBrowserClient } from "@/lib/supabase/client";
import { useAuth } from "@/contexts/auth-context";
import { DEFAULT_INCOME_CATEGORIES, getStoredIncomeRecords, type IncomeRecord } from "@/lib/income";

type ReportType =
  | "profit-loss"
  | "income"
  | "expense"
  | "cash-flow"
  | "balance"
  | "tax"
  | "performance";

type ReportPeriod =
  | "week"
  | "month"
  | "lastMonth"
  | "quarter"
  | "lastQuarter"
  | "year"
  | "lastYear"
  | "custom";

type ExpenseRecord = {
  id: string;
  userId: string;
  amount: number;
  category: string;
  date: string;
  description: string;
  vendor: string;
  paymentMethod: string;
  notes: string;
  reference: string;
  status: "Paid" | "Pending";
  createdAt: string;
  updatedAt: string;
};

type LedgerRecord = {
  id: string;
  userId?: string;
  type: "Income" | "Expense";
  amount: number;
  category: string;
  date: string;
  customer?: string;
  vendor?: string;
  description: string;
  paymentMethod?: string;
  notes?: string;
  reference?: string;
  status?: string;
  createdAt?: string;
  updatedAt?: string;
};

type SavedReport = {
  id: string;
  reportType: ReportType;
  period: ReportPeriod;
  label: string;
  startDate: string;
  endDate: string;
  generatedAt: string;
  filters: {
    category: string;
    customer: string;
  };
  summary: {
    income: number;
    expenses: number;
    net: number;
  };
};

const REPORT_TYPES: { value: ReportType; label: string }[] = [
  { value: "profit-loss", label: "Profit & Loss" },
  { value: "income", label: "Income" },
  { value: "expense", label: "Expense" },
  { value: "cash-flow", label: "Cash Flow" },
  { value: "balance", label: "Balance Summary" },
  { value: "tax", label: "Tax Summary" },
  { value: "performance", label: "Business Performance" },
];

const PERIOD_LABELS: Record<ReportPeriod, string> = {
  week: "This week",
  month: "This month",
  lastMonth: "Last month",
  quarter: "This quarter",
  lastQuarter: "Last quarter",
  year: "This year",
  lastYear: "Last year",
  custom: "Custom range",
};

const currency = new Intl.NumberFormat("en-NG", {
  style: "currency",
  currency: "NGN",
  maximumFractionDigits: 0,
});

function formatMoney(value: number) {
  return currency.format(value);
}

function readSavedReports(): SavedReport[] {
  if (typeof window === "undefined") return [];

  try {
    const raw = window.localStorage.getItem("fabby-saved-reports");
    return raw ? (JSON.parse(raw) as SavedReport[]) : [];
  } catch {
    return [];
  }
}

function writeSavedReports(reports: SavedReport[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem("fabby-saved-reports", JSON.stringify(reports));
}

function getCurrentUserId() {
  if (typeof window === "undefined") return "local-user";
  // TODO: Get user ID from Supabase Auth when available
  return "local-user";
}

function normalizeDate(value: string) {
  if (!value) return "";
  const date = new Date(`${value}T00:00:00`);
  if (Number.isNaN(date.getTime())) return "";
  return date.toISOString().slice(0, 10);
}

function toDateOnly(date: Date) {
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}

function getDateRange(period: ReportPeriod, customStart?: string, customEnd?: string) {
  const today = new Date();
  const now = new Date(today.getFullYear(), today.getMonth(), today.getDate());

  if (period === "custom") {
    return {
      start: customStart ? new Date(`${customStart}T00:00:00`) : null,
      end: customEnd ? new Date(`${customEnd}T23:59:59`) : null,
    };
  }

  const ranges: Record<ReportPeriod, { start: Date | null; end: Date | null }> = {
    week: {
      start: new Date(now),
      end: new Date(now),
    },
    month: {
      start: new Date(now.getFullYear(), now.getMonth(), 1),
      end: new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999),
    },
    lastMonth: {
      start: new Date(now.getFullYear(), now.getMonth() - 1, 1),
      end: new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999),
    },
    quarter: {
      start: new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 1),
      end: new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3 + 3, 0, 23, 59, 59, 999),
    },
    lastQuarter: {
      start: new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3 - 3, 1),
      end: new Date(now.getFullYear(), Math.floor(now.getMonth() / 3) * 3, 0, 23, 59, 59, 999),
    },
    year: {
      start: new Date(now.getFullYear(), 0, 1),
      end: new Date(now.getFullYear(), 11, 31, 23, 59, 59, 999),
    },
    lastYear: {
      start: new Date(now.getFullYear() - 1, 0, 1),
      end: new Date(now.getFullYear() - 1, 11, 31, 23, 59, 59, 999),
    },
    custom: {
      start: null,
      end: null,
    },
  };

  if (period === "week") {
    const startOfWeek = new Date(now);
    const day = startOfWeek.getDay();
    const diff = (day === 0 ? -6 : 1 - day);
    startOfWeek.setDate(now.getDate() + diff);
    ranges.week.start = startOfWeek;
    ranges.week.end = new Date(startOfWeek);
    ranges.week.end.setDate(startOfWeek.getDate() + 6);
    ranges.week.end.setHours(23, 59, 59, 999);
  }

  return ranges[period];
}

function getAllStoredTransactions() {
  // Legacy fallback for local storage
  if (typeof window === "undefined") return [] as LedgerRecord[];

  const userId = getCurrentUserId();
  const sources = ["fabby-ledger-transactions", "fabby-transactions", "fabby-income-records", "fabby-expense-records"];
  const combined: LedgerRecord[] = [];

  for (const key of sources) {
    try {
      const raw = window.localStorage.getItem(key);
      if (!raw) continue;
      const parsed = JSON.parse(raw);

      if (key === "fabby-income-records") {
        const grouped = parsed as Record<string, IncomeRecord[]> | IncomeRecord[];
        const records = Array.isArray(grouped) ? grouped : grouped[userId] ?? [];
        for (const item of records) {
          combined.push({
            id: item.id,
            userId: item.userId,
            type: "Income",
            amount: Number(item.amount),
            category: item.category,
            date: item.date,
            customer: item.customer,
            description: item.description,
            paymentMethod: item.paymentMethod,
            notes: item.notes,
            reference: item.reference,
            status: item.status,
            createdAt: item.createdAt,
            updatedAt: item.updatedAt,
          });
        }
        continue;
      }

      if (key === "fabby-expense-records") {
        const grouped = parsed as Record<string, ExpenseRecord[]> | ExpenseRecord[];
        const records = Array.isArray(grouped) ? grouped : grouped[userId] ?? [];
        for (const item of records) {
          combined.push({
            id: item.id,
            userId: item.userId,
            type: "Expense",
            amount: Number(item.amount),
            category: item.category,
            date: item.date,
            vendor: item.vendor,
            description: item.description,
            paymentMethod: item.paymentMethod,
            notes: item.notes,
            reference: item.reference,
            status: item.status,
            createdAt: item.createdAt,
            updatedAt: item.updatedAt,
          });
        }
        continue;
      }

      const entries = Array.isArray(parsed) ? parsed : Object.values(parsed ?? {});
      for (const item of entries) {
        if (!item || typeof item !== "object") continue;
        const rawType = item.type ?? (item.amount && item.kind === "expense" ? "Expense" : "Income");
        if (rawType === "Income" || rawType === "Expense") {
          combined.push({
            id: String(item.id ?? `${rawType}-${Math.random()}`),
            userId: item.userId ?? userId,
            type: rawType,
            amount: Number(item.amount ?? 0),
            category: item.category ?? "Other",
            date: item.date ?? toDateOnly(new Date()),
            customer: item.customer ?? item.vendor ?? "Customer",
            vendor: item.vendor,
            description: item.description ?? "Financial record",
            paymentMethod: item.paymentMethod ?? "Bank transfer",
            notes: item.notes ?? "",
            reference: item.reference ?? "",
            status: item.status ?? "Received",
            createdAt: item.createdAt ?? new Date().toISOString(),
            updatedAt: item.updatedAt ?? new Date().toISOString(),
          });
        }
      }
    } catch {
      // ignore malformed storage entries
    }
  }

  const deduped = new Map<string, LedgerRecord>();
  for (const item of combined) {
    deduped.set(`${item.type}-${item.id}`, item);
  }

  return Array.from(deduped.values());
}

async function fetchSupabaseTransactions(userId: string): Promise<LedgerRecord[]> {
  const supabase = createBrowserClient();
  const combined: LedgerRecord[] = [];

  try {
    const { data: transactions, error: transError } = await supabase
      .from("transactions")
      .select("*")
      .eq("user_id", userId)
      .order("date", { ascending: false });

    if (transError) throw transError;

    console.log(`[Reports] Fetched ${transactions?.length || 0} transactions from Supabase`);

    for (const tx of transactions ?? []) {
      combined.push({
        id: String(tx.id),
        userId: tx.user_id,
        type: tx.type as "Income" | "Expense",
        amount: Number(tx.amount ?? 0),
        category: tx.category || "Uncategorized",
        date: String(tx.date || toDateOnly(new Date())),
        customer: tx.type === "Income" ? "Customer" : undefined,
        vendor: tx.type === "Expense" ? "Vendor" : undefined,
        description: tx.description || "",
        paymentMethod: undefined,
        notes: tx.notes || "",
        reference: undefined,
        status: tx.status || "Completed",
        createdAt: tx.created_at,
        updatedAt: tx.updated_at,
      });
    }
  } catch (error) {
    console.error("[Reports] Failed to fetch transactions from Supabase:", error);
  }

  console.log(`[Reports] Returning ${combined.length} processed transactions`);
  return combined;
}

function sumByCategory(records: LedgerRecord[]) {
  const map = new Map<string, number>();
  for (const record of records) {
    map.set(record.category, (map.get(record.category) ?? 0) + record.amount);
  }
  return Array.from(map.entries()).map(([category, amount]) => ({ category, amount }));
}

function buildPdfBytes(title: string, periodLabel: string, summary: { income: number; expenses: number; net: number }, rows: { label: string; value: string }[]) {
  const documentTitle = title.replace(/\(/g, "").replace(/\)/g, "");
  const lines = [
    "FABBY",
    "Powered by Wiltecon Technologies",
    "Founded by Wilson Nometa",
    "",
    `${documentTitle}`,
    `Reporting period: ${periodLabel}`,
    "",
    `Total income: ${formatMoney(summary.income)}`,
    `Total expenses: ${formatMoney(summary.expenses)}`,
    `Net profit: ${formatMoney(summary.net)}`,
    "",
    ...rows.map((row) => `${row.label}: ${row.value}`),
  ];

  const contentLines = lines.map((line, index) => `BT /F1 12 Tf 72 ${720 - index * 18} Td (${escapePdfText(line)}) Tj ET`).join("\n");
  const content = `stream\n${contentLines}\nendstream`;
  const objects = [
    "<< /Type /Catalog /Pages 2 0 R >>",
    "<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
    "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>",
    "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    `<< /Length ${content.length} >>\n${content}`,
  ];

  const pdfParts: string[] = ["%PDF-1.4\n"];
  const offsets: number[] = [0];

  objects.forEach((object, index) => {
    offsets.push(pdfParts.join("").length);
    pdfParts.push(`${index + 1} 0 obj\n${object}\nendobj\n`);
  });

  const xrefPosition = pdfParts.join("").length;
  pdfParts.push(`xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`);

  for (let i = 1; i < offsets.length; i += 1) {
    pdfParts.push(`${String(offsets[i]).padStart(10, "0")} 00000 n \n`);
  }

  const trailer = `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xrefPosition}\n%%EOF`;
  pdfParts.push(trailer);

  return new TextEncoder().encode(pdfParts.join(""));
}

function escapePdfText(value: string) {
  return value.replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}

export function ReportsModule({
  incomeRecords = [],
  transactions = [],
}: {
  incomeRecords?: IncomeRecord[];
  transactions?: Array<LedgerRecord | { id: string; type: "Income" | "Expense"; amount: number; category: string; date: string; description: string; customer?: string; vendor?: string; paymentMethod?: string; notes?: string; reference?: string; status?: string; userId?: string; createdAt?: string; updatedAt?: string; }>;
} = {}) {
  const { user, isLoading: authLoading } = useAuth();
  const [reportType, setReportType] = useState<ReportType>("profit-loss");
  const [period, setPeriod] = useState<ReportPeriod>("month");
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [customerFilter, setCustomerFilter] = useState("All");
  const [savedReports, setSavedReports] = useState<SavedReport[]>(() => readSavedReports());
  const [statusMessage, setStatusMessage] = useState("");
  const [selectedSavedReport, setSelectedSavedReport] = useState<string | null>(null);
  const [supabaseTransactions, setSupabaseTransactions] = useState<LedgerRecord[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(false);

  // Fetch transactions from Supabase
  useEffect(() => {
    const fetchData = async () => {
      if (!user?.id) {
        console.log("[Reports] No user ID, skipping fetch");
        return;
      }
      
      console.log(`[Reports] Starting fetch for user: ${user.id}`);
      setIsLoadingData(true);
      setStatusMessage("Loading financial data...");
      
      try {
        const data = await fetchSupabaseTransactions(user.id);
        console.log(`[Reports] useEffect received ${data.length} transactions`);
        setSupabaseTransactions(data);
        
        if (data.length === 0) {
          setStatusMessage("No transactions found. Add income or expenses to generate reports.");
        } else {
          setStatusMessage(`Loaded ${data.length} transactions. Click Generate Report to refresh.`);
        }
      } catch (error) {
        console.error("[Reports] Error in useEffect:", error);
        setStatusMessage("Error loading report data. Please check the browser console.");
        setSupabaseTransactions([]);
      } finally {
        setIsLoadingData(false);
      }
    };

    void fetchData();
  }, [user?.id]);

  const rawTransactions = useMemo(() => {
    // Prefer Supabase data if available, fall back to localStorage
    const data = supabaseTransactions.length > 0 ? supabaseTransactions : getAllStoredTransactions();
    console.log(`[Reports] rawTransactions updated: ${data.length} total (from ${supabaseTransactions.length > 0 ? "Supabase" : "localStorage"})`);
    return data;
  }, [supabaseTransactions]);

  const reportDateRange = useMemo(() => {
    const normalizedStart = normalizeDate(startDate);
    const normalizedEnd = normalizeDate(endDate);
    return getDateRange(period, normalizedStart || undefined, normalizedEnd || undefined);
  }, [endDate, period, startDate]);

  const filteredTransactions = useMemo(() => {
    console.log(`[Reports] Filtering ${rawTransactions.length} transactions with period:`, period, "category:", categoryFilter, "customer:", customerFilter);
    
    const records = rawTransactions.filter((record) => {
      // Date filtering
      const dateValue = record.date ?? toDateOnly(new Date());
      const recordDate = new Date(`${dateValue}T00:00:00`);
      const inRange =
        (!reportDateRange.start || recordDate >= reportDateRange.start) &&
        (!reportDateRange.end || recordDate <= reportDateRange.end);
      
      // Category filtering
      const categoryMatches = categoryFilter === "All" || record.category === categoryFilter;
      
      // Customer filtering - skip if "All"
      const customerMatches = customerFilter === "All" ? true : false;
      
      return inRange && categoryMatches && customerMatches;
    });

    console.log(`[Reports] Filtered to ${records.length} transactions`);
    return records;
  }, [categoryFilter, customerFilter, rawTransactions, reportDateRange, period]);

  const expenseRecords = useMemo(() => {
    const records = rawTransactions.filter((record) => {
      // Type must be Expense
      if (record.type !== "Expense") return false;
      
      // Date filtering
      const dateValue = record.date ?? toDateOnly(new Date());
      const recordDate = new Date(`${dateValue}T00:00:00`);
      const inRange =
        (!reportDateRange.start || recordDate >= reportDateRange.start) &&
        (!reportDateRange.end || recordDate <= reportDateRange.end);
      
      // Category filtering
      const categoryMatches = categoryFilter === "All" || record.category === categoryFilter;
      
      return inRange && categoryMatches;
    });
    
    console.log(`[Reports] Expense records: ${records.length}`);
    return records;
  }, [categoryFilter, rawTransactions, reportDateRange]);

  const incomeRecordsFromTransactions = useMemo(
    () => {
      const records = rawTransactions.filter((record) => {
        // Type must be Income
        if (record.type !== "Income") return false;
        
        // Date filtering
        const dateValue = record.date ?? toDateOnly(new Date());
        const recordDate = new Date(`${dateValue}T00:00:00`);
        const inRange =
          (!reportDateRange.start || recordDate >= reportDateRange.start) &&
          (!reportDateRange.end || recordDate <= reportDateRange.end);
        
        // Category filtering
        const categoryMatches = categoryFilter === "All" || record.category === categoryFilter;
        
        return inRange && categoryMatches;
      });
      
      console.log(`[Reports] Income records: ${records.length}`);
      return records;
    },
    [rawTransactions, reportDateRange, categoryFilter]
  );

  const summary = useMemo(() => {
    const incomeTotal = incomeRecordsFromTransactions.reduce((sum, item) => sum + Number(item.amount || 0), 0);
    const expenseTotal = expenseRecords.reduce((sum, item) => sum + Number(item.amount || 0), 0);
    const net = incomeTotal - expenseTotal;
    const profitMargin = incomeTotal === 0 ? 0 : (net / incomeTotal) * 100;
    
    console.log(`[Reports] Summary: income=${incomeTotal}, expenses=${expenseTotal}, net=${net}, margin=${profitMargin.toFixed(1)}%`);
    
    return {
      income: incomeTotal,
      expenses: expenseTotal,
      net,
      profitMargin,
      grossProfit: Math.max(0, incomeTotal - expenseTotal),
    };
  }, [expenseRecords, incomeRecordsFromTransactions]);

  const incomeByCategory = useMemo(() => sumByCategory(incomeRecordsFromTransactions), [incomeRecordsFromTransactions]);

  const expenseByCategory = useMemo(() => sumByCategory(expenseRecords), [expenseRecords]);

  const incomeByCustomer = useMemo(() => {
    const map = new Map<string, number>();
    for (const record of incomeRecordsFromTransactions) {
      const key = record.customer || "Unknown customer";
      map.set(key, (map.get(key) ?? 0) + Number(record.amount));
    }
    return Array.from(map.entries()).map(([name, amount]) => ({ name, amount })).sort((a, b) => b.amount - a.amount);
  }, [incomeRecordsFromTransactions]);

  const expenseByVendor = useMemo(() => {
    const map = new Map<string, number>();
    for (const record of expenseRecords) {
      const key = record.vendor || record.customer || "Unknown vendor";
      map.set(key, (map.get(key) ?? 0) + Number(record.amount));
    }
    return Array.from(map.entries()).map(([name, amount]) => ({ name, amount })).sort((a, b) => b.amount - a.amount);
  }, [expenseRecords]);

  const allCategories = useMemo(
    () => Array.from(new Set([...DEFAULT_INCOME_CATEGORIES, ...rawTransactions.map((record) => record.category)])),
    [rawTransactions],
  );

  const allCustomers = useMemo(
    () => {
      const customers = Array.from(new Set(rawTransactions.flatMap((record) => [record.customer ?? record.vendor ?? ""]).filter(Boolean)));
      console.log(`[Reports] Available customers: ${customers.length}`);
      return customers;
    },
    [rawTransactions],
  );

  const currentPeriodLabel = PERIOD_LABELS[period] || "Custom range";
  const periodLabel = period === "custom" ? `${startDate || "Start"} to ${endDate || "End"}` : currentPeriodLabel;

  const reportRows = useMemo(() => {
    const rows: { label: string; value: string }[] = [];

    if (reportType === "profit-loss") {
      rows.push({ label: "Total income", value: formatMoney(summary.income) });
      rows.push({ label: "Total expenses", value: formatMoney(summary.expenses) });
      rows.push({ label: "Net profit", value: formatMoney(summary.net) });
      rows.push({ label: "Profit margin", value: `${summary.profitMargin.toFixed(1)}%` });
    }

    if (reportType === "income") {
      rows.push({ label: "Total income", value: formatMoney(summary.income) });
      rows.push({ label: "Top category", value: incomeByCategory[0]?.category ?? "No data" });
      rows.push({ label: "Top payer", value: incomeByCustomer[0]?.name ?? "No data" });
    }

    if (reportType === "expense") {
      rows.push({ label: "Total expenses", value: formatMoney(summary.expenses) });
      rows.push({ label: "Largest expense", value: expenseByVendor[0]?.name ?? "No data" });
      rows.push({ label: "Largest category", value: expenseByCategory[0]?.category ?? "No data" });
    }

    if (reportType === "cash-flow") {
      rows.push({ label: "Money in", value: formatMoney(summary.income) });
      rows.push({ label: "Money out", value: formatMoney(summary.expenses) });
      rows.push({ label: "Net split", value: formatMoney(summary.net) });
    }

    if (reportType === "balance") {
      rows.push({ label: "Recorded income", value: formatMoney(summary.income) });
      rows.push({ label: "Recorded expenses", value: formatMoney(summary.expenses) });
      rows.push({ label: "Net position", value: formatMoney(summary.net) });
    }

    if (reportType === "tax") {
      rows.push({ label: "Estimated gross income", value: formatMoney(summary.income) });
      rows.push({ label: "Estimated deductible spend", value: formatMoney(summary.expenses) });
      rows.push({ label: "Estimated taxable result", value: formatMoney(summary.net) });
    }

    if (reportType === "performance") {
      rows.push({ label: "Revenue growth", value: `${((summary.income || 0) > 0 ? 100 : 0).toFixed(1)}%` });
      rows.push({ label: "Expense growth", value: `${((summary.expenses || 0) > 0 ? 100 : 0).toFixed(1)}%` });
      rows.push({ label: "Profit growth", value: `${((summary.net || 0) > 0 ? 100 : 0).toFixed(1)}%` });
    }

    return rows;
  }, [expenseByCategory, expenseByVendor, incomeByCategory, incomeByCustomer, reportType, summary]);

  const reportInsight = useMemo(() => {
    if (!filteredTransactions.length) {
      return "Your reports will appear here as you record income and expenses.";
    }

    const topIncome = [...incomeByCategory].sort((a, b) => b.amount - a.amount)[0];
    const topExpense = [...expenseByCategory].sort((a, b) => b.amount - a.amount)[0];
    const overall = summary.net >= 0 ? "positive" : "negative";

    return `Your current performance is ${overall}. The highest income category is ${topIncome?.category ?? "not available"} and the largest expense category is ${topExpense?.category ?? "not available"}. The report reflects real recorded financial activity across your current range.`;
  }, [expenseByCategory, filteredTransactions.length, incomeByCategory, summary.net]);

  const generateCsv = () => {
    if (!filteredTransactions.length) {
      setStatusMessage("There are no records to export in the current report range.");
      return;
    }

    const csvRows = [
      ["Date", "Type", "Category", "Customer", "Description", "Amount", "Status"],
      ...filteredTransactions.map((record) => [
        record.date,
        record.type,
        record.category,
        record.customer ?? record.vendor ?? "",
        record.description,
        String(record.amount),
        record.status ?? "",
      ]),
    ];

    const csvContent = csvRows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\n");
    const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${reportType}-report.csv`;
    link.click();
    URL.revokeObjectURL(url);
    setStatusMessage("CSV export generated successfully.");
  };

  const generatePdf = () => {
    if (!filteredTransactions.length) {
      setStatusMessage("There are no records in the selected range to generate a PDF.");
      return;
    }

    const rows = reportRows.map((row) => ({ label: row.label, value: row.value }));
    const bytes = buildPdfBytes(reportType.replace("-", " ").toUpperCase(), periodLabel, summary, rows);
    const blob = new Blob([bytes], { type: "application/pdf" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `${reportType}-report.pdf`;
    link.click();
    URL.revokeObjectURL(url);
    setStatusMessage("PDF report generated successfully.");
  };

  const saveCurrentReport = () => {
    if (!filteredTransactions.length) {
      setStatusMessage("No report data is available to save yet.");
      return;
    }

    const nextReports = readSavedReports();
    const saved: SavedReport = {
      id: `report-${Date.now()}`,
      reportType,
      period,
      label: REPORT_TYPES.find((item) => item.value === reportType)?.label ?? "Report",
      startDate: startDate || "",
      endDate: endDate || "",
      generatedAt: new Date().toISOString(),
      filters: {
        category: categoryFilter,
        customer: customerFilter,
      },
      summary: {
        income: summary.income,
        expenses: summary.expenses,
        net: summary.net,
      },
    };

    const updated = [saved, ...nextReports].slice(0, 12);
    writeSavedReports(updated);
    setSavedReports(updated);
    setSelectedSavedReport(saved.id);
    setStatusMessage("Report saved successfully.");
  };

  const deleteSavedReport = (id: string) => {
    const updated = savedReports.filter((report) => report.id !== id);
    setSavedReports(updated);
    writeSavedReports(updated);
    if (selectedSavedReport === id) setSelectedSavedReport(null);
    setStatusMessage("Saved report deleted.");
  };

  const totalRevenueTrend = incomeByCategory.length ? incomeByCategory.reduce((sum, item) => sum + item.amount, 0) : 0;
  const chartMax = Math.max(1, ...[...incomeByCategory, ...expenseByCategory].map((item) => item.amount));

  return (
    <div className="space-y-6">
      <div className="fabby-card rounded-[30px] p-5 md:p-6">
        <div className="mb-5 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Reports</div>
            <h2 className="mt-2 text-3xl font-semibold text-[#2d1d1d]">Financial reporting</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            <button type="button" onClick={generateCsv} className="rounded-full border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] px-3 py-1.5 text-sm font-medium text-[#4b2d37]">
              Export CSV
            </button>
            <button type="button" onClick={generatePdf} className="rounded-full border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] px-3 py-1.5 text-sm font-medium text-[#4b2d37]">
              Export PDF
            </button>
            <button type="button" onClick={saveCurrentReport} className="rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white">
              Save report
            </button>
          </div>
        </div>

        <div className="grid gap-4 xl:grid-cols-[1fr_1fr_220px_auto]">
          <select value={reportType} onChange={(event) => setReportType(event.target.value as ReportType)} className="input-shell">
            {REPORT_TYPES.map((option) => (
              <option key={option.value} value={option.value}>{option.label}</option>
            ))}
          </select>

          <select value={period} onChange={(event) => setPeriod(event.target.value as ReportPeriod)} className="input-shell">
            {Object.entries(PERIOD_LABELS).map(([value, label]) => (
              <option key={value} value={value}>{label}</option>
            ))}
          </select>

          <div className="grid grid-cols-2 gap-2">
            <input type="date" value={startDate} onChange={(event) => setStartDate(event.target.value)} className="input-shell" />
            <input type="date" value={endDate} onChange={(event) => setEndDate(event.target.value)} className="input-shell" />
          </div>

          <button 
            type="button" 
            onClick={async () => {
              if (!user?.id) {
                setStatusMessage("Please log in to generate reports.");
                return;
              }
              
              console.log("[Reports] Generate button clicked");
              setIsLoadingData(true);
              setStatusMessage("Generating report...");
              
              try {
                const data = await fetchSupabaseTransactions(user.id);
                console.log(`[Reports] Generate button received ${data.length} transactions`);
                setSupabaseTransactions(data);
                
                if (data.length === 0) {
                  setStatusMessage("No transactions found in Supabase for the selected range.");
                } else {
                  setStatusMessage(`Report generated: ${data.length} transactions loaded. Filtering by date range: ${periodLabel}`);
                }
              } catch (error) {
                console.error("[Reports] Error in generate button:", error);
                setStatusMessage("Error generating report. Check browser console for details.");
              } finally {
                setIsLoadingData(false);
              }
            }} 
            disabled={isLoadingData}
            className="rounded-full bg-[#d98e95] px-4 py-2 text-sm font-medium text-[#2f2122] disabled:opacity-60"
          >
            {isLoadingData ? "Generating..." : "Generate report"}
          </button>
        </div>

        <div className="mt-4 grid gap-3 md:grid-cols-3">
          <select value={categoryFilter} onChange={(event) => setCategoryFilter(event.target.value)} className="input-shell">
            <option value="All">All categories</option>
            {allCategories.map((category) => (
              <option key={category} value={category}>{category}</option>
            ))}
          </select>

          <select value={customerFilter} onChange={(event) => setCustomerFilter(event.target.value)} className="input-shell">
            <option value="All">All customers</option>
            {allCustomers.map((customer) => (
              <option key={customer} value={customer}>{customer}</option>
            ))}
          </select>

          <div className="rounded-[18px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] px-3 py-2 text-sm text-[#4b2d37]">
            {periodLabel}
          </div>
        </div>

        {statusMessage ? (
          <div className="mt-4 rounded-2xl border border-[#dfece5] bg-[#eefaf5] px-3 py-2 text-sm text-[#234d3d]">
            {statusMessage}
          </div>
        ) : null}
      </div>

      {!filteredTransactions.length ? (
        <div className="fabby-card rounded-[30px] p-8 text-center">
          {isLoadingData ? (
            <div className="flex flex-col items-center justify-center py-10">
              <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-[#2d1d1d] border-t-transparent"></div>
              <p className="text-sm text-[#5a4547]">Loading your financial data from Supabase...</p>
            </div>
          ) : (
            <>
              <div className="text-3xl font-semibold text-[#2d1d1d]">Your reports will appear here as you record income and expenses.</div>
              <p className="mt-3 text-[#5a4547]">Add income and expense records to generate insight-driven reports.</p>
              <div className="mt-6 flex justify-center gap-3">
                <button type="button" className="rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white">Add income</button>
                <button type="button" className="rounded-full border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] px-4 py-2 text-sm font-medium text-[#4b2d37]">Add expense</button>
              </div>
            </>
          )}
        </div>
      ) : (
        <>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            {[
              { label: "Total income", value: formatMoney(summary.income) },
              { label: "Total expenses", value: formatMoney(summary.expenses) },
              { label: "Net profit", value: formatMoney(summary.net) },
              { label: "Profit margin", value: `${summary.profitMargin.toFixed(1)}%` },
            ].map((card) => (
              <div key={card.label} className="fabby-card rounded-[26px] p-4">
                <div className="text-xs uppercase tracking-[0.16em] text-[#7a5f60]">{card.label}</div>
                <div className="mt-3 text-3xl font-semibold text-[#2d1d1d]">{card.value}</div>
              </div>
            ))}
          </div>

          <div className="grid gap-6 xl:grid-cols-[1.3fr_0.7fr]">
            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Income vs expenses</div>
              <div className="flex h-52 items-end gap-3">
                {[1, 2, 3, 4, 5].map((item) => {
                  const base = [summary.income, summary.expenses, summary.net][(item - 1) % 3] || 1;
                  const height = Math.max(14, (base / Math.max(chartMax, 1)) * 100);
                  const color = item % 2 === 0 ? "#d98e95" : "#f2c9c8";
                  return (
                    <div key={item} className="flex flex-1 flex-col items-center gap-2">
                      <div className="w-full rounded-t-full" style={{ height: `${Math.min(height, 100)}%`, background: color }} />
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">AI insight</div>
              <p className="text-base leading-7 text-[#422b2c]">{reportInsight}</p>
            </div>
          </div>

          <div className="grid gap-6 xl:grid-cols-2">
            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Income by category</div>
              <div className="space-y-3">
                {incomeByCategory.length ? (
                  incomeByCategory.slice(0, 5).map((item) => (
                    <div key={item.category}>
                      <div className="mb-1 flex items-center justify-between text-sm text-[#4c3738]">
                        <span>{item.category}</span>
                        <span>{formatMoney(item.amount)}</span>
                      </div>
                      <div className="h-2.5 rounded-full bg-[#f6e7e5]">
                        <div className="h-full rounded-full bg-[#d98e95]" style={{ width: `${(item.amount / Math.max(totalRevenueTrend, 1)) * 100}%` }} />
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-sm text-[#604a4b]">No income categories in this range.</div>
                )}
              </div>
            </div>

            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Expense by category</div>
              <div className="space-y-3">
                {expenseByCategory.length ? (
                  expenseByCategory.slice(0, 5).map((item) => (
                    <div key={item.category}>
                      <div className="mb-1 flex items-center justify-between text-sm text-[#4c3738]">
                        <span>{item.category}</span>
                        <span>{formatMoney(item.amount)}</span>
                      </div>
                      <div className="h-2.5 rounded-full bg-[#f6e7e5]">
                        <div className="h-full rounded-full bg-[#bd7e76]" style={{ width: `${(item.amount / Math.max(summary.expenses || 1, 1)) * 100}%` }} />
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-sm text-[#604a4b]">No expense data in this range.</div>
                )}
              </div>
            </div>
          </div>

          <div className="fabby-card rounded-[30px] p-5">
            <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">{REPORT_TYPES.find((option) => option.value === reportType)?.label}</div>
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
              {reportRows.map((row) => (
                <button
                  key={row.label}
                  type="button"
                  onClick={() => setStatusMessage(`${row.label}: ${row.value}`)}
                  className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 text-left"
                >
                  <div className="text-xs uppercase tracking-[0.16em] text-[#7a5f60]">{row.label}</div>
                  <div className="mt-2 text-xl font-semibold text-[#2d1d1d]">{row.value}</div>
                </button>
              ))}
            </div>
          </div>

          <div className="fabby-card rounded-[30px] p-5">
            <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Underlying records</div>
            <div className="overflow-x-auto rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8]">
              <table className="min-w-full text-left text-sm">
                <thead className="bg-[#fdf1ee] text-[#584245]">
                  <tr>
                    <th className="px-4 py-3">Date</th>
                    <th className="px-4 py-3">Type</th>
                    <th className="px-4 py-3">Category</th>
                    <th className="px-4 py-3">Customer / payer</th>
                    <th className="px-4 py-3">Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredTransactions.slice(0, 10).map((record) => (
                    <tr key={`${record.type}-${record.id}`} className="border-t border-[rgba(109,69,71,0.06)]">
                      <td className="px-4 py-3">{record.date}</td>
                      <td className="px-4 py-3">{record.type}</td>
                      <td className="px-4 py-3">{record.category}</td>
                      <td className="px-4 py-3">{record.customer ?? record.vendor ?? ""}</td>
                      <td className={`px-4 py-3 font-semibold ${record.type === "Income" ? "text-[#2f7f67]" : "text-[#3a2c2d]"}`}>
                        {record.type === "Income" ? "+" : "-"}
                        {formatMoney(record.amount)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {savedReports.length > 0 && (
            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-4 flex items-center justify-between">
                <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Saved reports</div>
                <div className="text-xs text-[#6f5557]">{savedReports.length} saved</div>
              </div>

              <div className="space-y-3">
                {savedReports.map((report) => (
                  <div key={report.id} className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-3">
                    <div className="flex items-center justify-between gap-3">
                      <div>
                        <div className="font-medium text-[#2d1d1d]">{report.label}</div>
                        <div className="text-xs text-[#6f5557]">{new Date(report.generatedAt).toLocaleDateString()} • {report.filters.category}</div>
                      </div>
                      <div className="flex gap-2">
                        <button type="button" onClick={() => setSelectedSavedReport(report.id)} className="text-xs font-medium text-[#4b2d37]">View</button>
                        <button type="button" onClick={() => deleteSavedReport(report.id)} className="text-xs font-medium text-[#9c4d4d]">Delete</button>
                      </div>
                    </div>
                    {selectedSavedReport === report.id ? (
                      <div className="mt-3 rounded-2xl bg-[#f7e6e5] p-3 text-sm text-[#3f2a2c]">
                        {formatMoney(report.summary.income)} income • {formatMoney(report.summary.expenses)} expenses • {formatMoney(report.summary.net)} net
                      </div>
                    ) : null}
                  </div>
                ))}
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}
