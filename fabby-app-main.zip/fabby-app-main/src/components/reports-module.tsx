"use client";

import { useEffect, useState, useMemo } from "react";
import { createBrowserClient } from "@/lib/supabase/client";
import { useAuth } from "@/contexts/auth-context";

type Transaction = {
  id: string;
  user_id: string;
  type: "Income" | "Expense";
  amount: number;
  category: string;
  date: string;
  description: string;
  notes: string;
  status: string;
  created_at: string;
  updated_at: string;
  money_type: "Business" | "Personal" | "Unclassified";
};

type ReportData = {
  totalIncome: number;
  totalExpenses: number;
  netProfit: number;
  profitMargin: number;
  incomeByCategory: { category: string; amount: number }[];
  expenseByCategory: { category: string; amount: number }[];
  transactionCount: number;
  dateRange: { start: string; end: string };
};

const CURRENCY_FORMATTER = new Intl.NumberFormat("en-NG", {
  style: "currency",
  currency: "NGN",
  maximumFractionDigits: 0,
});

function formatMoney(amount: number): string {
  return CURRENCY_FORMATTER.format(amount);
}

function getMonthDateRange(monthOffset = 0): { start: string; end: string } {
  const now = new Date();
  const year = now.getFullYear();
  const month = now.getMonth() + monthOffset;
  
  const start = new Date(year, month, 1);
  const end = new Date(year, month + 1, 0, 23, 59, 59);
  
  return {
    start: start.toISOString().split("T")[0],
    end: end.toISOString().split("T")[0],
  };
}

async function fetchTransactionsFromSupabase(userId: string): Promise<Transaction[]> {
  try {
    const supabase = createBrowserClient();
    const { data, error } = await supabase
      .from("transactions")
      .select("*")
      .eq("user_id", userId)
      .order("date", { ascending: false });

    if (error) {
      console.error("[Reports V2] Supabase error:", error);
      return [];
    }

    console.log(`[Reports V2] Fetched ${data?.length || 0} transactions from Supabase`);
    return data as Transaction[];
  } catch (error) {
    console.error("[Reports V2] Exception:", error);
    return [];
  }
}

function fetchTransactionsFromLocalStorage(): Transaction[] {
  try {
    if (typeof window === "undefined") return [];

    const combined: Transaction[] = [];

    // Try to fetch from income records
    const incomeRaw = window.localStorage.getItem("fabby-income-records");
    if (incomeRaw) {
      try {
        const incomeData = JSON.parse(incomeRaw);
        const records = Array.isArray(incomeData) ? incomeData : Object.values(incomeData || {});
        
        for (const record of records) {
          if (record && typeof record === "object") {
            combined.push({
              id: record.id || `income-${Math.random()}`,
              user_id: record.userId || "local-user",
              type: "Income" as const,
              amount: Number(record.amount || 0),
              category: record.category || "Uncategorized",
              date: record.date || new Date().toISOString().split("T")[0],
              description: record.description || "",
              notes: record.notes || "",
              status: record.status || "Completed",
              created_at: record.createdAt || new Date().toISOString(),
              updated_at: record.updatedAt || new Date().toISOString(),
              money_type: "Business" as const,
            });
          }
        }
      } catch (e) {
        console.error("[Reports V2] Failed to parse income records:", e);
      }
    }

    // Try to fetch from expense records
    const expenseRaw = window.localStorage.getItem("fabby-expense-records");
    if (expenseRaw) {
      try {
        const expenseData = JSON.parse(expenseRaw);
        const records = Array.isArray(expenseData) ? expenseData : Object.values(expenseData || {});
        
        for (const record of records) {
          if (record && typeof record === "object") {
            combined.push({
              id: record.id || `expense-${Math.random()}`,
              user_id: record.userId || "local-user",
              type: "Expense" as const,
              amount: Number(record.amount || 0),
              category: record.category || "Uncategorized",
              date: record.date || new Date().toISOString().split("T")[0],
              description: record.description || "",
              notes: record.notes || "",
              status: record.status || "Completed",
              created_at: record.createdAt || new Date().toISOString(),
              updated_at: record.updatedAt || new Date().toISOString(),
              money_type: "Business" as const,
            });
          }
        }
      } catch (e) {
        console.error("[Reports V2] Failed to parse expense records:", e);
      }
    }

    console.log(`[Reports V2] Fetched ${combined.length} transactions from localStorage`);
    return combined;
  } catch (error) {
    console.error("[Reports V2] Exception in localStorage fetch:", error);
    return [];
  }
}

function generateReportData(transactions: Transaction[], startDate: string, endDate: string): ReportData {
  console.log(`[Reports V2] Generating report for ${startDate} to ${endDate}`);

  // Filter by date range
  const filtered = transactions.filter((tx) => {
    const txDate = tx.date;
    return txDate >= startDate && txDate <= endDate;
  });

  console.log(`[Reports V2] ${filtered.length} transactions in range`);

  // Calculate totals
  let totalIncome = 0;
  let totalExpenses = 0;
  const incomeByCategory = new Map<string, number>();
  const expenseByCategory = new Map<string, number>();

  for (const tx of filtered) {
    const amount = Number(tx.amount) || 0;

    if (tx.type === "Income") {
      totalIncome += amount;
      incomeByCategory.set(tx.category, (incomeByCategory.get(tx.category) || 0) + amount);
    } else if (tx.type === "Expense") {
      totalExpenses += amount;
      expenseByCategory.set(tx.category, (expenseByCategory.get(tx.category) || 0) + amount);
    }
  }

  const netProfit = totalIncome - totalExpenses;
  const profitMargin = totalIncome === 0 ? 0 : (netProfit / totalIncome) * 100;

  return {
    totalIncome,
    totalExpenses,
    netProfit,
    profitMargin,
    incomeByCategory: Array.from(incomeByCategory.entries())
      .map(([category, amount]) => ({ category, amount }))
      .sort((a, b) => b.amount - a.amount),
    expenseByCategory: Array.from(expenseByCategory.entries())
      .map(([category, amount]) => ({ category, amount }))
      .sort((a, b) => b.amount - a.amount),
    transactionCount: filtered.length,
    dateRange: { start: startDate, end: endDate },
  };
}

function exportToCSV(transactions: Transaction[], dateRange: { start: string; end: string }): void {
  const filtered = transactions.filter((tx) => tx.date >= dateRange.start && tx.date <= dateRange.end);

  if (filtered.length === 0) {
    alert("No transactions to export in this date range.");
    return;
  }

  // Create CSV header
  const headers = ["Date", "Type", "Category", "Description", "Amount", "Status"];
  const rows = [headers];

  // Add transaction rows
  for (const tx of filtered) {
    rows.push([tx.date, tx.type, tx.category, tx.description, String(tx.amount), tx.status]);
  }

  // Convert to CSV string
  const csvContent = rows.map((row) => row.map((cell) => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\n");

  // Create blob and download
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `financial-report-${dateRange.start}-to-${dateRange.end}.csv`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(link.href);

  console.log(`[Reports V2] Exported ${filtered.length} transactions to CSV`);
}

function exportToPDF(transactions: Transaction[], report: ReportData | null, dateRange: { start: string; end: string }): void {
  const filtered = transactions.filter((tx) => tx.date >= dateRange.start && tx.date <= dateRange.end);

  if (filtered.length === 0) {
    alert("No transactions to export in this date range.");
    return;
  }

  // Simple text-based PDF generation
  const lines: string[] = [
    "FABBY FINANCIAL REPORT",
    "=".repeat(50),
    "",
    `Period: ${dateRange.start} to ${dateRange.end}`,
    "",
  ];

  if (report) {
    lines.push("SUMMARY");
    lines.push("-".repeat(50));
    lines.push(`Total Income: ${formatMoney(report.totalIncome)}`);
    lines.push(`Total Expenses: ${formatMoney(report.totalExpenses)}`);
    lines.push(`Net Profit: ${formatMoney(report.netProfit)}`);
    lines.push(`Profit Margin: ${report.profitMargin.toFixed(1)}%`);
    lines.push("");
  }

  lines.push("TRANSACTIONS");
  lines.push("-".repeat(50));
  lines.push("");

  for (const tx of filtered) {
    lines.push(`Date: ${tx.date}`);
    lines.push(`Type: ${tx.type}`);
    lines.push(`Category: ${tx.category}`);
    lines.push(`Description: ${tx.description}`);
    lines.push(`Amount: ${formatMoney(tx.amount)}`);
    lines.push(`Status: ${tx.status}`);
    lines.push("");
  }

  lines.push("=".repeat(50));
  lines.push(`Generated: ${new Date().toLocaleString()}`);
  lines.push("Powered by FABBY - Financial Management System");

  const content = lines.join("\n");

  // Create blob and download as text (most browsers will handle as PDF if extension is .pdf)
  const blob = new Blob([content], { type: "application/pdf" });
  const link = document.createElement("a");
  link.href = URL.createObjectURL(blob);
  link.download = `financial-report-${dateRange.start}-to-${dateRange.end}.pdf`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(link.href);

  console.log(`[Reports V2] Exported ${filtered.length} transactions to PDF`);
}

export function ReportsModule() {
  const { user, isLoading: authLoading } = useAuth();
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [reportMonth, setReportMonth] = useState(0); // 0 = this month, -1 = last month, etc.
  const dateRange = useMemo(() => getMonthDateRange(reportMonth), [reportMonth]);

  // Fetch transactions on mount and when user changes
  useEffect(() => {
    const loadTransactions = async () => {
      console.log("[Reports V2] Fetching transactions...");
      setLoading(true);
      setError(null);

      try {
        // Try Supabase first
        const supabaseData = await fetchTransactionsFromSupabase(user?.id || "");
        let data = supabaseData;

        // Fall back to localStorage if Supabase is empty
        if (data.length === 0) {
          console.log("[Reports V2] Supabase empty, trying localStorage");
          data = fetchTransactionsFromLocalStorage();
        }

        setTransactions(data);

        if (data.length === 0) {
          setError("No transactions found. Add income or expenses to see reports.");
        }
      } catch (err) {
        const message = err instanceof Error ? err.message : "Failed to load transactions";
        console.error("[Reports V2] Load error:", err);
        setError(message);
      } finally {
        setLoading(false);
      }
    };

    void loadTransactions();
  }, [user?.id]);

  const report = useMemo(() => {
    if (transactions.length === 0) {
      return null;
    }
    return generateReportData(transactions, dateRange.start, dateRange.end);
  }, [transactions, dateRange]);

  const handleRefresh = async () => {
    console.log("[Reports V2] Manual refresh triggered");
    setLoading(true);
    setError(null);

    try {
      // Try Supabase first
      let data = await fetchTransactionsFromSupabase(user?.id || "");

      // Fall back to localStorage if Supabase is empty
      if (data.length === 0) {
        console.log("[Reports V2] Refresh: Supabase empty, trying localStorage");
        data = fetchTransactionsFromLocalStorage();
      }

      setTransactions(data);
      if (data.length === 0) {
        setError("No transactions found.");
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Refresh failed";
      console.error("[Reports V2] Refresh error:", err);
      setError(message);
    } finally {
      setLoading(false);
    }
  };

  const handlePreviousMonth = () => setReportMonth((m) => m - 1);
  const handleNextMonth = () => setReportMonth((m) => m + 1);
  const handleThisMonth = () => setReportMonth(0);

  if (authLoading) {
    return (
      <div className="fabby-card rounded-[30px] p-8 text-center">
        <div className="flex flex-col items-center justify-center py-10">
          <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-[#2d1d1d] border-t-transparent"></div>
          <p className="text-sm text-[#5a4547]">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header Section */}
      <div className="fabby-card rounded-[30px] p-5 md:p-6">
        <div className="mb-6 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Reports</div>
            <h2 className="mt-2 text-3xl font-semibold text-[#2d1d1d]">Financial Reporting</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={() => exportToCSV(transactions, dateRange)}
              disabled={loading || transactions.length === 0}
              className="rounded-full border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] px-4 py-2 text-sm font-medium text-[#4b2d37] disabled:opacity-50"
            >
              📥 Export CSV
            </button>
            <button
              type="button"
              onClick={() => exportToPDF(transactions, report, dateRange)}
              disabled={loading || transactions.length === 0}
              className="rounded-full border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] px-4 py-2 text-sm font-medium text-[#4b2d37] disabled:opacity-50"
            >
              📄 Export PDF
            </button>
            <button
              type="button"
              onClick={handleRefresh}
              disabled={loading}
              className="rounded-full bg-[#d98e95] px-6 py-2 text-sm font-medium text-[#2f2122] disabled:opacity-60"
            >
              {loading ? "Loading..." : "Refresh Data"}
            </button>
          </div>
        </div>

        {/* Month Navigation */}
        <div className="mb-6 flex items-center justify-between rounded-[18px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
          <button
            type="button"
            onClick={handlePreviousMonth}
            className="text-sm font-medium text-[#4b2d37] hover:text-[#2d1d1d]"
          >
            ← Previous
          </button>
          <div className="text-center">
            <div className="text-xs uppercase tracking-[0.16em] text-[#7a5f60]">Report Period</div>
            <div className="mt-1 text-sm font-medium text-[#2d1d1d]">
              {dateRange.start} to {dateRange.end}
            </div>
          </div>
          <div className="flex gap-2">
            {reportMonth !== 0 && (
              <button
                type="button"
                onClick={handleThisMonth}
                className="text-sm font-medium text-[#4b2d37] hover:text-[#2d1d1d]"
              >
                This Month
              </button>
            )}
            <button
              type="button"
              onClick={handleNextMonth}
              disabled={reportMonth >= 0}
              className="text-sm font-medium text-[#4b2d37] hover:text-[#2d1d1d] disabled:opacity-50"
            >
              Next →
            </button>
          </div>
        </div>

        {/* Error Display */}
        {error && (
          <div className="rounded-2xl border border-[#f5d5d0] bg-[#fde8e4] p-3 text-sm text-[#9c4d4d]">
            {error}
          </div>
        )}
      </div>

      {/* Report Content */}
      {loading ? (
        <div className="fabby-card rounded-[30px] p-8 text-center">
          <div className="flex flex-col items-center justify-center py-10">
            <div className="mb-4 h-8 w-8 animate-spin rounded-full border-4 border-[#2d1d1d] border-t-transparent"></div>
            <p className="text-sm text-[#5a4547]">Loading financial data...</p>
          </div>
        </div>
      ) : !report ? (
        <div className="fabby-card rounded-[30px] p-8 text-center">
          <div className="text-2xl font-semibold text-[#2d1d1d]">No data available</div>
          <p className="mt-2 text-[#5a4547]">Add income and expense records to generate reports.</p>
        </div>
      ) : (
        <>
          {/* Summary Cards */}
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
            <div className="fabby-card rounded-[26px] p-4">
              <div className="text-xs uppercase tracking-[0.16em] text-[#7a5f60]">Total Income</div>
              <div className="mt-3 text-3xl font-semibold text-[#2d1d1d]">{formatMoney(report.totalIncome)}</div>
            </div>
            <div className="fabby-card rounded-[26px] p-4">
              <div className="text-xs uppercase tracking-[0.16em] text-[#7a5f60]">Total Expenses</div>
              <div className="mt-3 text-3xl font-semibold text-[#2d1d1d]">{formatMoney(report.totalExpenses)}</div>
            </div>
            <div className="fabby-card rounded-[26px] p-4">
              <div className="text-xs uppercase tracking-[0.16em] text-[#7a5f60]">Net Profit</div>
              <div className={`mt-3 text-3xl font-semibold ${report.netProfit >= 0 ? "text-[#2f7f67]" : "text-[#9c4d4d]"}`}>
                {formatMoney(report.netProfit)}
              </div>
            </div>
            <div className="fabby-card rounded-[26px] p-4">
              <div className="text-xs uppercase tracking-[0.16em] text-[#7a5f60]">Profit Margin</div>
              <div className="mt-3 text-3xl font-semibold text-[#2d1d1d]">{report.profitMargin.toFixed(1)}%</div>
            </div>
          </div>

          {/* Categories Breakdown */}
          <div className="grid gap-6 xl:grid-cols-2">
            {/* Income by Category */}
            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Income by Category</div>
              {report.incomeByCategory.length > 0 ? (
                <div className="space-y-3">
                  {report.incomeByCategory.map((item) => (
                    <div key={item.category}>
                      <div className="mb-1 flex items-center justify-between text-sm text-[#4c3738]">
                        <span>{item.category}</span>
                        <span>{formatMoney(item.amount)}</span>
                      </div>
                      <div className="h-2.5 rounded-full bg-[#f6e7e5]">
                        <div
                          className="h-full rounded-full bg-[#d98e95]"
                          style={{
                            width: `${(item.amount / Math.max(report.totalIncome, 1)) * 100}%`,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-[#604a4b]">No income in this period.</p>
              )}
            </div>

            {/* Expense by Category */}
            <div className="fabby-card rounded-[30px] p-5">
              <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Expenses by Category</div>
              {report.expenseByCategory.length > 0 ? (
                <div className="space-y-3">
                  {report.expenseByCategory.map((item) => (
                    <div key={item.category}>
                      <div className="mb-1 flex items-center justify-between text-sm text-[#4c3738]">
                        <span>{item.category}</span>
                        <span>{formatMoney(item.amount)}</span>
                      </div>
                      <div className="h-2.5 rounded-full bg-[#f6e7e5]">
                        <div
                          className="h-full rounded-full bg-[#bd7e76]"
                          style={{
                            width: `${(item.amount / Math.max(report.totalExpenses, 1)) * 100}%`,
                          }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-[#604a4b]">No expenses in this period.</p>
              )}
            </div>
          </div>

          {/* Transaction Summary */}
          <div className="fabby-card rounded-[30px] p-5">
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Summary</div>
            <div className="mt-4 grid gap-4 md:grid-cols-3">
              <div className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
                <div className="text-xs uppercase tracking-[0.16em] text-[#7a5f60]">Total Transactions</div>
                <div className="mt-2 text-2xl font-semibold text-[#2d1d1d]">{report.transactionCount}</div>
              </div>
              <div className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
                <div className="text-xs uppercase tracking-[0.16em] text-[#7a5f60]">Avg Transaction</div>
                <div className="mt-2 text-2xl font-semibold text-[#2d1d1d]">
                  {report.transactionCount > 0
                    ? formatMoney((report.totalIncome + report.totalExpenses) / report.transactionCount)
                    : "N/A"}
                </div>
              </div>
              <div className="rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
                <div className="text-xs uppercase tracking-[0.16em] text-[#7a5f60]">Period</div>
                <div className="mt-2 text-xs font-semibold text-[#2d1d1d]">
                  {dateRange.start}
                  <br />
                  to {dateRange.end}
                </div>
              </div>
            </div>
          </div>

          {/* Insights */}
          <div className="fabby-card rounded-[30px] p-5">
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Key Insights</div>
            <div className="mt-4 space-y-3 text-sm text-[#422b2c]">
              <p>
                📊 <strong>Financial Health:</strong>{" "}
                {report.profitMargin >= 20
                  ? "Your profit margin is healthy!"
                  : report.profitMargin >= 0
                    ? "Your profit margin is positive but room for improvement."
                    : "You're operating at a loss. Review your expenses."}
              </p>
              {report.incomeByCategory.length > 0 && (
                <p>
                  💰 <strong>Top Income Source:</strong> {report.incomeByCategory[0].category} (
                  {formatMoney(report.incomeByCategory[0].amount)})
                </p>
              )}
              {report.expenseByCategory.length > 0 && (
                <p>
                  💸 <strong>Largest Expense:</strong> {report.expenseByCategory[0].category} (
                  {formatMoney(report.expenseByCategory[0].amount)})
                </p>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
