"use client";

import { useEffect, useMemo, useState } from "react";
import { getMoneySummary, getMoneyTypeSuggestions, getPotentialMixingWarnings, type LedgerEntry, type MoneyType } from "@/lib/financial-ledger";

const currency = new Intl.NumberFormat("en-NG", {
  style: "currency",
  currency: "NGN",
  maximumFractionDigits: 0,
});

function formatMoney(value: number) {
  return currency.format(value);
}

export function MoneySeparationModule({
  entries: initialEntries = [],
  onAddEntry,
  onUpdateEntry,
  onDeleteEntry,
  userId,
}: {
  entries?: LedgerEntry[];
  onAddEntry?: (entry: LedgerEntry) => Promise<boolean>;
  onUpdateEntry?: (entryId: string, updates: Partial<LedgerEntry>) => Promise<boolean>;
  onDeleteEntry?: (entryId: string) => Promise<boolean>;
  userId?: string;
} = {}) {
  const [entries, setEntries] = useState<LedgerEntry[]>(initialEntries);
  const [view, setView] = useState<"All" | "Business" | "Personal">("All");
  const [ledgerFilter, setLedgerFilter] = useState<"All" | MoneyType>("All");
  const [draft, setDraft] = useState({
    type: "Expense" as "Income" | "Expense",
    amount: "",
    date: new Date().toISOString().slice(0, 10),
    category: "General",
    description: "",
    moneyType: "Business" as MoneyType,
  });

  useEffect(() => {
    // persistLedgerEntries(entries, "user-id");
  }, [entries]);

  const summary = useMemo(() => getMoneySummary(entries), [entries]);
  const warnings = useMemo(() => getPotentialMixingWarnings(entries), [entries]);

  const visibleEntries = useMemo(() => {
    return entries.filter((entry) => {
      const matchesView = view === "All" || entry.moneyType === view;
      const matchesLedger = ledgerFilter === "All" || entry.moneyType === ledgerFilter;
      return matchesView && matchesLedger;
    });
  }, [entries, ledgerFilter, view]);

  const updateEntryMoneyType = (id: string, moneyType: MoneyType) => {
    setEntries((current) =>
      current.map((entry) =>
        entry.id === id
          ? {
              ...entry,
              moneyType,
              updatedAt: new Date().toISOString(),
            }
          : entry,
      ),
    );
  };

  const suggestedMoneyType = useMemo(
    () => getMoneyTypeSuggestions({
      description: draft.description,
      category: draft.category,
      customer: "",
      vendor: "",
    }),
    [draft.category, draft.description],
  );

  const addLedgerEntry = async () => {
    if (!draft.amount || Number(draft.amount) <= 0 || !draft.description.trim()) return;
    if (!userId) {
      console.error("Business vs Personal save blocked: no authenticated user.");
      return;
    }

    const nextEntry: LedgerEntry = {
      userId,
      id: `manual-${Date.now()}`,
      type: draft.type,
      amount: Number(draft.amount),
      category: draft.category,
      date: draft.date,
      description: draft.description,
      moneyType: draft.moneyType,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    if (onAddEntry) {
      const didAdd = await onAddEntry(nextEntry);
      if (didAdd) {
        setEntries((current) => [nextEntry, ...current]);
      }
    } else {
      setEntries((current) => [nextEntry, ...current]);
    }

    setDraft({
      type: "Expense",
      amount: "",
      date: new Date().toISOString().slice(0, 10),
      category: "General",
      description: "",
      moneyType: "Business",
    });
  };

  const businessCards = [
    { label: "Business income", value: formatMoney(summary.businessIncome) },
    { label: "Business expenses", value: formatMoney(summary.businessExpenses) },
    { label: "Business net cash flow", value: formatMoney(summary.businessNet) },
    { label: "Business profit", value: formatMoney(summary.businessNet) },
    { label: "Business transaction count", value: String(entries.filter((entry) => entry.moneyType === "Business").length) },
  ];

  const personalCards = [
    { label: "Personal income", value: formatMoney(summary.personalIncome) },
    { label: "Personal expenses", value: formatMoney(summary.personalExpenses) },
    { label: "Personal net cash flow", value: formatMoney(summary.personalNet) },
    { label: "Personal transaction count", value: String(entries.filter((entry) => entry.moneyType === "Personal").length) },
  ];

  const totalCards = [
    { label: "Combined income", value: formatMoney(summary.totalIncome) },
    { label: "Combined expenses", value: formatMoney(summary.totalExpenses) },
    { label: "Combined cash flow", value: formatMoney(summary.totalNet) },
  ];

  return (
    <div className="space-y-6">
      <div className="fabby-card rounded-[30px] p-5">
        <div className="mb-4 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Business vs Personal</div>
            <h2 className="mt-2 text-3xl font-semibold text-[#2d1d1d]">Money separation</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {(["All", "Business", "Personal"] as const).map((option) => (
              <button
                key={option}
                type="button"
                onClick={() => setView(option)}
                className={`rounded-full px-3 py-1.5 text-sm font-medium ${
                  view === option ? "bg-[#2d1d1d] text-white" : "border border-[rgba(109,69,71,0.12)] bg-[#fffaf8] text-[#4b2d37]"
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          <div className="rounded-[26px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Business</div>
            <div className="mt-4 space-y-2 text-sm text-[#422d30]">
              {businessCards.map((card) => (
                <div key={card.label} className="flex items-center justify-between gap-3">
                  <span>{card.label}</span>
                  <span className="font-semibold text-[#2d1d1d]">{card.value}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-[26px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Personal</div>
            <div className="mt-4 space-y-2 text-sm text-[#422d30]">
              {personalCards.map((card) => (
                <div key={card.label} className="flex items-center justify-between gap-3">
                  <span>{card.label}</span>
                  <span className="font-semibold text-[#2d1d1d]">{card.value}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="rounded-[26px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
            <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Total</div>
            <div className="mt-4 space-y-2 text-sm text-[#422d30]">
              {totalCards.map((card) => (
                <div key={card.label} className="flex items-center justify-between gap-3">
                  <span>{card.label}</span>
                  <span className="font-semibold text-[#2d1d1d]">{card.value}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {warnings.length > 0 && (
        <div className="fabby-card rounded-[30px] p-5">
          <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Possible classification issues</div>
          <div className="space-y-3">
            {warnings.map((warning) => (
              <div key={warning.id} className="rounded-[20px] border border-[#f0dac2] bg-[#fff8ef] p-4 text-sm text-[#4c352d]">
                <div className="font-semibold text-[#3f2a2c]">{warning.title}</div>
                <div className="mt-2 leading-6">{warning.detail}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="fabby-card rounded-[30px] p-5">
        <div className="mb-4 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Add transaction</div>
        <div className="grid gap-3 md:grid-cols-6">
          <select value={draft.type} onChange={(event) => setDraft((current) => ({ ...current, type: event.target.value as "Income" | "Expense" }))} className="input-shell">
            <option value="Income">Income</option>
            <option value="Expense">Expense</option>
          </select>
          <input type="number" min="0" value={draft.amount} onChange={(event) => setDraft((current) => ({ ...current, amount: event.target.value }))} placeholder="Amount" className="input-shell" />
          <input type="date" value={draft.date} onChange={(event) => setDraft((current) => ({ ...current, date: event.target.value }))} className="input-shell" />
          <input value={draft.category} onChange={(event) => setDraft((current) => ({ ...current, category: event.target.value }))} placeholder="Category" className="input-shell" />
          <input value={draft.description} onChange={(event) => setDraft((current) => ({ ...current, description: event.target.value }))} placeholder="Description" className="input-shell md:col-span-2" />
          <select value={draft.moneyType} onChange={(event) => setDraft((current) => ({ ...current, moneyType: event.target.value as MoneyType }))} className="input-shell">
            <option value="Business">Business</option>
            <option value="Personal">Personal</option>
            <option value="Unclassified">Unclassified</option>
          </select>
          <button type="button" onClick={addLedgerEntry} className="rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white md:col-span-1">
            Save
          </button>
        </div>

        {draft.description.trim() ? (
          <div className="mt-3 rounded-2xl border border-[#e9dccd] bg-[#fff8ef] px-3 py-2 text-sm text-[#4a362e]">
            Suggested classification: <span className="font-semibold">{suggestedMoneyType}</span>
          </div>
        ) : null}
      </div>

      <div className="fabby-card rounded-[30px] p-5">
        <div className="mb-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
          <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Ledger view</div>
          <select
            value={ledgerFilter}
            onChange={(event) => setLedgerFilter(event.target.value as "All" | MoneyType)}
            className="input-shell max-w-[180px]"
          >
            <option value="All">All money</option>
            <option value="Business">Business</option>
            <option value="Personal">Personal</option>
            <option value="Unclassified">Unclassified</option>
          </select>
        </div>

        <div className="overflow-x-auto rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8]">
          <table className="min-w-full text-left text-sm">
            <thead className="bg-[#fdf1ee] text-[#584245]">
              <tr>
                <th className="px-4 py-3">Date</th>
                <th className="px-4 py-3">Type</th>
                <th className="px-4 py-3">Description</th>
                <th className="px-4 py-3">Category</th>
                <th className="px-4 py-3">Amount</th>
                <th className="px-4 py-3">Money type</th>
              </tr>
            </thead>
            <tbody>
              {visibleEntries.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-6 text-center text-[#5e4748]">
                    No records match the selected money view.
                  </td>
                </tr>
              ) : (
                visibleEntries.map((entry) => (
                  <tr key={`${entry.id}-${entry.type}`} className="border-t border-[rgba(109,69,71,0.06)]">
                    <td className="px-4 py-3">{entry.date}</td>
                    <td className="px-4 py-3">{entry.type}</td>
                    <td className="px-4 py-3">{entry.description}</td>
                    <td className="px-4 py-3">{entry.category}</td>
                    <td className={`px-4 py-3 font-semibold ${entry.type === "Income" ? "text-[#2f7f67]" : "text-[#3a2c2d]"}`}>
                      {entry.type === "Income" ? "+" : "-"}
                      {formatMoney(entry.amount)}
                    </td>
                    <td className="px-4 py-3">
                      <select
                        value={entry.moneyType}
                        onChange={(event) => updateEntryMoneyType(entry.id, event.target.value as MoneyType)}
                        className="input-shell min-w-[150px]"
                      >
                        <option value="Business">Business</option>
                        <option value="Personal">Personal</option>
                        <option value="Unclassified">Unclassified</option>
                      </select>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
