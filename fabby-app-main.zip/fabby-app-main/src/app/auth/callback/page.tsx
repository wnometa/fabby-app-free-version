"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import { Suspense } from "react";
import { createBrowserClient } from "@/lib/supabase/client";

/**
 * Inner component that uses useSearchParams
 */
function AuthCallbackContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [message, setMessage] = useState("Processing your request...");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        const supabase = createBrowserClient();

        // Get the hash fragment which contains the session data
        // Supabase stores tokens in the URL hash
        const hash = window.location.hash;
        
        if (!hash) {
          // No session data in URL, redirect to login
          setMessage("Redirecting...");
          setTimeout(() => {
            router.push("/login");
          }, 1000);
          return;
        }

        // Parse the session from the hash
        // Supabase's ssr package should handle this automatically,
        // but we can check the session to verify
        const { data, error: sessionError } = await supabase!.auth.getSession();

        if (sessionError) {
          throw sessionError;
        }

        if (!data.session) {
          setError("Failed to establish a valid session. Please try again.");
          setTimeout(() => {
            router.push("/login");
          }, 3000);
          return;
        }

        // Check what type of callback this is
        const type = searchParams.get("type");

        if (type === "recovery") {
          // Password recovery - go to reset password page
          setMessage("Session verified. Redirecting to reset your password...");
          setTimeout(() => {
            router.push("/reset-password");
          }, 1500);
        } else if (type === "signup") {
          // Email confirmation after signup
          setMessage("Email verified! Redirecting to dashboard...");
          setTimeout(() => {
            router.push("/dashboard");
            router.refresh();
          }, 1500);
        } else {
          // Default - go to dashboard
          setMessage("Authentication successful! Redirecting...");
          setTimeout(() => {
            router.push("/dashboard");
            router.refresh();
          }, 1500);
        }
      } catch (err) {
        console.error("Auth callback error:", err);
        setError(
          err instanceof Error ? err.message : "An error occurred during authentication.",
        );
      }
    };

    handleAuthCallback();
  }, [router, searchParams]);

  return (
    <div className="fabby-shell flex items-center justify-center px-4 py-10 min-h-screen">
      <div className="w-full max-w-md rounded-[28px] border border-[rgba(109,69,71,0.08)] bg-[rgba(255,250,248,0.9)] p-6 shadow-[0_30px_80px_rgba(101,66,67,0.08)] backdrop-blur-sm md:p-8">
        <div className="text-center">
          {error ? (
            <>
              <div className="mb-4 text-4xl">❌</div>
              <h1 className="text-2xl font-semibold tracking-tight text-[#2d1d1d]">
                Authentication Error
              </h1>
              <p className="mt-4 text-sm text-[#6d5255]">{error}</p>
              <a
                href="/login"
                className="mt-6 inline-block rounded-full bg-[#2d1d1d] px-6 py-2 text-sm font-medium text-white hover:bg-[#1a0f10]"
              >
                Back to Login
              </a>
            </>
          ) : (
            <>
              <div className="mb-4 flex justify-center">
                <div className="h-10 w-10 animate-spin rounded-full border-4 border-[#2d1d1d] border-t-transparent"></div>
              </div>
              <h1 className="text-xl font-semibold tracking-tight text-[#2d1d1d]">FABBY</h1>
              <p className="mt-4 text-sm text-[#6d5255]">{message}</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

/**
 * Main page component wrapped in Suspense to handle useSearchParams
 */
export default function AuthCallbackPage() {
  return (
    <Suspense fallback={
      <div className="fabby-shell flex items-center justify-center px-4 py-10 min-h-screen">
        <div className="w-full max-w-md rounded-[28px] border border-[rgba(109,69,71,0.08)] bg-[rgba(255,250,248,0.9)] p-6 shadow-[0_30px_80px_rgba(101,66,67,0.08)] backdrop-blur-sm md:p-8">
          <div className="text-center">
            <div className="mb-4 flex justify-center">
              <div className="h-10 w-10 animate-spin rounded-full border-4 border-[#2d1d1d] border-t-transparent"></div>
            </div>
            <h1 className="text-xl font-semibold tracking-tight text-[#2d1d1d]">FABBY</h1>
            <p className="mt-4 text-sm text-[#6d5255]">Loading...</p>
          </div>
        </div>
      </div>
    }>
      <AuthCallbackContent />
    </Suspense>
  );
}
