"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { BrandFooter, BrandLogo } from "@/components/brand";
import { ExpensesModule } from "@/components/expenses-module";
import { IncomeModule } from "@/components/income-module";
import { InsightsModule } from "@/components/insights-module";
import { MoneySeparationModule } from "@/components/money-separation-module";
import { ReportsModule } from "@/components/reports-module";
import { SettingsModule } from "@/components/settings-module";
import { useAuth } from "@/contexts/auth-context";
import { signOut } from "@/lib/auth";
import {
  createContributionRecord,
  createGoalRecord,
  getGoalMetrics,
  readGoalContributions,
  readGoals,
  saveGoalContributions,
  saveGoals,
  type Goal,
  type GoalContribution,
} from "@/lib/goals";
import { readSettings } from "@/lib/settings";
import { createBrowserClient } from "@/lib/supabase/client";
import { type LedgerEntry, type MoneyType } from "@/lib/financial-ledger";
import { type IncomeRecord } from "@/lib/income";

type Section =
  | "Ask FABBY"
  | "Income"
  | "Expenses"
  | "Invoices"
  | "Reports"
  | "Insights"
  | "Goals"
  | "Business vs Personal"
  | "Settings";

type TxType = "Income" | "Expense";
type BusinessType = "Business" | "Personal" | "Needs Review";

type Transaction = {
  id: string;
  date: string;
  description: string;
  type: TxType;
  category: string;
  amount: number;
  businessType: BusinessType;
  status: "Recorded" | "Needs Review";
  notes: string;
};

type Invoice = {
  id: string;
  customer: string;
  amount: number;
  dueDate: string;
  status: "Paid" | "Unpaid" | "Overdue";
};

type ChatMessage = {
  id: string;
  role: "assistant" | "user";
  content: string;
};

type TransactionRow = {
  id: string;
  date: string;
  description: string;
  type: TxType;
  category: string;
  amount: number;
  money_type: "Business" | "Personal" | "Unclassified";
  status: string;
  notes: string;
  created_at: string;
  updated_at: string;
};

type InvoiceRow = {
  id: string;
  customer: string;
  amount: number;
  due_date: string;
  status: "Paid" | "Unpaid" | "Overdue";
  created_at: string;
  updated_at: string;
};

const navItems: Section[] = [
  "Ask FABBY",
  "Expenses",
  "Income",
  "Invoices",
  "Business vs Personal",
  "Reports",
  "Insights",
  "Goals",
  "Settings",
];

const currency = new Intl.NumberFormat("en-NG", {
  style: "currency",
  currency: "NGN",
  maximumFractionDigits: 0,
});

function formatMoney(value: number) {
  return currency.format(value);
}

function getTodayISO() {
  return new Date().toISOString().slice(0, 10);
}

function calculateRecentTotals(transactions: Transaction[]) {
  const revenue = transactions
    .filter((transaction) => transaction.type === "Income")
    .reduce((sum, transaction) => sum + transaction.amount, 0);

  const expenses = transactions
    .filter((transaction) => transaction.type === "Expense")
    .reduce((sum, transaction) => sum + transaction.amount, 0);

  const net = revenue - expenses;
  const margin = revenue === 0 ? 0 : (net / revenue) * 100;

  return { revenue, expenses, net, margin };
}

function inferCategory(text: string): string {
  const normalized = text.toLowerCase();

  if (normalized.includes("stock") || normalized.includes("inventory")) return "Inventory";
  if (normalized.includes("ad") || normalized.includes("advert") || normalized.includes("marketing")) return "Marketing";
  if (normalized.includes("transport") || normalized.includes("delivery") || normalized.includes("fuel")) return "Transportation";
  if (normalized.includes("food") || normalized.includes("meal") || normalized.includes("dinner")) return "Food";
  if (normalized.includes("software") || normalized.includes("app") || normalized.includes("subscription")) return "Software";
  if (normalized.includes("rent") || normalized.includes("lease")) return "Rent";
  if (normalized.includes("salary") || normalized.includes("payroll")) return "Salaries";
  if (normalized.includes("internet") || normalized.includes("wifi")) return "Internet";
  if (normalized.includes("utility") || normalized.includes("electric") || normalized.includes("water")) return "Utilities";
  if (normalized.includes("sale") || normalized.includes("sold") || normalized.includes("invoice")) return "Sales";
  if (normalized.includes("service") || normalized.includes("consult") || normalized.includes("design")) return "Services";
  if (normalized.includes("shop") || normalized.includes("shopping")) return "Shopping";
  if (normalized.includes("law") || normalized.includes("tax") || normalized.includes("account")) return "Professional Services";

  return "Miscellaneous";
}

function inferBusinessType(text: string, category: string): "Business" | "Personal" | "Needs Review" {
  const normalized = text.toLowerCase();

  if (normalized.includes("personal") || normalized.includes("family") || normalized.includes("home") || (category === "Food" && normalized.includes("dinner"))) {
    return "Personal";
  }

  if (
    normalized.includes("for business") ||
    normalized.includes("business") ||
    normalized.includes("inventory") ||
    normalized.includes("marketing") ||
    normalized.includes("delivery") ||
    normalized.includes("client") ||
    normalized.includes("invoice") ||
    normalized.includes("stock")
  ) {
    return "Business";
  }

  if (category === "Food") {
    return "Needs Review";
  }

  return "Needs Review";
}

function amountFromText(text: string): number | null {
  const match = text.match(/(?:₦|N|\$|£|€)?\s*(\d+(?:,\d{3})*(?:\.\d+)?)(?:\s*(k|K|thousand))?/i);

  if (!match) return null;

  const raw = match[1].replace(/,/g, "");
  let value = Number(raw);

  if (match[2] && /k|K|thousand/i.test(match[2])) {
    value *= 1000;
  }

  return value;
}

function parseNaturalMessage(message: string): { transactions: Transaction[]; summary: string } {
  const lines = message
    .split(/\n|\.|\r/)
    .map((line) => line.trim())
    .filter(Boolean);

  const transactions: Transaction[] = [];

  lines.forEach((line, index) => {
    const amount = amountFromText(line);
    if (!amount) return;

    const lower = line.toLowerCase();
    const isIncome =
      /income|revenue|sales|sold|received|earned|invoice|client/i.test(lower) ||
      /made\s+.*\b\d/i.test(lower) ||
      /sold\s+.*\b\d/i.test(lower);

    const category = inferCategory(line);
    const businessType = inferBusinessType(line, category);
    const description = line.replace(/[₦N$£€]\s*\d+(?:,\d{3})*(?:\.\d+)?(?:\s*(?:k|K|thousand))?/gi, "").trim() || "Recorded transaction";

    transactions.push({
      id: `parsed-${Date.now()}-${index}`,
      date: getTodayISO(),
      description: description.slice(0, 120),
      type: isIncome ? "Income" : "Expense",
      category,
      amount,
      businessType,
      status: businessType === "Needs Review" ? "Needs Review" : "Recorded",
      notes: businessType === "Needs Review" ? "Needs confirmation" : "Auto-categorized",
    });
  });

  if (!transactions.length) {
    return {
      transactions: [],
      summary: "I couldn’t confidently extract a transaction. Tell me the amount and what happened, for example: “Spent ₦12k on delivery” or “Sold 3 shirts for ₦45k.”",
    };
  }

  const incomeTotal = transactions
    .filter((transaction) => transaction.type === "Income")
    .reduce((sum, tx) => sum + tx.amount, 0);
  const expenseTotal = transactions
    .filter((transaction) => transaction.type === "Expense")
    .reduce((sum, tx) => sum + tx.amount, 0);

  const summary = `Got it. I recorded ${transactions.filter((tx) => tx.type === "Income").length} income transaction(s) and ${transactions.filter((tx) => tx.type === "Expense").length} expense item(s). Income: ${formatMoney(incomeTotal)} • Business expenses: ${formatMoney(expenseTotal)} • Net: ${formatMoney(incomeTotal - expenseTotal)}.`;

  return { transactions, summary };
}

function buildHealthScore(transactions: Transaction[]) {
  const totals = calculateRecentTotals(transactions);
  const personalRatio = transactions
    .filter((transaction) => transaction.businessType === "Personal")
    .reduce((sum, item) => sum + item.amount, 0);
  const totalActivity = transactions.reduce((sum, item) => sum + item.amount, 0) || 1;

  let score = 82;
  if (totals.margin < 10) score -= 12;
  if (totals.expenses > totals.revenue) score -= 16;
  if (personalRatio / totalActivity > 0.2) score -= 8;
  if (transactions.filter((item) => item.status === "Needs Review").length > 0) score -= 9;
  if (totals.expenses > totals.revenue * 0.85) score -= 10;

  return Math.min(100, Math.max(32, score));
}

function mapRowToTransaction(row: TransactionRow): Transaction {
  const businessType: BusinessType =
    row.money_type === "Business" ? "Business" : row.money_type === "Personal" ? "Personal" : "Needs Review";
  return {
    id: row.id,
    date: row.date,
    description: row.description,
    type: row.type,
    category: row.category,
    amount: Number(row.amount),
    businessType,
    status: row.status === "Needs Review" ? "Needs Review" : "Recorded",
    notes: row.notes ?? "",
  };
}

function mapRowToInvoice(row: InvoiceRow): Invoice {
  return {
    id: row.id,
    customer: row.customer,
    amount: Number(row.amount),
    dueDate: row.due_date,
    status: row.status,
  };
}

/**
 * Convert Transaction to LedgerEntry format for use by reporting modules.
 * Requires user ID to be passed since transactions don't store it explicitly.
 */
function transactionToLedgerEntry(tx: Transaction, userId: string): LedgerEntry {
  return {
    id: tx.id,
    userId,
    type: tx.type,
    amount: tx.amount,
    category: tx.category,
    date: tx.date,
    description: tx.description,
    vendor: undefined,
    paymentMethod: undefined,
    notes: tx.notes,
    reference: undefined,
    status: tx.status,
    moneyType: (tx.businessType === "Needs Review" ? "Unclassified" : tx.businessType) as MoneyType,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

/**
 * Convert income transactions to IncomeRecord format for the IncomeModule.
 */
function transactionToIncomeRecord(tx: Transaction, userId: string): IncomeRecord {
  return {
    id: tx.id,
    userId,
    amount: tx.amount,
    category: tx.category,
    date: tx.date,
    customer: tx.description, // Use description as customer since transaction doesn't have customer field
    paymentMethod: "Bank transfer", // Default, could be enhanced if stored in transaction
    description: tx.description,
    notes: tx.notes,
    reference: "",
    status: (tx.status === "Recorded" ? "Received" : "Pending") as "Received" | "Pending",
    moneyType: (tx.businessType === "Needs Review" ? "Unclassified" : tx.businessType) as MoneyType,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

export default function DashboardPage() {
  const router = useRouter();
  const [activeSection, setActiveSection] = useState<Section>("Ask FABBY");
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [isLoadingData, setIsLoadingData] = useState(false);
  const [dataError, setDataError] = useState<string | null>(null);
  const [goals, setGoals] = useState<Goal[]>(() => readGoals("local-user"));
  const [query, setQuery] = useState("");
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: "msg-1",
      role: "assistant",
      content: "Hi! Tell FABBY what happened today. I can turn it into organized bookkeeping and business insights.",
    },
  ]);
  const [pendingTransactions, setPendingTransactions] = useState<Transaction[]>([]);
  const [reviewTransaction, setReviewTransaction] = useState<Transaction | null>(null);
  const [reviewSaving, setReviewSaving] = useState(false);
  const [reviewError, setReviewError] = useState("");
  const [searchTerm, setSearchTerm] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("All");
  const [typeFilter, setTypeFilter] = useState("All");
  const [newGoal, setNewGoal] = useState({
    name: "",
    targetAmount: "",
    currentSavedAmount: "",
    targetDate: "",
    category: "General",
    description: "",
  });
  const [goalDrafts, setGoalDrafts] = useState<Record<string, { amount: string; source: string; date: string; note: string }>>({});
  const [invoiceDraft, setInvoiceDraft] = useState({ customer: "", amount: "", dueDate: "" });
  const [invoiceSaving, setInvoiceSaving] = useState(false);
  const [editingInvoiceId, setEditingInvoiceId] = useState<string | null>(null);
  const [invoiceEditDraft, setInvoiceEditDraft] = useState({
    customer: "",
    amount: "",
    dueDate: "",
    status: "Unpaid" as "Paid" | "Unpaid" | "Overdue",
  });
  const [invoiceActionLoadingId, setInvoiceActionLoadingId] = useState<string | null>(null);

  const { user, session, isLoading, isAuthenticated, authStateReady } = useAuth();

  const fetchTransactions = useCallback(async () => {
    if (!user?.id) {
      return [] as TransactionRow[];
    }

    const supabase = createBrowserClient();
    const { data, error } = await supabase
      .from("transactions")
      .select("id, date, description, type, category, amount, money_type, status, notes, created_at, updated_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (error) {
      throw error;
    }

    return (data ?? []) as unknown as TransactionRow[];
  }, [user]);

  const fetchInvoices = useCallback(async () => {
    if (!user?.id) {
      return [] as InvoiceRow[];
    }

    const supabase = createBrowserClient();
    const { data, error } = await supabase
      .from("invoices")
      .select("id, customer, amount, due_date, status, created_at, updated_at")
      .eq("user_id", user.id)
      .order("created_at", { ascending: false });

    if (error) {
      throw error;
    }

    return (data ?? []) as unknown as InvoiceRow[];
  }, [user]);

  useEffect(() => {
    if (!authStateReady || isLoading) {
      return;
    }

    // If AuthContext shows no session/user, directly verify with Supabase
    // This eliminates the race condition where the guard redirects before
    // AuthContext finishes processing the auth state change event
    if (!session && !user) {
      const verifySession = async () => {
        try {
          const supabase = createBrowserClient();
          const { data, error } = await supabase.auth.getSession();
          
          // If there's still no valid session after direct check, redirect to login
          if (error || !data.session) {
            router.replace("/login");
          }
          // If Supabase confirms session exists, the AuthContext will catch up
          // and update state. Don't redirect here - let context sync.
        } catch (err) {
          console.error("Session verification failed:", err);
          router.replace("/login");
        }
      };

      void verifySession();
    }
  }, [authStateReady, isLoading, session, user, router]);

  useEffect(() => {
    if (!isAuthenticated || !user?.id) {
      return;
    }

    let cancelled = false;

    const load = async () => {
      setIsLoadingData(true);
      setDataError(null);
      try {
        const [txRows, invoiceRows] = await Promise.all([fetchTransactions(), fetchInvoices()]);
        if (cancelled) return;
        setTransactions(txRows.map(mapRowToTransaction));
        setInvoices(invoiceRows.map(mapRowToInvoice));
      } catch (err) {
        if (cancelled) return;
        console.error("Failed to load dashboard data:", err);
        setDataError(err instanceof Error ? err.message : "Unable to load your financial records.");
      } finally {
        if (!cancelled) setIsLoadingData(false);
      }
    };

    void load();

    return () => {
      cancelled = true;
    };
  }, [isAuthenticated, user, fetchTransactions, fetchInvoices]);

  const settings = readSettings();
  const totals = useMemo(() => calculateRecentTotals(transactions), [transactions]);
  const healthScore = useMemo(() => buildHealthScore(transactions), [transactions]);

  /**
   * Convert transactions to LedgerEntry format for modules that need full ledger data.
   * Used by: InsightsModule, MoneySeparationModule, ExpensesModule
   */
  const ledgerEntries = useMemo(() => {
    if (!user?.id) return [];
    return transactions.map((tx) => transactionToLedgerEntry(tx, user.id));
  }, [transactions, user]);

  /**
   * Extract and convert income transactions to IncomeRecord format for IncomeModule.
   */
  const incomeRecords = useMemo(() => {
    if (!user?.id) return [];
    return transactions
      .filter((tx) => tx.type === "Income")
      .map((tx) => transactionToIncomeRecord(tx, user.id));
  }, [transactions, user]);

  const filteredTransactions = useMemo(() => {
    return transactions.filter((transaction) => {
      const matchesSearch =
        searchTerm.length === 0 ||
        transaction.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        transaction.category.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesCategory = categoryFilter === "All" || transaction.category === categoryFilter;
      const matchesType = typeFilter === "All" || transaction.type === typeFilter;
      return matchesSearch && matchesCategory && matchesType;
    });
  }, [transactions, searchTerm, categoryFilter, typeFilter]);

  const monthlySegments = [
    { label: "Jan", value: 55 },
    { label: "Feb", value: 62 },
    { label: "Mar", value: 68 },
    { label: "Apr", value: 74 },
    { label: "May", value: 79 },
    { label: "Jun", value: 82 },
  ];

  const businessSummary = useMemo(() => {
    const businessRevenue = transactions
      .filter((tx) => tx.type === "Income" && tx.businessType === "Business")
      .reduce((sum, tx) => sum + tx.amount, 0);
    const businessExpenses = transactions
      .filter((tx) => tx.type === "Expense" && tx.businessType === "Business")
      .reduce((sum, tx) => sum + tx.amount, 0);
    const personalExpenses = transactions
      .filter((tx) => tx.businessType === "Personal")
      .reduce((sum, tx) => sum + tx.amount, 0);
    const mixed = transactions
      .filter((tx) => tx.businessType === "Needs Review")
      .reduce((sum, tx) => sum + tx.amount, 0);

    return { businessRevenue, businessExpenses, personalExpenses, mixed };
  }, [transactions]);

  const goalContributionMap = useMemo(() => {
    const map: Record<string, GoalContribution[]> = {};
    goals.forEach((goal) => {
      map[goal.id] = readGoalContributions(goal.id, "local-user");
    });
    return map;
  }, [goals]);

  const handleSignOut = async () => {
    try {
      await signOut();
      router.push("/login");
      router.refresh();
    } catch (error) {
      console.error("Sign out error:", error);
    }
  };

  const insertTransactionToSupabase = useCallback(async (tx: Transaction): Promise<TransactionRow | null> => {
    const supabase = createBrowserClient();
    const activeUserId = user?.id;

    if (!activeUserId) {
      setReviewError("You must be signed in before saving a transaction.");
      return null;
    }

    const moneyType = tx.businessType === "Business" ? "Business" : tx.businessType === "Personal" ? "Personal" : "Unclassified";
    const { data, error } = await supabase
      .from("transactions")
      .insert({
        user_id: activeUserId,
        date: tx.date,
        description: tx.description,
        type: tx.type,
        category: tx.category,
        amount: tx.amount,
        money_type: moneyType,
        status: tx.status,
        notes: tx.notes,
      })
      .select("id, date, description, type, category, amount, money_type, status, notes, created_at, updated_at")
      .single();

    if (error) {
      console.error("Supabase insert transaction error:", error);
      setReviewError(error.message || "FABBY couldn't save this transaction.");
      return null;
    }

    return data as unknown as TransactionRow;
  }, [user?.id]);

  const persistTransactionSuggestion = useCallback(
    async (transaction: Transaction): Promise<boolean> => {
      const inserted = await insertTransactionToSupabase(transaction);
      if (!inserted) return false;

      setTransactions((currentTransactions) => [mapRowToTransaction(inserted), ...currentTransactions]);
      return true;
    },
    [insertTransactionToSupabase],
  );

  /**
   * Callbacks for modules to add/update/delete transactions via Supabase.
   * These replace the direct localStorage persistence calls.
   */
  const onAddTransaction = useCallback(
    async (entry: LedgerEntry | IncomeRecord): Promise<boolean> => {
      const supabase = createBrowserClient();
      const activeUserId = user?.id;

      if (!activeUserId) {
        console.error("User not authenticated");
        return false;
      }

      const moneyType =
        entry.moneyType === "Business" ? "Business" : entry.moneyType === "Personal" ? "Personal" : "Unclassified";

      const { data, error } = await supabase
        .from("transactions")
        .insert({
          user_id: activeUserId,
          date: entry.date,
          description: entry.description,
          type: "type" in entry ? (entry.type === "Income" ? "Income" : "Expense") : "Income",
          category: entry.category,
          amount: entry.amount,
          money_type: moneyType,
          status: entry.status || "Recorded",
          notes: entry.notes || "",
        })
        .select("id, date, description, type, category, amount, money_type, status, notes, created_at, updated_at")
        .single();

      if (error) {
        console.error("Failed to add transaction:", error);
        return false;
      }

      const newTx = mapRowToTransaction(data as unknown as TransactionRow);
      setTransactions((current) => [newTx, ...current]);
      return true;
    },
    [user?.id],
  );

  const onUpdateTransaction = useCallback(
    async (entryId: string, updates: Partial<LedgerEntry | IncomeRecord>): Promise<boolean> => {
      const supabase = createBrowserClient();
      const activeUserId = user?.id;

      if (!activeUserId) {
        console.error("User not authenticated");
        return false;
      }

      const moneyType =
        updates.moneyType === "Business"
          ? "Business"
          : updates.moneyType === "Personal"
            ? "Personal"
            : "Unclassified";

      const { data, error } = await supabase
        .from("transactions")
        .update({
          ...(updates.date && { date: updates.date }),
          ...(updates.description && { description: updates.description }),
          ...(updates.category && { category: updates.category }),
          ...(updates.amount && { amount: updates.amount }),
          ...(updates.moneyType && { money_type: moneyType }),
          ...(updates.notes && { notes: updates.notes }),
        })
        .eq("id", entryId)
        .eq("user_id", activeUserId)
        .select("id, date, description, type, category, amount, money_type, status, notes, created_at, updated_at")
        .single();

      if (error) {
        console.error("Failed to update transaction:", error);
        return false;
      }

      const updatedTx = mapRowToTransaction(data as unknown as TransactionRow);
      setTransactions((current) => current.map((tx) => (tx.id === entryId ? updatedTx : tx)));
      return true;
    },
    [user?.id],
  );

  const onDeleteTransaction = useCallback(
    async (entryId: string): Promise<boolean> => {
      const supabase = createBrowserClient();
      const activeUserId = user?.id;

      if (!activeUserId) {
        console.error("User not authenticated");
        return false;
      }

      const { error } = await supabase
        .from("transactions")
        .delete()
        .eq("id", entryId)
        .eq("user_id", activeUserId);

      if (error) {
        console.error("Failed to delete transaction:", error);
        return false;
      }

      setTransactions((current) => current.filter((tx) => tx.id !== entryId));
      return true;
    },
    [user?.id],
  );

  const askFabby = async (input: string) => {
    const cleaned = input.trim();
    if (!cleaned) return;

    setMessages((current) => [...current, { id: crypto.randomUUID(), role: "user", content: cleaned }]);

    const { transactions: parsed, summary } = parseNaturalMessage(cleaned);

    if (parsed.length) {
      const requireConfirmation = readSettings().ai.confirmationBeforeSave;
      setPendingTransactions(parsed);
      setMessages((current) => [
        ...current,
        {
          id: crypto.randomUUID(),
          role: "assistant",
          content: requireConfirmation ? `${summary} Review the suggested transaction before saving.` : `${summary} FABBY saved the detected transaction automatically based on your settings.`,
        },
      ]);

      if (!requireConfirmation) {
        let savedCount = 0;
        for (const transaction of parsed) {
          const didPersist = await persistTransactionSuggestion(transaction);
          if (didPersist) savedCount += 1;
        }
        if (savedCount > 0) {
          setMessages((current) => [...current, { id: crypto.randomUUID(), role: "assistant", content: `✓ ${savedCount} transaction${savedCount > 1 ? "s" : ""} saved to your ledger.` }]);
        }
        setPendingTransactions([]);
      }
      return;
    }

    const lower = cleaned.toLowerCase();
    let answer = "I’m ready to help. Try describing a sale, expense, or a question like ‘How much did I spend this week?’";

    if (lower.includes("spend this week")) {
      answer = `This week, you spent ${formatMoney(transactions.filter((tx) => tx.type === "Expense").reduce((sum, tx) => sum + tx.amount, 0))}.`;
    }
    if (lower.includes("make this month")) {
      answer = `This month, your business generated ${formatMoney(totals.revenue)} in revenue.`;
    }
    if (lower.includes("biggest expense")) {
      const biggest = [...transactions].sort((a, b) => b.amount - a.amount)[0];
      answer = biggest ? `Your biggest expense is ${biggest.category} at ${formatMoney(biggest.amount)}.` : "No major expense recorded yet.";
    }
    if (lower.includes("advertising")) {
      const adSpend = transactions.filter((tx) => tx.category === "Marketing" || tx.category === "Advertising").reduce((sum, tx) => sum + tx.amount, 0);
      answer = `Advertising and marketing spend is ${formatMoney(adSpend)}.`;
    }
    if (lower.includes("personal expenses")) {
      const personalSpend = transactions.filter((tx) => tx.businessType === "Personal").reduce((sum, tx) => sum + tx.amount, 0);
      answer = `Your personal spending total is ${formatMoney(personalSpend)}.`;
    }
    if (lower.includes("burn rate")) {
      answer = `Your current burn rate looks like ${formatMoney(totals.expenses / 4)} per week based on recent activity.`;
    }
    if (lower.includes("goal") || lower.includes("profit")) {
      if (goals.length > 0) {
        const topGoal = goals
          .map((goal) => ({ goal, metrics: getGoalMetrics(goal, goalContributionMap[goal.id] ?? []) }))
          .sort((a, b) => b.metrics.percentComplete - a.metrics.percentComplete)[0];
        if (topGoal) {
          answer = `${topGoal.goal.name} is ${Math.round(topGoal.metrics.percentComplete)}% complete and ${formatMoney(topGoal.metrics.remainingAmount)} remaining. The current savings pace is ${formatMoney(topGoal.metrics.currentSavingsPace)} per month.`;
        } else {
          answer = `Your current profit is ${formatMoney(totals.net)} and you are ${formatMoney(Math.max(0, 1000000 - totals.net))} away from a ₦1,000,000 target.`;
        }
      } else {
        answer = `Your current profit is ${formatMoney(totals.net)} and you are ${formatMoney(Math.max(0, 1000000 - totals.net))} away from a ₦1,000,000 target.`;
      }
    }

    setMessages((current) => [...current, { id: crypto.randomUUID(), role: "assistant", content: answer }]);
  };

  const savePendingTransactions = async () => {
    if (!pendingTransactions.length) return;

    let savedCount = 0;
    for (const transaction of pendingTransactions) {
      const didPersist = await persistTransactionSuggestion(transaction);
      if (didPersist) savedCount += 1;
    }

    if (savedCount > 0) {
      setMessages((current) => [...current, { id: crypto.randomUUID(), role: "assistant", content: `✓ ${savedCount} transaction${savedCount > 1 ? "s" : ""} saved to your ledger.` }]);
    }

    setPendingTransactions([]);
    setQuery("");
  };

  const saveReviewTransaction = async () => {
    if (!reviewTransaction) return;
    if (reviewSaving) return;

    const trimmedDescription = reviewTransaction.description.trim();
    const trimmedCategory = reviewTransaction.category.trim();
    const normalized = Number(reviewTransaction.amount);

    if (!trimmedDescription || !trimmedCategory || Number.isNaN(normalized) || normalized <= 0) {
      setReviewError("Please provide a valid amount, description, and category before saving.");
      return;
    }

    setReviewSaving(true);
    setReviewError("");

    const finalTransaction: Transaction = {
      ...reviewTransaction,
      description: trimmedDescription,
      category: trimmedCategory,
      amount: normalized,
      businessType: reviewTransaction.businessType === "Needs Review" ? "Needs Review" : reviewTransaction.businessType,
      notes: reviewTransaction.notes,
      status: reviewTransaction.businessType === "Needs Review" ? "Needs Review" : "Recorded",
    };

    const didPersist = await persistTransactionSuggestion(finalTransaction);
    setReviewSaving(false);

    if (!didPersist) {
      setReviewError(reviewError || "FABBY couldn't save this transaction. Please try again.");
      return;
    }

    setPendingTransactions((current) => current.filter((transaction) => transaction.id !== finalTransaction.id));
    setReviewTransaction(null);

    setMessages((current) => [...current, { id: crypto.randomUUID(), role: "assistant", content: `✓ ${finalTransaction.type} saved\n\n${formatMoney(finalTransaction.amount)}\n${finalTransaction.description}\n${finalTransaction.businessType} · ${finalTransaction.category}` }]);
  };

  const removeTransaction = async (id: string) => {
    if (!user?.id) {
      console.error("Delete blocked: no authenticated user.");
      return;
    }

    const supabase = createBrowserClient();
    const { error } = await supabase.from("transactions").delete().eq("id", id).eq("user_id", user.id);

    if (error) {
      console.error("Failed to delete transaction:", error);
      return;
    }

    setTransactions((current) => current.filter((transaction) => transaction.id !== id));
  };

  const addInvoice = async () => {
    if (!invoiceDraft.customer || !invoiceDraft.amount || !invoiceDraft.dueDate) return;
    if (!user?.id) {
      setDataError("You must be signed in to save an invoice.");
      return;
    }

    setInvoiceSaving(true);

    const supabase = createBrowserClient();
    const { data, error } = await supabase
      .from("invoices")
      .insert({
        user_id: user.id,
        customer: invoiceDraft.customer,
        amount: Number(invoiceDraft.amount),
        due_date: invoiceDraft.dueDate,
        status: "Unpaid",
      })
      .select("id, customer, amount, due_date, status, created_at, updated_at")
      .single();

    setInvoiceSaving(false);

    if (error) {
      console.error("Failed to save invoice:", error);
      setDataError(error.message || "The invoice could not be saved.");
      return;
    }

    const row = data as unknown as InvoiceRow;
    setInvoices((current) => [mapRowToInvoice(row), ...current]);
    setInvoiceDraft({ customer: "", amount: "", dueDate: "" });
    setDataError(null);
  };

  const onUpdateInvoice = useCallback(
    async (
      invoiceId: string,
      updates: Partial<{ customer: string; amount: number; due_date: string; status: "Paid" | "Unpaid" | "Overdue" }>,
    ): Promise<boolean> => {
      const supabase = createBrowserClient();
      const activeUserId = user?.id;

      if (!activeUserId) {
        setDataError("You must be signed in to update an invoice.");
        return false;
      }

      const { data, error } = await supabase
        .from("invoices")
        .update({
          ...(updates.customer !== undefined && { customer: updates.customer }),
          ...(updates.amount !== undefined && { amount: updates.amount }),
          ...(updates.due_date !== undefined && { due_date: updates.due_date }),
          ...(updates.status && { status: updates.status }),
        })
        .eq("id", invoiceId)
        .eq("user_id", activeUserId)
        .select("id, customer, amount, due_date, status, created_at, updated_at")
        .single();

      if (error) {
        console.error("Failed to update invoice:", error);
        setDataError(error.message || "The invoice could not be updated.");
        return false;
      }

      const updatedInvoice = mapRowToInvoice(data as unknown as InvoiceRow);
      setInvoices((current) => current.map((invoice) => (invoice.id === invoiceId ? updatedInvoice : invoice)));
      setDataError(null);
      return true;
    },
    [user?.id],
  );

  const onDeleteInvoice = useCallback(
    async (invoiceId: string): Promise<boolean> => {
      const confirmed = window.confirm("Delete this invoice?");
      if (!confirmed) {
        return false;
      }

      const supabase = createBrowserClient();
      const activeUserId = user?.id;

      if (!activeUserId) {
        setDataError("You must be signed in to delete an invoice.");
        return false;
      }

      const { error } = await supabase
        .from("invoices")
        .delete()
        .eq("id", invoiceId)
        .eq("user_id", activeUserId);

      if (error) {
        console.error("Failed to delete invoice:", error);
        setDataError(error.message || "The invoice could not be deleted.");
        return false;
      }

      setInvoices((current) => current.filter((invoice) => invoice.id !== invoiceId));
      setDataError(null);
      return true;
    },
    [user?.id],
  );

  const beginInvoiceEdit = (invoice: Invoice) => {
    setEditingInvoiceId(invoice.id);
    setInvoiceEditDraft({
      customer: invoice.customer,
      amount: String(invoice.amount),
      dueDate: invoice.dueDate,
      status: invoice.status,
    });
    setDataError(null);
  };

  const saveInvoiceEdit = async () => {
    if (!editingInvoiceId) return;
    if (!invoiceEditDraft.customer.trim() || !invoiceEditDraft.amount || !invoiceEditDraft.dueDate) {
      setDataError("Please complete the customer, amount, and due date before saving.");
      return;
    }

    setInvoiceActionLoadingId(editingInvoiceId);
    setDataError(null);

    const didUpdate = await onUpdateInvoice(editingInvoiceId, {
      customer: invoiceEditDraft.customer.trim(),
      amount: Number(invoiceEditDraft.amount),
      due_date: invoiceEditDraft.dueDate,
      status: invoiceEditDraft.status,
    });

    setInvoiceActionLoadingId(null);

    if (didUpdate) {
      setEditingInvoiceId(null);
    }
  };

  const cancelInvoiceEdit = () => {
    setEditingInvoiceId(null);
    setInvoiceEditDraft({ customer: "", amount: "", dueDate: "", status: "Unpaid" });
    setDataError(null);
  };

  const addGoal = () => {
    if (!newGoal.name || !newGoal.targetAmount) return;

    const created = createGoalRecord({
      name: newGoal.name,
      targetAmount: Number(newGoal.targetAmount),
      currentSavedAmount: Number(newGoal.currentSavedAmount || 0),
      targetDate: newGoal.targetDate || new Date(Date.now() + 1000 * 60 * 60 * 24 * 365).toISOString().slice(0, 10),
      description: newGoal.description,
      category: newGoal.category,
      userId: "local-user",
    });

    const nextGoals = [created, ...goals];
    setGoals(nextGoals);
    saveGoals(nextGoals, "local-user");
    setNewGoal({ name: "", targetAmount: "", currentSavedAmount: "", targetDate: "", category: "General", description: "" });
  };

  const updateGoalContribution = (goalId: string, amount: string, source: string, date: string, note: string) => {
    const trimmedAmount = Number(amount);
    if (!Number.isFinite(trimmedAmount) || trimmedAmount <= 0) return;

    const contribution = createContributionRecord({
      goalId,
      userId: "local-user",
      amount: trimmedAmount,
      date: date || getTodayISO(),
      source: source || "Business savings",
      note: note || "",
    });

    const currentContributions = readGoalContributions(goalId, "local-user");
    const nextContributions = [contribution, ...currentContributions];
    saveGoalContributions(goalId, nextContributions, "local-user");

    const nextGoals = goals.map((goal) => {
      if (goal.id !== goalId) return goal;
      const totalSaved = Math.max(goal.currentSavedAmount, nextContributions.reduce((sum, item) => sum + Number(item.amount ?? 0), 0));
      return { ...goal, currentSavedAmount: totalSaved, updatedAt: new Date().toISOString() };
    });

    setGoals(nextGoals);
    saveGoals(nextGoals, "local-user");
    setGoalDrafts((current) => ({ ...current, [goalId]: { amount: "", source: "Business savings", date: getTodayISO(), note: "" } }));
  };

  const removeGoal = (goalId: string) => {
    const nextGoals = goals.filter((goal) => goal.id !== goalId);
    setGoals(nextGoals);
    saveGoals(nextGoals, "local-user");
    saveGoalContributions(goalId, [], "local-user");
  };

  if (isLoading) {
    return (
      <div className="fabby-shell flex items-center justify-center px-4 py-10 min-h-screen">
        <div className="text-center">
          <div className="mb-4 flex justify-center">
            <div className="h-10 w-10 animate-spin rounded-full border-4 border-[#2d1d1d] border-t-transparent"></div>
          </div>
          <p className="text-sm text-[#6d5255]">Loading FABBY...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  return (
    <div className="fabby-shell px-3 py-4 md:px-5 lg:px-6">
      <div className="mx-auto max-w-[1500px] overflow-hidden rounded-[30px] border border-[rgba(109,69,71,0.09)] bg-[rgba(255,250,248,0.72)] shadow-[0_30px_80px_rgba(101,66,67,0.09)] backdrop-blur-sm">
        <div className="grid min-h-[calc(100vh-2rem)] lg:grid-cols-[260px_minmax(0,1fr)]">
          <aside className="border-b border-r border-[rgba(109,69,71,0.08)] bg-[rgba(255,247,244,0.9)] p-5 lg:border-b-0">
            <div className="mb-8 flex items-center gap-3">
              <BrandLogo compact className="h-11 w-11" />
            </div>

            <nav className="space-y-1.5">
              {navItems.map((item) => (
                <button
                  key={item}
                  type="button"
                  onClick={() => setActiveSection(item)}
                  className={`flex w-full items-center justify-between rounded-2xl px-3 py-2.5 text-left text-sm font-medium transition ${
                    activeSection === item
                      ? "bg-[#f4d5d3] text-[#2d1d1d] shadow-sm"
                      : "text-[#5c4645] hover:bg-[rgba(244,213,211,0.2)]"
                  }`}
                >
                  <span>{item}</span>
                  <span className="text-[10px] text-[#806264]">
                    {item === "Ask FABBY" ? "AI" : ""}
                  </span>
                </button>
              ))}
            </nav>

            <div className="mt-8 rounded-2xl border border-[rgba(109,69,71,0.08)] bg-[#fffaf7] p-4">
              <BrandFooter className="!text-left" />
            </div>

            <div className="mt-8 text-xs text-[#7b5d5d]">
              FABBY provides business insights and bookkeeping support based on the information provided. It is not a substitute for a qualified accountant or adviser.
            </div>

            <button
              type="button"
              onClick={handleSignOut}
              className="mt-8 flex w-full items-center justify-center rounded-full border border-[rgba(109,69,71,0.12)] bg-white px-4 py-2.5 text-sm font-medium text-[#4f383b]"
            >
              Log out
            </button>
          </aside>

          <main className="p-4 md:p-6 lg:p-8">
            {activeSection === "Income" && (
              <IncomeModule
                records={incomeRecords}
                onAddRecord={onAddTransaction}
                onUpdateRecord={onUpdateTransaction}
                onDeleteRecord={onDeleteTransaction}
                userId={user?.id}
              />
            )}
            {activeSection === "Expenses" && (
              <ExpensesModule
                entries={ledgerEntries.filter((e) => e.type === "Expense")}
                onAddEntry={onAddTransaction}
                onUpdateEntry={onUpdateTransaction}
                onDeleteEntry={onDeleteTransaction}
                userId={user?.id}
              />
            )}
            {activeSection === "Insights" && <InsightsModule entries={ledgerEntries} />}
            {activeSection === "Reports" && <ReportsModule />}
            {activeSection === "Business vs Personal" && (
              <MoneySeparationModule
                entries={ledgerEntries}
                onAddEntry={onAddTransaction}
                onUpdateEntry={onUpdateTransaction}
                onDeleteEntry={onDeleteTransaction}
                userId={user?.id}
              />
            )}
            {activeSection === "Settings" && <SettingsModule />}

            {activeSection === "Ask FABBY" && (
              <div className="space-y-6">
                <div className="fabby-card rounded-[30px] p-5 md:p-6">
                  <div className="mb-4 flex items-center justify-between">
                    <div>
                      <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Ask FABBY</div>
                      <h2 className="mt-2 text-3xl font-semibold text-[#2d1d1d]">Tell FABBY what happened.</h2>
                    </div>
                    <div className="rounded-full bg-[#f6e4e3] px-3 py-1 text-xs font-medium text-[#5b3a3e]">AI bookkeeping</div>
                  </div>

                  <div className="space-y-4 rounded-[24px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4">
                    <textarea
                      value={query}
                      onChange={(event) => setQuery(event.target.value)}
                      rows={4}
                      placeholder="Tell FABBY what happened..."
                      className="input-shell min-h-[120px] resize-none"
                    />
                    <div className="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                      <div className="flex flex-wrap gap-2 text-xs text-[#6e5759]">
                        {[
                          "I made ₦80k today",
                          "I spent ₦12k on advertising",
                          "How did I perform this month?",
                          "Show me my biggest expenses",
                        ].map((example) => (
                          <button
                            key={example}
                            type="button"
                            onClick={() => setQuery(example)}
                            className="rounded-full border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] px-2.5 py-1.5 hover:bg-[#fbeae9]"
                          >
                            {example}
                          </button>
                        ))}
                      </div>
                      <button
                        type="button"
                        onClick={() => askFabby(query)}
                        className="rounded-full bg-[#2d1d1d] px-5 py-2.5 text-sm font-medium text-white"
                      >
                        Ask FABBY
                      </button>
                    </div>
                  </div>
                </div>

                <div className="fabby-card rounded-[30px] p-5">
                  <div className="mb-4 text-sm uppercase tracking-[0.16em] text-[#7a5f60]">Conversation</div>
                  <div className="space-y-3">
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`max-w-[90%] rounded-2xl px-4 py-3 text-sm leading-6 ${
                          message.role === "assistant"
                            ? "bg-[#f7e6e5] text-[#3c292a]"
                            : "ml-auto bg-[#2d1d1d] text-white"
                        }`}
                      >
                        {message.content}
                      </div>
                    ))}
                  </div>
                </div>

                {pendingTransactions.length > 0 && (
                  <div className="fabby-card rounded-[30px] p-5">
                    <div className="mb-3 text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Confirmation card</div>
                    <div className="mb-4 text-xl font-semibold text-[#2d1d1d]">I found {pendingTransactions.length} transactions</div>
                    <div className="space-y-3">
                      {pendingTransactions.map((tx) => (
                        <div key={tx.id} className="flex items-center justify-between rounded-2xl border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-3">
                          <div>
                            <div className="font-medium text-[#2d1d1d]">{tx.category}</div>
                            <div className="text-xs text-[#725c5e]">{tx.description}</div>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className={`text-sm font-semibold ${tx.type === "Income" ? "text-[#2f7f67]" : "text-[#3b2b2d]"}`}>
                              {tx.type === "Income" ? "+" : "-"}
                              {formatMoney(tx.amount)}
                            </div>
                            <span className={`label-pill ${tx.businessType === "Business" ? "business" : tx.businessType === "Personal" ? "personal" : "review"}`}>
                              {tx.businessType}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="mt-5 flex flex-wrap gap-3">
                      <button type="button" onClick={savePendingTransactions} className="rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white">
                        Save All
                      </button>
                      <button type="button" onClick={() => setReviewTransaction(pendingTransactions[0] ?? null)} className="rounded-full border border-[#e7b0b3] bg-[#fdf1f0] px-4 py-2 text-sm font-medium text-[#40292b]">
                        Review
                      </button>
                      <button type="button" onClick={() => setPendingTransactions([])} className="rounded-full border border-[rgba(109,69,71,0.1)] px-4 py-2 text-sm font-medium text-[#5b4144]">
                        Cancel
                      </button>
                    </div>
                  </div>
                )}

                {reviewTransaction && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#1d1b1b]/50 p-4">
                    <div className="w-full max-w-3xl rounded-[30px] bg-white p-5 shadow-2xl md:p-6">
                      <div className="mb-5 flex items-start justify-between gap-4">
                        <div>
                          <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Review transaction</div>
                          <h3 className="mt-2 text-2xl font-semibold text-[#2d1d1d]">AI suggestion review</h3>
                        </div>
                        <button type="button" onClick={() => setReviewTransaction(null)} className="rounded-full border border-[rgba(109,69,71,0.12)] px-3 py-1.5 text-sm text-[#4b2f31]">
                          Close
                        </button>
                      </div>

                      <div className="grid gap-4 md:grid-cols-2">
                        <label className="space-y-2 text-sm text-[#563d3f]">
                          <span>Type</span>
                          <select
                            value={reviewTransaction.type}
                            onChange={(event) => setReviewTransaction((current) => current ? { ...current, type: event.target.value as TxType } : current)}
                            className="input-shell"
                          >
                            <option value="Expense">Expense</option>
                            <option value="Income">Income</option>
                          </select>
                        </label>

                        <label className="space-y-2 text-sm text-[#563d3f]">
                          <span>Amount</span>
                          <input
                            type="number"
                            value={reviewTransaction.amount}
                            onChange={(event) => setReviewTransaction((current) => current ? { ...current, amount: Number(event.target.value || 0) } : current)}
                            className="input-shell"
                          />
                        </label>

                        <label className="space-y-2 text-sm text-[#563d3f] md:col-span-2">
                          <span>Description</span>
                          <input
                            value={reviewTransaction.description}
                            onChange={(event) => setReviewTransaction((current) => current ? { ...current, description: event.target.value } : current)}
                            className="input-shell"
                          />
                        </label>

                        <label className="space-y-2 text-sm text-[#563d3f]">
                          <span>Category</span>
                          <input
                            value={reviewTransaction.category}
                            onChange={(event) => setReviewTransaction((current) => current ? { ...current, category: event.target.value } : current)}
                            className="input-shell"
                          />
                        </label>

                        <label className="space-y-2 text-sm text-[#563d3f]">
                          <span>Money type</span>
                          <select
                            value={reviewTransaction.businessType}
                            onChange={(event) => setReviewTransaction((current) => current ? { ...current, businessType: event.target.value as BusinessType } : current)}
                            className="input-shell"
                          >
                            <option value="Business">Business</option>
                            <option value="Personal">Personal</option>
                            <option value="Needs Review">Needs Review</option>
                          </select>
                        </label>

                        <label className="space-y-2 text-sm text-[#563d3f]">
                          <span>Date</span>
                          <input
                            type="date"
                            value={reviewTransaction.date}
                            onChange={(event) => setReviewTransaction((current) => current ? { ...current, date: event.target.value } : current)}
                            className="input-shell"
                          />
                        </label>

                        <label className="space-y-2 text-sm text-[#563d3f]">
                          <span>Payment method</span>
                          <select
                            value={reviewTransaction.notes.includes("cash") ? "Cash" : "Bank transfer"}
                            onChange={(event) => setReviewTransaction((current) => current ? { ...current, notes: current.notes.includes("cash") ? current.notes.replace(/cash|Cash/i, event.target.value) : `${current.notes || ""}${current.notes ? " • " : ""}${event.target.value}` } : current)}
                            className="input-shell"
                          >
                            <option value="Bank transfer">Bank transfer</option>
                            <option value="Cash">Cash</option>
                            <option value="Card">Card</option>
                            <option value="Mobile money">Mobile money</option>
                          </select>
                        </label>

                        <label className="space-y-2 text-sm text-[#563d3f] md:col-span-2">
                          <span>Notes</span>
                          <textarea
                            value={reviewTransaction.notes}
                            onChange={(event) => setReviewTransaction((current) => current ? { ...current, notes: event.target.value } : current)}
                            rows={3}
                            className="input-shell min-h-[72px] resize-none"
                          />
                        </label>

                        <div className="flex items-center justify-between rounded-[20px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-4 text-sm text-[#402d2f] md:col-span-2">
                          <span>AI confidence</span>
                          <span className="rounded-full bg-[#eaf6ef] px-3 py-1 text-xs font-medium text-[#2f7f67]">High</span>
                        </div>
                      </div>

                      {reviewError && <div className="mt-4 rounded-xl border border-[#f2d0d0] bg-[#fff4f4] px-3 py-2 text-sm text-[#7a2e36]">{reviewError}</div>}

                      <div className="mt-6 flex justify-end gap-3">
                        <button type="button" onClick={() => setReviewTransaction(null)} className="rounded-full border border-[rgba(109,69,71,0.12)] bg-white px-4 py-2 text-sm font-medium text-[#40292b]">
                          Cancel
                        </button>
                        <button type="button" onClick={saveReviewTransaction} disabled={reviewSaving} className="rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white disabled:cursor-not-allowed disabled:opacity-60">
                          {reviewSaving ? "Saving..." : "Save transaction"}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}

            {activeSection === "Invoices" && (
              <div className="space-y-6">
                <div className="fabby-card rounded-[30px] p-5">
                  <div className="mb-5 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                    <div>
                      <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Invoices</div>
                      <h2 className="mt-2 text-3xl font-semibold text-[#2d1d1d]">Payment tracking</h2>
                    </div>
                    <div className="rounded-full bg-[#f5dfe1] px-3 py-1.5 text-sm text-[#4e3738]">
                      Overdue: {invoices.filter((inv) => inv.status === "Overdue").length}
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-3">
                    <input value={invoiceDraft.customer} onChange={(e) => setInvoiceDraft({ ...invoiceDraft, customer: e.target.value })} placeholder="Customer name" className="input-shell" />
                    <input value={invoiceDraft.amount} onChange={(e) => setInvoiceDraft({ ...invoiceDraft, amount: e.target.value })} placeholder="Amount" className="input-shell" />
                    <div className="flex gap-2">
                      <input value={invoiceDraft.dueDate} onChange={(e) => setInvoiceDraft({ ...invoiceDraft, dueDate: e.target.value })} type="date" className="input-shell" />
                      <button type="button" onClick={addInvoice} disabled={invoiceSaving} className="rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white disabled:opacity-60">
                        {invoiceSaving ? "Saving..." : "Add"}
                      </button>
                    </div>
                  </div>

                  {isLoadingData ? (
                    <div className="mt-6 flex items-center justify-center py-10">
                      <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#2d1d1d] border-t-transparent"></div>
                    </div>
                  ) : invoices.length === 0 ? (
                    <div className="mt-6 rounded-[22px] border border-dashed border-[rgba(109,69,71,0.16)] bg-[#fffaf8] p-10 text-center">
                      <div className="text-xl font-semibold text-[#2d1d1d]">No invoices yet</div>
                      <p className="mt-2 text-sm text-[#5a4547]">
                        Add your first invoice above to start tracking payments from your customers.
                      </p>
                    </div>
                  ) : (
                    <div className="mt-6 overflow-x-auto rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8]">
                      <table className="min-w-full text-left text-sm">
                        <thead className="bg-[#fdf1ee] text-[#584245]">
                          <tr>
                            <th className="px-4 py-3">Invoice</th>
                            <th className="px-4 py-3">Customer</th>
                            <th className="px-4 py-3">Amount</th>
                            <th className="px-4 py-3">Due date</th>
                            <th className="px-4 py-3">Status</th>
                            <th className="px-4 py-3">Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {invoices.map((invoice) => {
                            const isEditing = editingInvoiceId === invoice.id;
                            const isActionLoading = invoiceActionLoadingId === invoice.id;

                            return (
                              <tr key={invoice.id} className="border-t border-[rgba(109,69,71,0.06)]">
                                <td className="px-4 py-3 font-medium">{invoice.id.slice(0, 8).toUpperCase()}</td>
                                <td className="px-4 py-3">
                                  {isEditing ? (
                                    <input
                                      value={invoiceEditDraft.customer}
                                      onChange={(event) => setInvoiceEditDraft((current) => ({ ...current, customer: event.target.value }))}
                                      className="input-shell min-w-[140px]"
                                    />
                                  ) : (
                                    invoice.customer
                                  )}
                                </td>
                                <td className="px-4 py-3 font-semibold">
                                  {isEditing ? (
                                    <input
                                      type="number"
                                      min="0"
                                      value={invoiceEditDraft.amount}
                                      onChange={(event) => setInvoiceEditDraft((current) => ({ ...current, amount: event.target.value }))}
                                      className="input-shell min-w-[100px]"
                                    />
                                  ) : (
                                    formatMoney(invoice.amount)
                                  )}
                                </td>
                                <td className="px-4 py-3">
                                  {isEditing ? (
                                    <input
                                      type="date"
                                      value={invoiceEditDraft.dueDate}
                                      onChange={(event) => setInvoiceEditDraft((current) => ({ ...current, dueDate: event.target.value }))}
                                      className="input-shell min-w-[120px]"
                                    />
                                  ) : (
                                    invoice.dueDate
                                  )}
                                </td>
                                <td className="px-4 py-3">
                                  {isEditing ? (
                                    <select
                                      value={invoiceEditDraft.status}
                                      onChange={(event) =>
                                        setInvoiceEditDraft((current) => ({
                                          ...current,
                                          status: event.target.value as "Paid" | "Unpaid" | "Overdue",
                                        }))
                                      }
                                      className="input-shell min-w-[120px]"
                                    >
                                      <option value="Paid">Paid</option>
                                      <option value="Unpaid">Unpaid</option>
                                      <option value="Overdue">Overdue</option>
                                    </select>
                                  ) : (
                                    <span className={`inline-flex rounded-full px-2.5 py-1 text-xs font-semibold ${
                                      invoice.status === "Paid" ? "bg-[#ddefea] text-[#2f7f67]" : invoice.status === "Unpaid" ? "bg-[#f7e8d8] text-[#8f5c39]" : "bg-[#f7dfe2] text-[#8d505a]"
                                    }`}>
                                      {invoice.status}
                                    </span>
                                  )}
                                </td>
                                <td className="px-4 py-3">
                                  {isEditing ? (
                                    <div className="flex gap-2">
                                      <button
                                        type="button"
                                        onClick={saveInvoiceEdit}
                                        disabled={isActionLoading}
                                        className="rounded-full bg-[#2d1d1d] px-3 py-1.5 text-xs font-medium text-white disabled:opacity-60"
                                      >
                                        {isActionLoading ? "Saving..." : "Save"}
                                      </button>
                                      <button
                                        type="button"
                                        onClick={cancelInvoiceEdit}
                                        className="rounded-full border border-[rgba(109,69,71,0.1)] px-3 py-1.5 text-xs font-medium text-[#4f383b]"
                                      >
                                        Cancel
                                      </button>
                                    </div>
                                  ) : (
                                    <div className="flex gap-2">
                                      <button
                                        type="button"
                                        onClick={() => beginInvoiceEdit(invoice)}
                                        className="rounded-full bg-[#2d1d1d] px-3 py-1.5 text-xs font-medium text-white"
                                      >
                                        Edit
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => {
                                          setInvoiceActionLoadingId(invoice.id);
                                          void onDeleteInvoice(invoice.id).finally(() => setInvoiceActionLoadingId(null));
                                        }}
                                        disabled={isActionLoading}
                                        className="rounded-full border border-[#e7b0b3] bg-[#fdf1f0] px-3 py-1.5 text-xs font-medium text-[#40292b] disabled:opacity-60"
                                      >
                                        {isActionLoading ? "Deleting..." : "Delete"}
                                      </button>
                                    </div>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeSection === "Goals" && (
              <div className="space-y-6">
                <div className="fabby-card rounded-[30px] p-5">
                  <div className="mb-5 flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
                    <div>
                      <div className="text-sm uppercase tracking-[0.18em] text-[#7a5f60]">Business goals</div>
                      <h2 className="mt-2 text-3xl font-semibold text-[#2d1d1d]">Savings targets</h2>
                    </div>
                    <button type="button" className="rounded-full bg-[#2d1d1d] px-4 py-2 text-sm font-medium text-white">
                      Add goal
                    </button>
                  </div>

                  <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                    <input value={newGoal.name} onChange={(e) => setNewGoal({ ...newGoal, name: e.target.value })} placeholder="Goal name" className="input-shell" />
                    <input value={newGoal.targetAmount} onChange={(e) => setNewGoal({ ...newGoal, targetAmount: e.target.value })} placeholder="Target amount" className="input-shell" />
                    <input value={newGoal.currentSavedAmount} onChange={(e) => setNewGoal({ ...newGoal, currentSavedAmount: e.target.value })} placeholder="Saved so far" className="input-shell" />
                    <input value={newGoal.targetDate} onChange={(e) => setNewGoal({ ...newGoal, targetDate: e.target.value })} type="date" className="input-shell" />
                    <input value={newGoal.category} onChange={(e) => setNewGoal({ ...newGoal, category: e.target.value })} placeholder="Category" className="input-shell" />
                    <input value={newGoal.description} onChange={(e) => setNewGoal({ ...newGoal, description: e.target.value })} placeholder="Goal note" className="input-shell" />
                    <div className="md:col-span-2 xl:col-span-3 flex justify-end">
                      <button type="button" onClick={addGoal} className="rounded-full bg-[#d98e95] px-4 py-2 text-sm font-medium text-[#2f2122]">
                        Save goal
                      </button>
                    </div>
                  </div>
                </div>

                <div className="grid gap-5 md:grid-cols-2">
                  {goals.map((goal) => {
                    const contributions = goalContributionMap[goal.id] ?? [];
                    const metrics = getGoalMetrics(goal, contributions);
                    const draft = goalDrafts[goal.id] ?? { amount: "", source: "Business savings", date: getTodayISO(), note: "" };
                    const progress = Math.min(100, metrics.percentComplete);
                    return (
                      <div key={goal.id} className="fabby-card rounded-[28px] p-5">
                        <div className="mb-2 flex items-start justify-between gap-3">
                          <div>
                            <div className="text-lg font-semibold text-[#2d1d1d]">{goal.name}</div>
                            <div className="text-xs uppercase tracking-[0.12em] text-[#7a5e60]">{goal.category}</div>
                          </div>
                          <button type="button" onClick={() => removeGoal(goal.id)} className="text-xs text-[#7a5e60] underline decoration-dotted">Remove</button>
                        </div>
                        <div className="text-sm text-[#69585a]">{goal.description || "No note added yet."}</div>
                        <div className="mt-5 flex items-end justify-between gap-3">
                          <div>
                            <div className="text-2xl font-semibold text-[#2d1d1d]">{formatMoney(metrics.savedAmount)}</div>
                            <div className="text-xs text-[#7a5e60]">of {formatMoney(goal.targetAmount)} by {new Date(goal.targetDate).toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" })}</div>
                          </div>
                          <div className="text-sm font-medium text-[#5c3a3d]">{Math.round(progress)}%</div>
                        </div>
                        <div className="mt-4 h-2.5 rounded-full bg-[#f5e5e3]">
                          <div className="h-full rounded-full bg-[#d98990]" style={{ width: `${progress}%` }} />
                        </div>
                        <div className="mt-4 grid gap-2 text-xs text-[#5f4748] sm:grid-cols-2">
                          <div className="rounded-2xl bg-[#fff5f3] p-2.5">Remaining: {formatMoney(metrics.remainingAmount)}</div>
                          <div className="rounded-2xl bg-[#fff5f3] p-2.5">Required/mo: {formatMoney(metrics.requiredMonthlySavings)}</div>
                          <div className="rounded-2xl bg-[#fff5f3] p-2.5">Pace: {formatMoney(metrics.currentSavingsPace)}/mo</div>
                          <div className="rounded-2xl bg-[#fff5f3] p-2.5">Status: {metrics.status}</div>
                        </div>

                        <div className="mt-5 rounded-[22px] border border-[rgba(109,69,71,0.08)] bg-[#fffaf8] p-3">
                          <div className="mb-2 text-xs font-semibold uppercase tracking-[0.12em] text-[#7a5e60]">Add contribution</div>
                          <div className="grid gap-2 sm:grid-cols-2">
                            <input value={draft.amount} onChange={(e) => setGoalDrafts({ ...goalDrafts, [goal.id]: { ...draft, amount: e.target.value } })} placeholder="Amount" className="input-shell" />
                            <input value={draft.date} onChange={(e) => setGoalDrafts({ ...goalDrafts, [goal.id]: { ...draft, date: e.target.value } })} type="date" className="input-shell" />
                            <input value={draft.source} onChange={(e) => setGoalDrafts({ ...goalDrafts, [goal.id]: { ...draft, source: e.target.value } })} placeholder="Source" className="input-shell" />
                            <input value={draft.note} onChange={(e) => setGoalDrafts({ ...goalDrafts, [goal.id]: { ...draft, note: e.target.value } })} placeholder="Note" className="input-shell" />
                          </div>
                          <div className="mt-3 flex justify-end">
                            <button type="button" onClick={() => updateGoalContribution(goal.id, draft.amount, draft.source, draft.date, draft.note)} className="rounded-full bg-[#2d1d1d] px-3 py-1.5 text-xs font-medium text-white">Save contribution</button>
                          </div>
                        </div>

                        {contributions.length > 0 && (
                          <div className="mt-5">
                            <div className="mb-2 text-xs font-semibold uppercase tracking-[0.12em] text-[#7a5e60]">History</div>
                            <ul className="space-y-2 text-sm text-[#5f4748]">
                              {contributions.slice(0, 4).map((entry) => (
                                <li key={entry.id} className="flex items-center justify-between gap-3 rounded-2xl bg-[#fff5f3] px-3 py-2">
                                  <div>
                                    <div className="font-medium text-[#2d1d1d]">{formatMoney(entry.amount)}</div>
                                    <div className="text-[11px] text-[#7a5e60]">{entry.source || "Business savings"}</div>
                                  </div>
                                  <div className="text-right text-[11px] text-[#7a5e60]">
                                    {new Date(entry.date).toLocaleDateString("en-GB", { day: "2-digit", month: "short" })}
                                  </div>
                                </li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

          </main>
        </div>
      </div>
    </div>
  );
}
