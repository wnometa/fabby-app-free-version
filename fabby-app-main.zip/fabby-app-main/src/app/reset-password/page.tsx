"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useEffect, useState } from "react";
import { BrandFooter, BrandLogo } from "@/components/brand";
import { updatePassword } from "@/lib/auth";
import { createBrowserClient } from "@/lib/supabase/client";

export default function ResetPasswordPage() {
  const router = useRouter();
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [isValidToken, setIsValidToken] = useState(false);
  const [isCheckingToken, setIsCheckingToken] = useState(true);

  // Check if user has a valid recovery token
  useEffect(() => {
    const checkToken = async () => {
      try {
        const supabase = createBrowserClient();
        const { data, error } = await supabase.auth.getSession();
        if (error || !data.session) {
          setErrorMessage(
            "This password reset link is invalid or has expired. Please request a new one.",
          );
          setIsValidToken(false);
        } else {
          setIsValidToken(true);
        }
      } catch (err) {
        console.error("Token check error:", err);
        setErrorMessage("Unable to verify your reset link. Please try again.");
        setIsValidToken(false);
      } finally {
        setIsCheckingToken(false);
      }
    };

    checkToken();
  }, []);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrorMessage("");
    setMessage("");

    if (password.length < 8) {
      setErrorMessage("Password must be at least 8 characters long.");
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage("Passwords do not match.");
      return;
    }

    setIsSubmitting(true);

    try {
      await updatePassword(password);
      setMessage("Your password has been updated successfully. Redirecting to login...");
      setPassword("");
      setConfirmPassword("");

      setTimeout(() => {
        router.push("/login");
        router.refresh();
      }, 2000);
    } catch (error) {
      setErrorMessage(
        error instanceof Error
          ? error.message
          : "Unable to update your password. Please try again.",
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isCheckingToken) {
    return (
      <div className="fabby-shell flex items-center justify-center px-4 py-10 min-h-screen">
        <div className="w-full max-w-md rounded-[28px] border border-[rgba(109,69,71,0.08)] bg-[rgba(255,250,248,0.9)] p-6 shadow-[0_30px_80px_rgba(101,66,67,0.08)] backdrop-blur-sm md:p-8">
          <div className="flex items-center justify-center">
            <div className="h-8 w-8 animate-spin rounded-full border-4 border-[#2d1d1d] border-t-transparent"></div>
          </div>
          <p className="mt-4 text-center text-sm text-[#6d5255]">Verifying your reset link...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fabby-shell flex items-center justify-center px-4 py-10 min-h-screen">
      <div className="w-full max-w-md rounded-[28px] border border-[rgba(109,69,71,0.08)] bg-[rgba(255,250,248,0.9)] p-6 shadow-[0_30px_80px_rgba(101,66,67,0.08)] backdrop-blur-sm md:p-8">
        {/* Logo */}
        <div className="mb-6 text-center">
          <div className="mb-4 flex justify-center">
            <BrandLogo className="h-11 w-11" />
          </div>
          <h1 className="text-3xl font-semibold tracking-tight text-[#2d1d1d]">Set new password</h1>
          <p className="mt-2 text-sm text-[#6d5255]">
            Create a strong password for your FABBY account.
          </p>
        </div>

        {/* Form */}
        {isValidToken ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* New Password */}
            <div>
              <label className="mb-2 block text-sm font-medium text-[#422d30]">New password</label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  className="input-shell pr-11"
                  placeholder="Enter a new password (8+ characters)"
                  disabled={isSubmitting}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((current) => !current)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium text-[#5e4348] hover:text-[#2d1d1d]"
                  tabIndex={-1}
                >
                  {showPassword ? "Hide" : "Show"}
                </button>
              </div>
            </div>

            {/* Confirm Password */}
            <div>
              <label className="mb-2 block text-sm font-medium text-[#422d30]">
                Confirm new password
              </label>
              <input
                type={showPassword ? "text" : "password"}
                value={confirmPassword}
                onChange={(event) => setConfirmPassword(event.target.value)}
                className="input-shell"
                placeholder="Repeat your new password"
                disabled={isSubmitting}
                required
              />
            </div>

            {/* Messages */}
            {message && (
              <div className="rounded-2xl border border-[#c7f0d8] bg-[#f2fcf7] px-3 py-2 text-sm text-[#0f6938]">
                {message}
              </div>
            )}

            {errorMessage && (
              <div className="rounded-2xl border border-[#f0c7c9] bg-[#fff2f3] px-3 py-2 text-sm text-[#7a3f44]">
                {errorMessage}
              </div>
            )}

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full rounded-full bg-[#2d1d1d] px-5 py-3 text-sm font-medium text-white transition disabled:cursor-not-allowed disabled:opacity-70 hover:bg-[#1a0f10]"
            >
              {isSubmitting ? "Updating password..." : "Update password"}
            </button>
          </form>
        ) : (
          <div className="rounded-2xl border border-[#f0c7c9] bg-[#fff2f3] px-4 py-3 text-sm text-[#7a3f44]">
            <p className="mb-4">{errorMessage}</p>
            <Link
              href="/forgot-password"
              className="inline-block rounded-full bg-[#2d1d1d] px-4 py-2 text-xs font-medium text-white hover:bg-[#1a0f10]"
            >
              Request new reset link
            </Link>
          </div>
        )}

        {/* Back to Login Link */}
        <div className="mt-6 text-center text-sm text-[#5f4a4d]">
          <Link href="/login" className="font-semibold text-[#8c5962] hover:underline">
            Back to login
          </Link>
        </div>

        {/* Brand Footer */}
        <div className="mt-6">
          <BrandFooter className="!text-[11px]" />
        </div>
      </div>
    </div>
  );
}
