import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { AuthProvider } from "@/contexts/auth-context";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL("http://localhost:3000"),
  title: "FABBY | Your business numbers, finally making sense.",
  description:
    "FABBY helps businesses track what happened, understand their money, and decide what to do next.",
  applicationName: "FABBY",
  keywords: ["bookkeeping", "AI bookkeeping", "cash flow", "business finance"],
  authors: [{ name: "Wiltecon Technologies" }],
  icons: {
    icon: "/brand/favicon.svg",
    shortcut: "/brand/favicon.svg",
    apple: "/brand/favicon.svg",
  },
  openGraph: {
    title: "FABBY | Your business numbers, finally making sense.",
    description:
      "AI-powered bookkeeping and business insights designed to clarify your numbers and decisions.",
    siteName: "FABBY",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "FABBY | Your business numbers, finally making sense.",
    description:
      "AI-powered bookkeeping and business insights designed to clarify your numbers and decisions.",
  },
};

export default function RootLayout({ children }: LayoutProps<"/">) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
    >
      <body className="min-h-full flex flex-col">
        <AuthProvider>{children}</AuthProvider>
      </body>
    </html>
  );
}
