"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { BrandFooter, BrandLogo } from "@/components/brand";
import { signUpWithEmail } from "@/lib/auth";

export default function SignupPage() {
  const router = useRouter();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrorMessage("");
    setSuccessMessage("");

    // Validation
    if (!fullName.trim()) {
      setErrorMessage("Please enter your full name.");
      return;
    }

    if (!email.trim()) {
      setErrorMessage("Please enter your email address.");
      return;
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setErrorMessage("Please enter a valid email address.");
      return;
    }

    if (password.length < 8) {
      setErrorMessage("Password must be at least 8 characters long.");
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage("Passwords do not match.");
      return;
    }

    setIsSubmitting(true);

    try {
      const result = await signUpWithEmail({
        fullName: fullName.trim(),
        email: email.trim(),
        password,
      });

      // Check if email confirmation is required
      if (result.requiresEmailConfirmation) {
        setSuccessMessage(
          "Account created! Please check your email to verify your FABBY account before signing in.",
        );
        setFullName("");
        setEmail("");
        setPassword("");
        setConfirmPassword("");
        
        // Redirect to login after a short delay
        setTimeout(() => {
          router.push("/login");
        }, 3000);
      } else {
        // Email confirmation not required, user can go to dashboard
        setSuccessMessage("Account created successfully! Redirecting to dashboard...");
        setTimeout(() => {
          router.push("/dashboard");
          router.refresh();
        }, 1500);
      }
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : "Unable to create account. Please try again.",
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fabby-shell flex items-center justify-center px-4 py-10 min-h-screen">
      <div className="w-full max-w-md rounded-[28px] border border-[rgba(109,69,71,0.08)] bg-[rgba(255,250,248,0.9)] p-6 shadow-[0_30px_80px_rgba(101,66,67,0.08)] backdrop-blur-sm md:p-8">
        {/* Logo */}
        <div className="mb-7 flex items-center justify-center">
          <BrandLogo className="h-11 w-11" />
        </div>

        {/* Header */}
        <div className="mb-6 text-center">
          <h1 className="text-3xl font-semibold tracking-tight text-[#2d1d1d]">Start tracking smarter</h1>
          <p className="mt-2 text-sm text-[#6d5255]">
            Create your FABBY account to begin managing your finances intelligently.
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Full Name */}
          <div>
            <label className="mb-2 block text-sm font-medium text-[#422d30]">Full name</label>
            <input
              type="text"
              value={fullName}
              onChange={(event) => setFullName(event.target.value)}
              placeholder="Ada Okafor"
              className="input-shell"
              disabled={isSubmitting}
              required
            />
          </div>

          {/* Email */}
          <div>
            <label className="mb-2 block text-sm font-medium text-[#422d30]">Email</label>
            <input
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="you@company.com"
              className="input-shell"
              autoComplete="email"
              disabled={isSubmitting}
              required
            />
          </div>

          {/* Password */}
          <div>
            <label className="mb-2 block text-sm font-medium text-[#422d30]">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="Create a strong password (8+ characters)"
                className="input-shell pr-11"
                disabled={isSubmitting}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword((current) => !current)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium text-[#5e4348] hover:text-[#2d1d1d]"
                tabIndex={-1}
              >
                {showPassword ? "Hide" : "Show"}
              </button>
            </div>
          </div>

          {/* Confirm Password */}
          <div>
            <label className="mb-2 block text-sm font-medium text-[#422d30]">Confirm password</label>
            <input
              type={showPassword ? "text" : "password"}
              value={confirmPassword}
              onChange={(event) => setConfirmPassword(event.target.value)}
              placeholder="Repeat your password"
              className="input-shell"
              disabled={isSubmitting}
              required
            />
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="rounded-2xl border border-[#f0c7c9] bg-[#fff2f3] px-3 py-2 text-sm text-[#7a3f44]">
              {errorMessage}
            </div>
          )}

          {/* Success Message */}
          {successMessage && (
            <div className="rounded-2xl border border-[#c7f0d8] bg-[#f2fcf7] px-3 py-2 text-sm text-[#0f6938]">
              {successMessage}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full rounded-full bg-[#2d1d1d] px-5 py-3 text-sm font-medium text-white transition disabled:cursor-not-allowed disabled:opacity-70 hover:bg-[#1a0f10]"
          >
            {isSubmitting ? "Creating account..." : "Create account"}
          </button>
        </form>

        {/* Login Link */}
        <div className="mt-6 text-center text-sm text-[#5f4a4d]">
          Already have an account?{" "}
          <Link href="/login" className="font-semibold text-[#8c5962] hover:underline">
            Sign in
          </Link>
        </div>

        {/* Brand Footer */}
        <div className="mt-6 rounded-2xl border border-[rgba(109,69,71,0.08)] bg-[#fffaf7] p-4 text-center">
          <BrandFooter />
        </div>
      </div>
    </div>
  );
}
