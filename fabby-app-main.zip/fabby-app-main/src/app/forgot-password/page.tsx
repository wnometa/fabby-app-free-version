"use client";

import Link from "next/link";
import { FormEvent, useState } from "react";
import { BrandFooter, BrandLogo } from "@/components/brand";
import { resetPasswordForEmail } from "@/lib/auth";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [message, setMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setMessage("");
    setErrorMessage("");

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      setErrorMessage("Please enter a valid email address.");
      return;
    }

    setIsSubmitting(true);

    try {
      await resetPasswordForEmail(email);
      setMessage("If an account exists for that email, a reset link will be sent.");
      setEmail("");
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : "Unable to send a password reset email right now.",
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fabby-shell flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-md rounded-[28px] border border-[rgba(109,69,71,0.08)] bg-[rgba(255,250,248,0.9)] p-6 shadow-[0_30px_80px_rgba(101,66,67,0.08)] backdrop-blur-sm md:p-8">
        <div className="mb-6 text-center">
          <div className="mb-4 flex justify-center">
            <BrandLogo className="h-11 w-11" />
          </div>
          <h1 className="text-3xl font-semibold tracking-tight text-[#2d1d1d]">Reset password</h1>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="mb-2 block text-sm font-medium text-[#422d30]">Email</label>
            <input
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              className="input-shell"
              placeholder="you@company.com"
            />
          </div>

          {message ? (
            <div className="rounded-2xl border border-[#dfece5] bg-[#eefaf5] px-3 py-2 text-sm text-[#234d3d]">
              {message}
            </div>
          ) : null}

          {errorMessage ? (
            <div className="rounded-2xl border border-[#f0c7c9] bg-[#fff2f3] px-3 py-2 text-sm text-[#7a3f44]">
              {errorMessage}
            </div>
          ) : null}

          <button
            type="submit"
            disabled={isSubmitting}
            className="flex w-full items-center justify-center rounded-full bg-[#2d1d1d] px-5 py-3 text-sm font-medium text-white transition disabled:cursor-not-allowed disabled:opacity-70"
          >
            {isSubmitting ? "Sending reset link..." : "Send reset link"}
          </button>
        </form>

        <div className="mt-5 text-center text-sm text-[#5f4a4d]">
          <Link href="/login" className="font-semibold text-[#8c5962] hover:underline">Back to login</Link>
        </div>

        <div className="mt-6">
          <BrandFooter className="!text-[11px]" />
        </div>
      </div>
    </div>
  );
}
