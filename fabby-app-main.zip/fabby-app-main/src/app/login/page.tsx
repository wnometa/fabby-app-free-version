"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { FormEvent, useState } from "react";
import { BrandFooter, BrandLogo } from "@/components/brand";
import { signInWithEmail } from "@/lib/auth";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrorMessage("");

    if (!email.trim() || !password.trim()) {
      setErrorMessage("Email and password are required.");
      return;
    }

    setIsSubmitting(true);

    try {
      const { session } = await signInWithEmail(email, password);
      
      // Only navigate after confirming the session is actually valid.
      // This prevents the dashboard guard from seeing stale auth state.
      if (session) {
        router.push("/dashboard");
        router.refresh();
      } else {
        setErrorMessage("Sign in succeeded but session not established. Please try again.");
      }
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : "Unable to log in. Please try again.",
      );
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fabby-shell flex items-center justify-center px-4 py-10 min-h-screen">
      <div className="w-full max-w-md rounded-[28px] border border-[rgba(109,69,71,0.08)] bg-[rgba(255,250,248,0.9)] p-6 shadow-[0_30px_80px_rgba(101,66,67,0.08)] backdrop-blur-sm md:p-8">
        {/* Logo */}
        <div className="mb-7 flex items-center justify-center">
          <BrandLogo className="h-11 w-11" />
        </div>

        {/* Header */}
        <div className="mb-6 text-center">
          <h1 className="text-3xl font-semibold tracking-tight text-[#2d1d1d]">Welcome back</h1>
          <p className="mt-2 text-sm text-[#6d5255]">
            Sign in to access your FABBY dashboard and manage your finances.
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Email */}
          <div>
            <label className="mb-2 block text-sm font-medium text-[#422d30]">Email</label>
            <input
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="you@company.com"
              className="input-shell"
              autoComplete="email"
              disabled={isSubmitting}
              required
            />
          </div>

          {/* Password */}
          <div>
            <label className="mb-2 block text-sm font-medium text-[#422d30]">Password</label>
            <div className="relative">
              <input
                type={showPassword ? "text" : "password"}
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="••••••••"
                className="input-shell pr-11"
                autoComplete="current-password"
                disabled={isSubmitting}
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword((current) => !current)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-medium text-[#5e4348] hover:text-[#2d1d1d]"
                tabIndex={-1}
              >
                {showPassword ? "Hide" : "Show"}
              </button>
            </div>
          </div>

          {/* Forgot Password Link */}
          <div className="flex justify-end">
            <Link href="/forgot-password" className="text-sm font-medium text-[#8b5961] hover:underline">
              Forgot password?
            </Link>
          </div>

          {/* Error Message */}
          {errorMessage && (
            <div className="rounded-2xl border border-[#f0c7c9] bg-[#fff2f3] px-3 py-2 text-sm text-[#7a3f44]">
              {errorMessage}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full rounded-full bg-[#2d1d1d] px-5 py-3 text-sm font-medium text-white transition disabled:cursor-not-allowed disabled:opacity-70 hover:bg-[#1a0f10]"
          >
            {isSubmitting ? "Signing in..." : "Sign in"}
          </button>
        </form>

        {/* Sign Up Link */}
        <div className="mt-6 text-center text-sm text-[#5f4a4d]">
          Don&apos;t have an account?{" "}
          <Link href="/signup" className="font-semibold text-[#8c5962] hover:underline">
            Create account
          </Link>
        </div>

        {/* Brand Footer */}
        <div className="mt-8 rounded-2xl border border-[rgba(109,69,71,0.08)] bg-[#fffaf7] p-4 text-center">
          <BrandFooter />
        </div>
      </div>
    </div>
  );
}
