"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { BrandFooter, BrandLogo } from "@/components/brand";
import { createBrowserClient } from "@/lib/supabase/client";

/**
 * Email verification page
 * Shown to users who haven't verified their email yet
 */
export default function VerifyEmailPage() {
  const router = useRouter();
  const [isResending, setIsResending] = useState(false);
  const [message, setMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  const handleResendEmail = async () => {
    setIsResending(true);
    setMessage("");
    setErrorMessage("");

    try {
      const supabase = createBrowserClient();
      const { data: authData } = await supabase!.auth.getUser();

      if (!authData.user?.email) {
        throw new Error("Unable to identify your email address.");
      }

      const { error } = await supabase!.auth.resend({
        type: "signup",
        email: authData.user.email,
      });

      if (error) {
        throw error;
      }

      setMessage("Verification email sent! Check your inbox.");
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : "Failed to resend verification email.",
      );
    } finally {
      setIsResending(false);
    }
  };

  const handleLogOut = async () => {
    try {
      const supabase = createBrowserClient();
      await supabase!.auth.signOut();
      router.push("/login");
      router.refresh();
    } catch (error) {
      console.error("Sign out error:", error);
    }
  };

  return (
    <div className="fabby-shell flex items-center justify-center px-4 py-10 min-h-screen">
      <div className="w-full max-w-md rounded-[28px] border border-[rgba(109,69,71,0.08)] bg-[rgba(255,250,248,0.9)] p-6 shadow-[0_30px_80px_rgba(101,66,67,0.08)] backdrop-blur-sm md:p-8">
        {/* Logo */}
        <div className="mb-7 flex items-center justify-center">
          <BrandLogo className="h-11 w-11" />
        </div>

        {/* Header */}
        <div className="mb-6 text-center">
          <div className="mb-4 text-4xl">✉️</div>
          <h1 className="text-2xl font-semibold tracking-tight text-[#2d1d1d]">
            Verify your email
          </h1>
          <p className="mt-2 text-sm text-[#6d5255]">
            We&apos;ve sent a verification link to your email address. Click the link to activate your FABBY account.
          </p>
        </div>

        {/* Messages */}
        {message && (
          <div className="mb-4 rounded-2xl border border-[#c7f0d8] bg-[#f2fcf7] px-3 py-2 text-sm text-[#0f6938]">
            {message}
          </div>
        )}

        {errorMessage && (
          <div className="mb-4 rounded-2xl border border-[#f0c7c9] bg-[#fff2f3] px-3 py-2 text-sm text-[#7a3f44]">
            {errorMessage}
          </div>
        )}

        {/* Instructions */}
        <div className="mb-6 rounded-2xl border border-[rgba(109,69,71,0.08)] bg-[#fffaf7] px-4 py-3">
          <p className="text-sm text-[#422d30]">
            <strong>Didn&apos;t receive the email?</strong>
          </p>
          <ul className="mt-2 list-inside list-disc space-y-1 text-xs text-[#6d5255]">
            <li>Check your spam or junk folder</li>
            <li>Make sure you entered the correct email address</li>
            <li>Request a new verification email below</li>
          </ul>
        </div>

        {/* Resend Button */}
        <button
          onClick={handleResendEmail}
          disabled={isResending}
          className="w-full rounded-full bg-[#2d1d1d] px-5 py-3 text-sm font-medium text-white transition disabled:cursor-not-allowed disabled:opacity-70 hover:bg-[#1a0f10]"
        >
          {isResending ? "Sending..." : "Resend verification email"}
        </button>

        {/* Log Out Link */}
        <div className="mt-6 text-center text-sm text-[#5f4a4d]">
          <button
            onClick={handleLogOut}
            className="font-semibold text-[#8c5962] hover:underline"
          >
            Log out and use a different account
          </button>
        </div>

        {/* Brand Footer */}
        <div className="mt-8 rounded-2xl border border-[rgba(109,69,71,0.08)] bg-[#fffaf7] p-4 text-center">
          <BrandFooter />
        </div>
      </div>
    </div>
  );
}
