import { createBrowserClient } from "@/lib/supabase/client";

export type GoalStatus = "On Track" | "Behind" | "Ahead" | "Completed" | "At Risk";

export type GoalContribution = {
  id: string;
  goalId: string;
  userId: string;
  amount: number;
  date: string;
  source: string;
  note: string;
  createdAt: string;
  updatedAt: string;
};

export type Goal = {
  id: string;
  userId: string;
  name: string;
  targetAmount: number;
  currentSavedAmount: number;
  targetDate: string;
  description: string;
  category: string;
  createdAt: string;
  updatedAt: string;
};

export type GoalMetrics = {
  savedAmount: number;
  remainingAmount: number;
  percentComplete: number;
  daysRemaining: number;
  requiredMonthlySavings: number;
  currentSavingsPace: number;
  estimatedCompletionDate: string | null;
  status: GoalStatus;
  statusLabel: string;
  isCompleted: boolean;
};

function toDateOnly(value: string | null | undefined) {
  if (!value) return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return null;
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
}

const GOALS_KEY = "fabby-goals";
const CONTRIBUTIONS_KEY = "fabby-goal-contributions";

function readStore<T>(key: string): Record<string, T[]> {
  if (typeof window === "undefined") return {} as Record<string, T[]>;

  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as Record<string, T[]>) : {};
  } catch {
    return {} as Record<string, T[]>;
  }
}

function writeStore<T>(key: string, value: Record<string, T[]>) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, JSON.stringify(value));
}

export function readGoals(userId?: string): Goal[] {
  const keyUserId = userId ?? "local-user";
  const all = readStore<Goal>(GOALS_KEY);
  const userGoals = all[keyUserId] ?? [];
  return userGoals.map((goal) => ({
    ...goal,
    targetAmount: Number(goal.targetAmount ?? 0),
    currentSavedAmount: Number(goal.currentSavedAmount ?? 0),
    description: goal.description ?? "",
    category: goal.category ?? "General",
  }));
}

export function saveGoals(goals: Goal[], userId?: string) {
  if (typeof window === "undefined") return;
  const keyUserId = userId ?? "local-user";
  const store = readStore<Goal>(GOALS_KEY);
  store[keyUserId] = goals;
  writeStore(GOALS_KEY, store);
}

export async function fetchGoals(userId?: string): Promise<Goal[]> {
  if (!userId) return readGoals();

  const supabase = createBrowserClient();
  const { data, error } = await supabase.from("goals").select("*").eq("user_id", userId).order("created_at", { ascending: false });
  if (error) {
    console.error("Failed to load goals:", error);
    return readGoals(userId);
  }

  const nextGoals = (data ?? []).map((row) => ({
    id: row.id,
    userId: row.user_id,
    name: row.name,
    targetAmount: Number(row.target_amount ?? 0),
    currentSavedAmount: Number(row.current_amount ?? 0),
    targetDate: row.target_date ?? new Date().toISOString().slice(0, 10),
    description: row.description ?? "",
    category: row.category ?? "General",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  }));

  saveGoals(nextGoals, userId);
  return nextGoals;
}

export function readGoalContributions(goalId?: string, userId?: string): GoalContribution[] {
  const keyUserId = userId ?? "local-user";
  const all = readStore<GoalContribution>(CONTRIBUTIONS_KEY);
  const chunks = goalId ? all[`${keyUserId}:${goalId}`] ?? [] : Object.entries(all)
    .filter(([key]) => key.startsWith(`${keyUserId}:`))
    .flatMap(([, value]) => value ?? []);

  return (Array.isArray(chunks) ? chunks : []).map((contribution) => ({
    ...contribution,
    amount: Number(contribution.amount ?? 0),
    source: contribution.source ?? "Business savings",
    note: contribution.note ?? "",
  }));
}

export function saveGoalContributions(goalId: string, contributions: GoalContribution[], userId?: string) {
  if (typeof window === "undefined") return;
  const keyUserId = userId ?? "local-user";
  const store = readStore<GoalContribution>(CONTRIBUTIONS_KEY);
  store[`${keyUserId}:${goalId}`] = contributions;
  writeStore(CONTRIBUTIONS_KEY, store);
}

export async function fetchGoalContributions(goalId?: string, userId?: string): Promise<GoalContribution[]> {
  if (!userId) return readGoalContributions(goalId, userId);

  const supabase = createBrowserClient();
  let query = supabase.from("goal_contributions").select("*").eq("user_id", userId);
  if (goalId) {
    query = query.eq("goal_id", goalId);
  }

  const { data, error } = await query.order("contribution_date", { ascending: false });
  if (error) {
    console.error("Failed to load goal contributions:", error);
    return readGoalContributions(goalId, userId);
  }

  const nextContributions = (data ?? []).map((row) => ({
    id: row.id,
    goalId: row.goal_id,
    userId: row.user_id,
    amount: Number(row.amount ?? 0),
    date: row.contribution_date,
    source: row.source ?? "Business savings",
    note: row.note ?? "",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  }));

  if (goalId) {
    saveGoalContributions(goalId, nextContributions, userId);
  }
  return nextContributions;
}

export function readGoalContributionMap(userId?: string): Record<string, GoalContribution[]> {
  const all = readStore<GoalContribution>(CONTRIBUTIONS_KEY);
  const map: Record<string, GoalContribution[]> = {};

  Object.entries(all).forEach(([key, value]) => {
    const targetUserId = userId ?? "local-user";
    if (!key.startsWith(`${targetUserId}:`)) return;
    const goalId = key.slice(targetUserId.length + 1);
    map[goalId] = Array.isArray(value) ? value.map((entry) => ({
      ...entry,
      amount: Number(entry.amount ?? 0),
      source: entry.source ?? "Business savings",
      note: entry.note ?? "",
    })) : [];
  });

  return map;
}

export function getGoalSavedTotal(goal: Goal, contributions: GoalContribution[]) {
  const contribTotal = contributions.reduce((sum, contribution) => sum + Number(contribution.amount ?? 0), 0);
  return Math.max(Number(goal.currentSavedAmount ?? 0), contribTotal);
}

export function getGoalMetrics(goal: Goal, contributions: GoalContribution[] = []): GoalMetrics {
  const savedAmount = getGoalSavedTotal(goal, contributions);
  const targetAmount = Number(goal.targetAmount ?? 0);
  const remainingAmount = Math.max(targetAmount - savedAmount, 0);
  const percentComplete = targetAmount > 0 ? Math.min((savedAmount / targetAmount) * 100, 100) : 0;
  const today = new Date();
  const targetDate = new Date(goal.targetDate);
  const daysRemaining = targetDate && !Number.isNaN(targetDate.getTime())
    ? Math.max(Math.ceil((targetDate.getTime() - today.getTime()) / 86400000), 0)
    : 0;

  const monthsRemaining = daysRemaining > 0 ? Math.max(daysRemaining / 30.437, 0.25) : 0;
  const requiredMonthlySavings = remainingAmount > 0 && monthsRemaining > 0 ? remainingAmount / monthsRemaining : 0;

  let currentSavingsPace = 0;
  if (contributions.length > 0) {
    const oldestDate = contributions.reduce((min, contribution) => {
      const candidate = new Date(contribution.date);
      return candidate < min ? candidate : min;
    }, new Date(contributions[0].date));

    const daysTracked = Math.max((today.getTime() - oldestDate.getTime()) / 86400000, 30);
    const totalContribution = contributions.reduce((sum, contribution) => sum + Number(contribution.amount ?? 0), 0);
    currentSavingsPace = totalContribution / (daysTracked / 30.437);
  }

  const estimatedCompletionDate = (() => {
    if (savedAmount >= targetAmount) return toDateOnly(goal.targetDate) ?? new Date().toISOString().slice(0, 10);
    if (currentSavingsPace <= 0 || remainingAmount <= 0) return null;
    const monthsNeeded = remainingAmount / currentSavingsPace;
    const estimate = new Date(today.getTime() + monthsNeeded * 30.437 * 86400000);
    return estimate.toISOString().slice(0, 10);
  })();

  let status: GoalStatus = "At Risk";
  if (savedAmount >= targetAmount) {
    status = "Completed";
  } else if (currentSavingsPace <= 0) {
    status = "At Risk";
  } else if (currentSavingsPace >= requiredMonthlySavings * 1.1) {
    status = "Ahead";
  } else if (currentSavingsPace >= requiredMonthlySavings * 0.9) {
    status = "On Track";
  } else if (daysRemaining <= 30) {
    status = "At Risk";
  } else {
    status = "Behind";
  }

  const statusLabel = {
    "On Track": "On track to reach your target by the deadline.",
    Behind: "Your current savings pace may not be enough to reach the target date.",
    Ahead: "You are currently ahead of the pace required to reach the goal.",
    Completed: "Goal achieved.",
    "At Risk": "This goal needs attention to stay on course.",
  }[status];

  return { savedAmount, remainingAmount, percentComplete, daysRemaining, requiredMonthlySavings, currentSavingsPace, estimatedCompletionDate, status, statusLabel, isCompleted: status === "Completed" };
}

export function getGoalOverview(goals: Goal[], contributionsMap: Record<string, GoalContribution[]>) {
  const totalActiveGoals = goals.length;
  const totalSaved = goals.reduce((sum, goal) => sum + getGoalSavedTotal(goal, contributionsMap[goal.id] ?? []), 0);
  const totalTarget = goals.reduce((sum, goal) => sum + Number(goal.targetAmount ?? 0), 0);
  const overallProgress = totalTarget > 0 ? Math.min((totalSaved / totalTarget) * 100, 100) : 0;
  const goalsOnTrack = goals.filter((goal) => getGoalMetrics(goal, contributionsMap[goal.id] ?? []).status === "On Track").length;
  const goalsBehind = goals.filter((goal) => getGoalMetrics(goal, contributionsMap[goal.id] ?? []).status === "Behind").length;
  const goalsCompleted = goals.filter((goal) => getGoalMetrics(goal, contributionsMap[goal.id] ?? []).status === "Completed").length;

  return { totalActiveGoals, totalSaved, totalTarget, overallProgress, goalsOnTrack, goalsBehind, goalsCompleted };
}

export function createGoalRecord(input: { name: string; targetAmount: number; currentSavedAmount: number; targetDate: string; description: string; category: string; userId?: string; }) {
  const userId = input.userId ?? "";
  const targetAmount = Number(input.targetAmount ?? 0);
  const currentSavedAmount = Number(input.currentSavedAmount ?? 0);
  const name = input.name.trim();

  if (!name) throw new Error("Goal name is required.");
  if (!Number.isFinite(targetAmount) || targetAmount <= 0) throw new Error("Target amount must be greater than zero.");
  if (!input.targetDate) throw new Error("Target date is required.");

  return {
    id: `goal-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    userId,
    name,
    targetAmount,
    currentSavedAmount,
    targetDate: input.targetDate,
    description: input.description?.trim() ?? "",
    category: input.category?.trim() || "General",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  } satisfies Goal;
}

export function createContributionRecord(input: { goalId: string; userId?: string; amount: number; date: string; source: string; note: string; }) {
  const amount = Number(input.amount ?? 0);
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Contribution amount must be greater than zero.");
  if (!input.date) throw new Error("Contribution date is required.");

  return {
    id: `contribution-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    goalId: input.goalId,
    userId: input.userId ?? "",
    amount,
    date: input.date,
    source: input.source?.trim() || "Business savings",
    note: input.note?.trim() || "",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  } satisfies GoalContribution;
}
