import type { LedgerEntry } from "@/lib/financial-ledger";

export type InsightPriority = "HIGH PRIORITY" | "IMPORTANT" | "WATCH" | "OPPORTUNITY" | "POSITIVE";

export type Insight = {
  id: string;
  title: string;
  category: string;
  priority: InsightPriority;
  explanation: string;
  metric: string;
  whyThisMatters: string;
  recommendedAction: string;
  details: {
    previousPeriod: number;
    currentPeriod: number;
    difference: number;
    relevantCategories: string[];
    transactions: Array<Pick<LedgerEntry, "id" | "date" | "description" | "category" | "amount" | "moneyType">>;
  };
};

export type InsightData = {
  insights: Insight[];
  aiAnswer: string;
  hasEnoughData: boolean;
  totalIncome: number;
  totalExpenses: number;
  netCashFlow: number;
  largestExpenseCategory: string | null;
};

type BuildOptions = {
  includeGoals?: boolean;
  askFabbyPrompt?: string;
};

const currency = new Intl.NumberFormat("en-NG", {
  style: "currency",
  currency: "NGN",
  maximumFractionDigits: 0,
});

function formatMoney(value: number) {
  return currency.format(value);
}

function formatPercent(value: number) {
  return `${Math.abs(value).toFixed(0)}%`;
}

function getDateOnly(value: string | undefined) {
  if (!value) return null;
  const date = new Date(`${value}T00:00:00`);
  return Number.isNaN(date.getTime()) ? null : date;
}

function getWindow(startDaysAgo: number, endDaysAgo: number) {
  const end = new Date();
  end.setHours(23, 59, 59, 999);
  const start = new Date();
  start.setDate(start.getDate() - startDaysAgo);
  start.setHours(0, 0, 0, 0);

  const previousEnd = new Date(end);
  previousEnd.setDate(previousEnd.getDate() - endDaysAgo);
  const previousStart = new Date(end);
  previousStart.setDate(previousStart.getDate() - startDaysAgo);
  previousStart.setHours(0, 0, 0, 0);

  return { currentStart: start, currentEnd: end, previousStart, previousEnd };
}

function summarize(entries: LedgerEntry[]) {
  const income = entries.filter((entry) => entry.type === "Income").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0);
  const expenses = entries.filter((entry) => entry.type === "Expense").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0);
  const net = income - expenses;

  const categoryTotals = new Map<string, number>();
  for (const entry of entries) {
    if (entry.type !== "Expense") continue;
    categoryTotals.set(entry.category, (categoryTotals.get(entry.category) ?? 0) + Number(entry.amount ?? 0));
  }

  const largestExpenseCategory = Array.from(categoryTotals.entries()).sort((a, b) => b[1] - a[1])[0];

  return {
    income,
    expenses,
    net,
    largestExpenseCategory: largestExpenseCategory ? largestExpenseCategory[0] : null,
    largestExpenseAmount: largestExpenseCategory ? largestExpenseCategory[1] : 0,
  };
}

function calculatePercentChange(current: number, previous: number) {
  if (previous === 0) {
    return current === 0 ? 0 : 100;
  }
  return ((current - previous) / previous) * 100;
}

function getTransactionsForInsight(entries: LedgerEntry[], keepType?: "Income" | "Expense", category?: string) {
  return entries
    .filter((entry) => (keepType ? entry.type === keepType : true))
    .filter((entry) => (category ? entry.category === category : true))
    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
    .slice(0, 5)
    .map((entry) => ({
      id: entry.id,
      date: entry.date,
      description: entry.description,
      category: entry.category,
      amount: Number(entry.amount ?? 0),
      moneyType: entry.moneyType,
    }));
}

function buildPriority(change: number): InsightPriority {
  if (change > 25) return "HIGH PRIORITY";
  if (change > 10) return "IMPORTANT";
  if (change < -15) return "WATCH";
  if (change > 0) return "OPPORTUNITY";
  return "POSITIVE";
}

export function buildInsights(entries: LedgerEntry[], options: BuildOptions = {}): InsightData {
  const entriesWithTime = entries.filter((entry) => !!getDateOnly(entry.date));
  const hasEnoughData = entriesWithTime.length >= 4;

  if (!hasEnoughData) {
    return {
      insights: [],
      aiAnswer: "I don't have enough financial history to make a reliable comparison yet. Add income and expenses to start building your financial picture.",
      hasEnoughData: false,
      totalIncome: 0,
      totalExpenses: 0,
      netCashFlow: 0,
      largestExpenseCategory: null,
    };
  }

  const { currentStart, currentEnd, previousStart, previousEnd } = getWindow(30, 60);

  const currentWindow = entriesWithTime.filter((entry) => {
    const date = getDateOnly(entry.date);
    if (!date) return false;
    return date >= currentStart && date <= currentEnd;
  });

  const previousWindow = entriesWithTime.filter((entry) => {
    const date = getDateOnly(entry.date);
    if (!date) return false;
    return date >= previousStart && date <= previousEnd;
  });

  const currentSummary = summarize(currentWindow);
  const previousSummary = summarize(previousWindow);

  const businessIncome = currentWindow.filter((entry) => entry.type === "Income" && entry.moneyType === "Business").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0);
  const businessExpenses = currentWindow.filter((entry) => entry.type === "Expense" && entry.moneyType === "Business").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0);

  const averageExpense = currentWindow.filter((entry) => entry.type === "Expense").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0) / Math.max(currentWindow.filter((entry) => entry.type === "Expense").length, 1);
  const unusualExpense = currentWindow.filter((entry) => entry.type === "Expense" && Number(entry.amount ?? 0) > averageExpense * 2.5).slice(0, 1);

  const topExpenseCategory = Array.from(
    currentWindow
      .filter((entry) => entry.type === "Expense")
      .reduce((map, entry) => {
        const category = entry.category || "Other";
        map.set(category, (map.get(category) ?? 0) + Number(entry.amount ?? 0));
        return map;
      }, new Map<string, number>())
      .entries(),
  ).sort((a, b) => b[1] - a[1])[0];

  const topIncomeCategory = Array.from(
    currentWindow
      .filter((entry) => entry.type === "Income")
      .reduce((map, entry) => {
        const category = entry.category || "Other";
        map.set(category, (map.get(category) ?? 0) + Number(entry.amount ?? 0));
        return map;
      }, new Map<string, number>())
      .entries(),
  ).sort((a, b) => b[1] - a[1])[0];

  const largestPersonalCategory = Array.from(
    currentWindow
      .filter((entry) => entry.type === "Expense" && entry.moneyType === "Personal")
      .reduce((map, entry) => {
        map.set(entry.category, (map.get(entry.category) ?? 0) + Number(entry.amount ?? 0));
        return map;
      }, new Map<string, number>())
      .entries(),
  ).sort((a, b) => b[1] - a[1])[0];

  const insights: Insight[] = [];

  if (currentSummary.net !== 0 || currentSummary.income > 0 || currentSummary.expenses > 0) {
    const netDirection = currentSummary.net >= 0 ? "positive" : "under pressure";
    const healthPriority: InsightPriority = currentSummary.net >= 0 ? "POSITIVE" : "HIGH PRIORITY";
    const healthExplanation =
      currentSummary.net >= 0
        ? `Your current cash flow is positive, with ${formatMoney(currentSummary.income)} in income against ${formatMoney(currentSummary.expenses)} in expenses.`
        : `Your current cash flow is negative, with ${formatMoney(currentSummary.expenses)} in expenses against ${formatMoney(currentSummary.income)} in income.`;

    insights.push({
      id: "financial-health",
      title: `Financial health is ${netDirection}`,
      category: "Financial health",
      priority: healthPriority,
      explanation: healthExplanation,
      metric: `Net cash flow: ${formatMoney(currentSummary.net)}`,
      whyThisMatters: "Cash flow is the clearest signal of whether the business can cover operating costs and growth without strain.",
      recommendedAction:
        currentSummary.net >= 0
          ? "Keep an eye on the expense mix and protect the margin by paying down flexible costs where possible."
          : "Review recurring or discretionary spending immediately and decide which expenses can be deferred or reduced.",
      details: {
        previousPeriod: previousSummary.net,
        currentPeriod: currentSummary.net,
        difference: currentSummary.net - previousSummary.net,
        relevantCategories: [topExpenseCategory?.[0] ?? "General", topIncomeCategory?.[0] ?? "Income"],
        transactions: getTransactionsForInsight(currentWindow),
      },
    });
  }

  if (currentSummary.income > 0) {
    const incomeDelta = calculatePercentChange(currentSummary.income, previousSummary.income);
    const incomeTitle = incomeDelta >= 0 ? "Income is growing" : "Income is down";
    insights.push({
      id: "income-trend",
      title: incomeTitle,
      category: "Income trends",
      priority: buildPriority(incomeDelta),
      explanation:
        incomeDelta >= 0
          ? `This month’s income is ${formatPercent(incomeDelta)} higher than the previous period.`
          : `This month’s income is ${formatPercent(incomeDelta)} lower than the previous period.`,
      metric: `${formatMoney(currentSummary.income)} vs ${formatMoney(previousSummary.income)}`,
      whyThisMatters: "A sustained change in revenue affects your ability to cover costs, invest, and maintain planned growth.",
      recommendedAction:
        incomeDelta >= 0
          ? "Continue the strongest income channels and protect the conversion or sales mix that is producing the gain."
          : "Review recent sales volume, customer concentration, and late payment issues to determine the cause of the decline.",
      details: {
        previousPeriod: previousSummary.income,
        currentPeriod: currentSummary.income,
        difference: currentSummary.income - previousSummary.income,
        relevantCategories: [topIncomeCategory?.[0] ?? "Income"],
        transactions: getTransactionsForInsight(currentWindow, "Income"),
      },
    });
  }

  if (currentSummary.expenses > 0) {
    const expenseDelta = calculatePercentChange(currentSummary.expenses, previousSummary.expenses);
    insights.push({
      id: "expense-trend",
      title: expenseDelta >= 0 ? "Expenses are increasing" : "Expenses are easing",
      category: "Expense trends",
      priority: buildPriority(expenseDelta),
      explanation:
        expenseDelta >= 0
          ? `Your expenses increased ${formatPercent(expenseDelta)} compared with the previous period.`
          : `Your expenses decreased ${formatPercent(Math.abs(expenseDelta))} compared with the previous period.`,
      metric: `${formatMoney(currentSummary.expenses)} vs ${formatMoney(previousSummary.expenses)}`,
      whyThisMatters: "Spending is one of the fastest levers on profit, especially when revenue is flat or declining.",
      recommendedAction:
        expenseDelta >= 0
          ? `Review ${topExpenseCategory?.[0] ?? "your largest cost category"} and check whether the growth is strategic or discretionary.`
          : "Keep the gains and look for the recurring categories that contributed to the reduction.",
      details: {
        previousPeriod: previousSummary.expenses,
        currentPeriod: currentSummary.expenses,
        difference: currentSummary.expenses - previousSummary.expenses,
        relevantCategories: [topExpenseCategory?.[0] ?? "Other"],
        transactions: getTransactionsForInsight(currentWindow, "Expense"),
      },
    });
  }

  if (businessIncome > 0 || businessExpenses > 0) {
    const businessNet = businessIncome - businessExpenses;
    const businessPriority = businessNet >= 0 ? "POSITIVE" : "IMPORTANT";
    insights.push({
      id: "business-performance",
      title: businessNet >= 0 ? "Business performance is positive" : "Business performance needs attention",
      category: "Business performance",
      priority: businessPriority,
      explanation: `Business income is ${formatMoney(businessIncome)} and business expenses are ${formatMoney(businessExpenses)}, leaving a business net of ${formatMoney(businessNet)}.`,
      metric: `Business net: ${formatMoney(businessNet)}`,
      whyThisMatters: "This is the clearest view of whether your core operating activity is covering its cost base and supporting growth.",
      recommendedAction: "Keep the margin visible in the monthly review and check whether high-cost categories are producing proportional returns.",
      details: {
        previousPeriod: previousSummary.income - previousSummary.expenses,
        currentPeriod: currentSummary.net,
        difference: currentSummary.net - (previousSummary.income - previousSummary.expenses),
        relevantCategories: Array.from(new Set(currentWindow.filter((entry) => entry.moneyType === "Business").map((entry) => entry.category))).slice(0, 4),
        transactions: getTransactionsForInsight(currentWindow.filter((entry) => entry.moneyType === "Business")).slice(0, 5),
      },
    });
  }

  if (largestPersonalCategory) {
    insights.push({
      id: "personal-spending",
      title: `${largestPersonalCategory[0]} is your largest personal expense category`,
      category: "Personal spending",
      priority: "IMPORTANT",
      explanation: `${largestPersonalCategory[0]} accounts for ${formatMoney(largestPersonalCategory[1])} in current personal expenses.`,
      metric: `${formatMoney(largestPersonalCategory[1])}`,
      whyThisMatters: "Large personal spending categories can quietly distort your monthly cash picture if they are not clearly separated from business activity.",
      recommendedAction: "Review whether this category is recurring and whether any items should be reclassified or reduced to preserve stronger personal cash flow.",
      details: {
        previousPeriod: previousWindow.filter((entry) => entry.type === "Expense" && entry.moneyType === "Personal" && entry.category === largestPersonalCategory[0]).reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0),
        currentPeriod: largestPersonalCategory[1],
        difference: largestPersonalCategory[1] - previousWindow.filter((entry) => entry.type === "Expense" && entry.moneyType === "Personal" && entry.category === largestPersonalCategory[0]).reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0),
        relevantCategories: [largestPersonalCategory[0]],
        transactions: getTransactionsForInsight(currentWindow.filter((entry) => entry.type === "Expense" && entry.moneyType === "Personal" && entry.category === largestPersonalCategory[0]), "Expense", largestPersonalCategory[0]),
      },
    });
  }

  if (unusualExpense.length > 0) {
    const anomaly = unusualExpense[0];
    insights.push({
      id: "anomaly",
      title: "Possible anomaly",
      category: "Anomaly detection",
      priority: "WATCH",
      explanation: `One expense is significantly larger than the recent average: ${anomaly.description} for ${formatMoney(Number(anomaly.amount ?? 0))}.`,
      metric: `${formatMoney(Number(anomaly.amount ?? 0))}`,
      whyThisMatters: "Large outliers can signal timing changes, unusual purchases, or a need to confirm that the transaction belongs in the current category.",
      recommendedAction: "Inspect the underlying transaction and confirm the date, category, and classification before relying on this as a normalized expense trend.",
      details: {
        previousPeriod: averageExpense,
        currentPeriod: Number(anomaly.amount ?? 0),
        difference: Number(anomaly.amount ?? 0) - averageExpense,
        relevantCategories: [anomaly.category],
        transactions: [{
          id: anomaly.id,
          date: anomaly.date,
          description: anomaly.description,
          category: anomaly.category,
          amount: Number(anomaly.amount ?? 0),
          moneyType: anomaly.moneyType,
        }],
      },
    });
  }

  if (options.includeGoals) {
    const businessNetCurrent = businessIncome - businessExpenses;
    const businessGoalPotential = businessIncome > 0 ? Math.min(100, (businessNetCurrent / Math.max(businessIncome, 1)) * 100) : 0;
    insights.push({
      id: "goal-coverage",
      title: "Goal coverage is being tracked",
      category: "Goals",
      priority: businessGoalPotential > 40 ? "POSITIVE" : "IMPORTANT",
      explanation: `Current business net cash flow is ${formatMoney(businessNetCurrent)} against the current goal pace in your operating data.`,
      metric: `${Math.round(Math.max(0, businessGoalPotential))}% of current business flow`,
      whyThisMatters: "Goal pacing matters because it shows whether the business is operating at the rate needed to meet its targets.",
      recommendedAction: "Use this as a signal to compare the current pace against your target dates and consider changing spending or sales mix where required.",
      details: {
        previousPeriod: previousSummary.net,
        currentPeriod: businessNetCurrent,
        difference: businessNetCurrent - previousSummary.net,
        relevantCategories: Array.from(new Set(currentWindow.filter((entry) => entry.moneyType === "Business").map((entry) => entry.category))).slice(0, 4),
        transactions: getTransactionsForInsight(currentWindow.filter((entry) => entry.moneyType === "Business"), "Expense").slice(0, 3),
      },
    });
  }

  const topInsights = insights.slice(0, 6);

  const questionPrompt = (options.askFabbyPrompt ?? "How am I doing financially?").trim();
  const insightSummary = topInsights
    .slice(0, 3)
    .map((item) => `${item.title}: ${item.explanation}`)
    .join(" ");

  const aiAnswer = questionPrompt
    ? `Based on your current ledger, ${insightSummary || "I don't have enough data yet to make a reliable comparison."}`
    : "I don't have enough financial history to make a reliable comparison yet.";

  return {
    insights: topInsights,
    aiAnswer,
    hasEnoughData: true,
    totalIncome: currentSummary.income,
    totalExpenses: currentSummary.expenses,
    netCashFlow: currentSummary.net,
    largestExpenseCategory: topExpenseCategory?.[0] ?? null,
  };
}
