export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[];

export type Database = {
  __InternalSupabase: {
    PostgrestVersion: "12";
  };
  public: {
    Tables: {
      profiles: {
        Row: {
          avatar_url: string | null;
          created_at: string;
          email: string | null;
          full_name: string | null;
          id: string;
          updated_at: string;
        };
        Insert: {
          avatar_url?: string | null;
          created_at?: string;
          email?: string | null;
          full_name?: string | null;
          id: string;
          updated_at?: string;
        };
        Update: {
          avatar_url?: string | null;
          created_at?: string;
          email?: string | null;
          full_name?: string | null;
          id?: string;
          updated_at?: string;
        };
        Relationships: [];
      };
      transactions: {
        Row: {
          amount: number;
          category: string;
          created_at: string;
          date: string;
          description: string;
          id: string;
          money_type: "Business" | "Personal" | "Unclassified";
          notes: string;
          status: string;
          type: "Income" | "Expense";
          updated_at: string;
          user_id: string;
        };
        Insert: {
          amount?: number;
          category?: string;
          created_at?: string;
          date: string;
          description?: string;
          id?: string;
          money_type?: "Business" | "Personal" | "Unclassified";
          notes?: string;
          status?: string;
          type: "Income" | "Expense";
          updated_at?: string;
          user_id?: string;
        };
        Update: {
          amount?: number;
          category?: string;
          created_at?: string;
          date?: string;
          description?: string;
          id?: string;
          money_type?: "Business" | "Personal" | "Unclassified";
          notes?: string;
          status?: string;
          type?: "Income" | "Expense";
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      invoices: {
        Row: {
          amount: number;
          created_at: string;
          customer: string;
          due_date: string;
          id: string;
          status: "Paid" | "Unpaid" | "Overdue";
          updated_at: string;
          user_id: string;
        };
        Insert: {
          amount?: number;
          created_at?: string;
          customer?: string;
          due_date: string;
          id?: string;
          status?: "Paid" | "Unpaid" | "Overdue";
          updated_at?: string;
          user_id?: string;
        };
        Update: {
          amount?: number;
          created_at?: string;
          customer?: string;
          due_date?: string;
          id?: string;
          status?: "Paid" | "Unpaid" | "Overdue";
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      goals: {
        Row: {
          category: string;
          created_at: string;
          current_amount: number;
          description: string;
          id: string;
          name: string;
          status: "On Track" | "Behind" | "Ahead" | "Completed" | "At Risk";
          target_amount: number;
          target_date: string | null;
          updated_at: string;
          user_id: string;
        };
        Insert: {
          category?: string;
          created_at?: string;
          current_amount?: number;
          description?: string;
          id?: string;
          name?: string;
          status?: "On Track" | "Behind" | "Ahead" | "Completed" | "At Risk";
          target_amount?: number;
          target_date?: string | null;
          updated_at?: string;
          user_id?: string;
        };
        Update: {
          category?: string;
          created_at?: string;
          current_amount?: number;
          description?: string;
          id?: string;
          name?: string;
          status?: "On Track" | "Behind" | "Ahead" | "Completed" | "At Risk";
          target_amount?: number;
          target_date?: string | null;
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      goal_contributions: {
        Row: {
          amount: number;
          contribution_date: string;
          created_at: string;
          goal_id: string;
          id: string;
          note: string;
          source: string;
          updated_at: string;
          user_id: string;
        };
        Insert: {
          amount?: number;
          contribution_date?: string;
          created_at?: string;
          goal_id: string;
          id?: string;
          note?: string;
          source?: string;
          updated_at?: string;
          user_id?: string;
        };
        Update: {
          amount?: number;
          contribution_date?: string;
          created_at?: string;
          goal_id?: string;
          id?: string;
          note?: string;
          source?: string;
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [];
      };
      user_settings: {
        Row: {
          ai_enabled: boolean;
          created_at: string;
          currency: string;
          email_notifications: boolean;
          id: string;
          language: string;
          notifications_enabled: boolean;
          theme: string;
          timezone: string;
          updated_at: string;
          user_id: string;
        };
        Insert: {
          ai_enabled?: boolean;
          created_at?: string;
          currency?: string;
          email_notifications?: boolean;
          id?: string;
          language?: string;
          notifications_enabled?: boolean;
          theme?: string;
          timezone?: string;
          updated_at?: string;
          user_id?: string;
        };
        Update: {
          ai_enabled?: boolean;
          created_at?: string;
          currency?: string;
          email_notifications?: boolean;
          id?: string;
          language?: string;
          notifications_enabled?: boolean;
          theme?: string;
          timezone?: string;
          updated_at?: string;
          user_id?: string;
        };
        Relationships: [];
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
  };
};
