export type MoneyType = "Business" | "Personal" | "Unclassified";
export type LedgerType = "Income" | "Expense";

export type LedgerEntry = {
  id: string;
  userId: string;
  type: LedgerType;
  amount: number;
  category: string;
  date: string;
  description: string;
  customer?: string;
  vendor?: string;
  paymentMethod?: string;
  notes?: string;
  reference?: string;
  status?: string;
  moneyType: MoneyType;
  split?: {
    business: number;
    personal: number;
  };
  createdAt: string;
  updatedAt: string;
};

const STORAGE_KEY = "fabby-financial-ledger";
const LEGACY_KEYS: string[] = [
  "fabby-ledger-transactions",
  "fabby-income-records",
  "fabby-expense-records",
  "fabby-transactions",
];

export function getCurrentUserId() {
  if (typeof window === "undefined") return "local-user";
  // TODO: Get user ID from Supabase Auth when available
  return "local-user";
}

export function normalizeMoneyType(value: unknown): MoneyType {
  if (value === "Business" || value === "Personal") return value;
  return "Unclassified";
}

export function getStoredLedgerEntries(userId?: string): LedgerEntry[] {
  if (typeof window === "undefined") return [];

  const targetUserId = userId ?? getCurrentUserId();
  const entries: LedgerEntry[] = [];

  try {
    const ledgerRaw = window.localStorage.getItem(STORAGE_KEY);
    if (ledgerRaw) {
      const ledger = JSON.parse(ledgerRaw) as Record<string, LedgerEntry[]>;
      const grouped = Array.isArray(ledger[targetUserId]) ? ledger[targetUserId] : [];
      for (const item of grouped) {
        if (item && typeof item === "object") {
          entries.push({
            ...item,
            userId: item.userId ?? targetUserId,
            moneyType: normalizeMoneyType(item.moneyType),
            amount: Number(item.amount ?? 0),
            split: item.split ?? undefined,
          });
        }
      }
    }
  } catch {
    // ignore malformed state and fall back to legacy keys below
  }

  for (const key of LEGACY_KEYS) {
    try {
      const raw = window.localStorage.getItem(key);
      if (!raw) continue;
      const parsed = JSON.parse(raw);

      if (key === "fabby-income-records") {
        const grouped = parsed as Record<string, Array<Record<string, unknown>>> | Array<Record<string, unknown>>;
        const records = Array.isArray(grouped) ? grouped : grouped[targetUserId] ?? [];
        for (const record of records) {
          if (!record || typeof record !== "object") continue;
          entries.push({
            id: String(record.id ?? crypto.randomUUID()),
            userId: String(record.userId ?? targetUserId),
            type: "Income",
            amount: Number(record.amount ?? 0),
            category: String(record.category ?? "Other income"),
            date: String(record.date ?? new Date().toISOString().slice(0, 10)),
            description: String(record.description ?? "Income"),
            customer: String(record.customer ?? "Customer"),
            paymentMethod: String(record.paymentMethod ?? "Bank transfer"),
            notes: String(record.notes ?? ""),
            reference: String(record.reference ?? ""),
            status: String(record.status ?? "Received"),
            moneyType: normalizeMoneyType(record.moneyType),
            createdAt: String(record.createdAt ?? new Date().toISOString()),
            updatedAt: String(record.updatedAt ?? new Date().toISOString()),
          });
        }
        continue;
      }

      if (key === "fabby-expense-records") {
        const grouped = parsed as Record<string, Array<Record<string, unknown>>> | Array<Record<string, unknown>>;
        const records = Array.isArray(grouped) ? grouped : grouped[targetUserId] ?? [];
        for (const record of records) {
          if (!record || typeof record !== "object") continue;
          entries.push({
            id: String(record.id ?? crypto.randomUUID()),
            userId: String(record.userId ?? targetUserId),
            type: "Expense",
            amount: Number(record.amount ?? 0),
            category: String(record.category ?? "Other expense"),
            date: String(record.date ?? new Date().toISOString().slice(0, 10)),
            description: String(record.description ?? "Expense"),
            vendor: String(record.vendor ?? "Vendor"),
            paymentMethod: String(record.paymentMethod ?? "Bank transfer"),
            notes: String(record.notes ?? ""),
            reference: String(record.reference ?? ""),
            status: String(record.status ?? "Paid"),
            moneyType: normalizeMoneyType(record.moneyType),
            createdAt: String(record.createdAt ?? new Date().toISOString()),
            updatedAt: String(record.updatedAt ?? new Date().toISOString()),
          });
        }
        continue;
      }

      const values = Array.isArray(parsed) ? parsed : Object.values(parsed ?? {});
      for (const item of values) {
        if (!item || typeof item !== "object") continue;
        const record = item as Record<string, unknown>;
        const type = String(record.type ?? "Income");
        if (type !== "Income" && type !== "Expense") continue;

        entries.push({
          id: String(record.id ?? crypto.randomUUID()),
          userId: String(record.userId ?? targetUserId),
          type: type as LedgerType,
          amount: Number(record.amount ?? 0),
          category: String(record.category ?? "Other"),
          date: String(record.date ?? new Date().toISOString().slice(0, 10)),
          description: String(record.description ?? "Transaction"),
          customer: typeof record.customer === "string" ? record.customer : undefined,
          vendor: typeof record.vendor === "string" ? record.vendor : undefined,
          paymentMethod: typeof record.paymentMethod === "string" ? record.paymentMethod : undefined,
          notes: typeof record.notes === "string" ? record.notes : undefined,
          reference: typeof record.reference === "string" ? record.reference : undefined,
          status: typeof record.status === "string" ? record.status : undefined,
          moneyType: normalizeMoneyType(record.moneyType),
          createdAt: String(record.createdAt ?? new Date().toISOString()),
          updatedAt: String(record.updatedAt ?? new Date().toISOString()),
        });
      }
    } catch {
      // ignore malformed legacy data
    }
  }

  const deduped = new Map<string, LedgerEntry>();
  for (const entry of entries) {
    deduped.set(`${entry.userId}-${entry.type}-${entry.id}`, entry);
  }

  return Array.from(deduped.values()).filter((entry) => entry.userId === targetUserId || !entry.userId);
}

export function persistLedgerEntries(entries: LedgerEntry[], userId?: string) {
  if (typeof window === "undefined") return;

  const targetUserId = userId ?? getCurrentUserId();
  const raw = window.localStorage.getItem(STORAGE_KEY);
  const all: Record<string, LedgerEntry[]> = raw ? JSON.parse(raw) : {};
  all[targetUserId] = entries;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

export function getMoneySummary(entries: LedgerEntry[], filter?: MoneyType) {
  const filtered = filter ? entries.filter((entry) => entry.moneyType === filter) : entries;

  const businessIncome = filtered
    .filter((entry) => entry.type === "Income" && entry.moneyType === "Business")
    .reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0);
  const businessExpenses = filtered
    .filter((entry) => entry.type === "Expense" && entry.moneyType === "Business")
    .reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0);
  const personalIncome = filtered
    .filter((entry) => entry.type === "Income" && entry.moneyType === "Personal")
    .reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0);
  const personalExpenses = filtered
    .filter((entry) => entry.type === "Expense" && entry.moneyType === "Personal")
    .reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0);
  const unclassified = filtered.filter((entry) => entry.moneyType === "Unclassified");

  return {
    businessIncome,
    businessExpenses,
    personalIncome,
    personalExpenses,
    businessNet: businessIncome - businessExpenses,
    personalNet: personalIncome - personalExpenses,
    unclassified,
    totalIncome: filtered.filter((entry) => entry.type === "Income").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0),
    totalExpenses: filtered.filter((entry) => entry.type === "Expense").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0),
    totalNet: filtered.filter((entry) => entry.type === "Income").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0) - filtered.filter((entry) => entry.type === "Expense").reduce((sum, entry) => sum + Number(entry.amount ?? 0), 0),
  };
}

export function getPotentialMixingWarnings(entries: LedgerEntry[]) {
  const warnings: { id: string; title: string; detail: string; severity: "warning" | "review" }[] = [];

  const personalKeywords = ["grocery", "groceries", "rent", "movie", "shopping", "family", "personal", "home", "school", "car fuel"];
  const businessKeywords = ["invoice", "client", "software", "ads", "marketing", "inventory", "supplier", "travel", "salary", "hosting"];

  for (const entry of entries) {
    const text = `${entry.description} ${entry.category} ${entry.vendor ?? ""} ${entry.customer ?? ""}`.toLowerCase();
    const hasBusinessKeyword = businessKeywords.some((keyword) => text.includes(keyword));
    const hasPersonalKeyword = personalKeywords.some((keyword) => text.includes(keyword));

    if (entry.moneyType === "Business" && hasPersonalKeyword && !hasBusinessKeyword) {
      warnings.push({
        id: entry.id,
        title: "Possible classification issue",
        detail: `"${entry.description}" looks personal to FABBY, but it is marked as Business. Review the transaction to make sure it is not being mixed with personal spending.`,
        severity: "review",
      });
    }

    if (entry.moneyType === "Personal" && hasBusinessKeyword && !hasPersonalKeyword) {
      warnings.push({
        id: entry.id,
        title: "Possible classification issue",
        detail: `"${entry.description}" has business-like indicators, but it is marked as Personal. This may be a misclassified business purchase or a mixed transaction.`,
        severity: "warning",
      });
    }
  }

  return warnings.slice(0, 6);
}

export function getMoneyTypeSuggestions(entry: Partial<LedgerEntry>) {
  const text = `${entry.description ?? ""} ${entry.category ?? ""} ${entry.vendor ?? ""} ${entry.customer ?? ""}`.toLowerCase();

  const personalKeywords = ["grocery", "groceries", "home", "rent", "family", "movie", "shopping", "personal", "school"];
  const businessKeywords = ["client", "software", "invoice", "marketing", "ad", "inventory", "supplier", "travel", "hosting", "contractor", "website", "subscription"];

  const businessScore = businessKeywords.filter((keyword) => text.includes(keyword)).length;
  const personalScore = personalKeywords.filter((keyword) => text.includes(keyword)).length;

  if (businessScore > personalScore) return "Business" as const;
  if (personalScore > businessScore) return "Personal" as const;
  return "Unclassified" as const;
}
