import { createBrowserClient } from "@/lib/supabase/client";
import type { AuthChangeEvent, Session } from "@supabase/supabase-js";

export type AuthUser = {
  id: string;
  email: string;
  fullName?: string;
  avatar?: string;
  createdAt: string;
};

export type AuthSession = {
  user: AuthUser;
  accessToken: string;
  refreshToken?: string;
};

/**
 * Check if Supabase is properly configured
 */
export function isSupabaseConfigured() {
  return Boolean(
    process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,
  );
}

/**
 * Sign up a new user with email and password
 * Creates a new Supabase Auth user and profile
 */
export async function signUpWithEmail({
  email,
  password,
  fullName,
}: {
  email: string;
  password: string;
  fullName: string;
}) {
  if (!isSupabaseConfigured()) {
    throw new Error("Authentication is not configured.");
  }

  const supabase = createBrowserClient();

  // Validate inputs
  const normalizedEmail = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
    throw new Error("Please enter a valid email address.");
  }

  if (password.length < 8) {
    throw new Error("Password must be at least 8 characters long.");
  }

  if (!fullName.trim()) {
    throw new Error("Full name is required.");
  }

  const { data, error } = await supabase.auth.signUp({
    email: normalizedEmail,
    password,
    options: {
      data: {
        full_name: fullName,
      },
      emailRedirectTo: `${getBaseUrl()}/auth/callback`,
    },
  });

  if (error) {
    if (error.message.includes("already registered")) {
      throw new Error("An account with this email already exists. Please sign in instead.");
    }
    throw new Error(error.message || "Failed to create account. Please try again.");
  }

  if (!data.user) {
    throw new Error("Failed to create account. Please try again.");
  }

  if (typeof window !== "undefined" && data.session) {
    window.dispatchEvent(
      new CustomEvent("fabby-auth-state", {
        detail: { session: data.session },
      }),
    );
  }

  // Create user profile
  try {
    const profileRecord = {
      id: data.user.id,
      full_name: fullName,
      email: normalizedEmail,
      avatar_url: null,
    };

    const { error: profileError } = await supabase.from("profiles").insert([profileRecord]);

    if (profileError && profileError.code !== "23505") {
      // 23505 is unique violation - profile may already exist
      console.error("Profile creation error:", profileError);
    }
  } catch (err) {
    console.error("Failed to create profile:", err);
    // Continue anyway - profile creation is not blocking
  }

  return {
    user: data.user,
    session: data.session,
    requiresEmailConfirmation: !data.session, // If no session returned, email confirmation required
  };
}

/**
 * Sign in with email and password
 * Returns the authenticated session
 */
export async function signInWithEmail(email: string, password: string) {
  if (!isSupabaseConfigured()) {
    throw new Error("Authentication is not configured.");
  }

  const supabase = createBrowserClient();

  // Validate inputs
  const normalizedEmail = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
    throw new Error("Please enter a valid email address.");
  }

  if (!password.trim()) {
    throw new Error("Password is required.");
  }

  const { data, error } = await supabase.auth.signInWithPassword({
    email: normalizedEmail,
    password,
  });

  if (error) {
    if (error.message.includes("Invalid login credentials")) {
      throw new Error("Invalid email or password. Please try again.");
    }
    throw new Error(error.message || "Failed to sign in. Please try again.");
  }

  if (!data.session || !data.user) {
    throw new Error("Failed to sign in. Please try again.");
  }

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("fabby-auth-state", {
        detail: { session: data.session },
      }),
    );
  }

  return { user: data.user, session: data.session };
}

/**
 * Sign out the current user
 */
export async function signOut() {
  if (!isSupabaseConfigured()) {
    return;
  }

  const supabase = createBrowserClient();

  const { error } = await supabase.auth.signOut();

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("fabby-auth-state", { detail: { session: null } }));
  }

  if (error) {
    console.error("Sign out error:", error);
    // Still clear localStorage even if sign out fails
  }
}

/**
 * Get the current authenticated user (client-side)
 */
export async function getCurrentUser() {
  if (!isSupabaseConfigured()) {
    return null;
  }

  const supabase = createBrowserClient();

  const { data, error } = await supabase.auth.getUser();

  if (error || !data.user) {
    return null;
  }

  return data.user;
}

/**
 * Get the current session (client-side)
 */
export async function getCurrentSession() {
  if (!isSupabaseConfigured()) {
    return null;
  }

  const supabase = createBrowserClient();

  const { data, error } = await supabase.auth.getSession();

  if (error || !data.session) {
    return null;
  }

  return data.session;
}

/**
 * Send a password reset email
 */
export async function resetPasswordForEmail(email: string) {
  if (!isSupabaseConfigured()) {
    throw new Error("Authentication is not configured.");
  }

  const supabase = createBrowserClient();

  const normalizedEmail = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalizedEmail)) {
    throw new Error("Please enter a valid email address.");
  }

  const { error } = await supabase.auth.resetPasswordForEmail(normalizedEmail, {
    redirectTo: `${getBaseUrl()}/auth/callback?type=recovery`,
  });

  if (error) {
    throw new Error(error.message || "Failed to send password reset email. Please try again.");
  }

  // Supabase doesn't throw an error if email doesn't exist (for security)
  // This is intentional - don't reveal whether an email exists
}

/**
 * Update the user's password with a token from password reset
 */
export async function updatePassword(password: string) {
  if (!isSupabaseConfigured()) {
    throw new Error("Authentication is not configured.");
  }

  const supabase = createBrowserClient();

  if (password.length < 8) {
    throw new Error("Password must be at least 8 characters long.");
  }

  const { error } = await supabase!.auth.updateUser({
    password,
  });

  if (error) {
    throw new Error(error.message || "Failed to update password. Please try again.");
  }
}

/**
 * Refresh the session
 */
export async function refreshSession() {
  if (!isSupabaseConfigured()) {
    return null;
  }

  const supabase = createBrowserClient();

  const { data, error } = await supabase!.auth.refreshSession();

  if (error || !data.session) {
    return null;
  }

  return data.session;
}

/**
 * Get the base URL for auth redirects
 */
function getBaseUrl() {
  if (typeof window !== "undefined") {
    return window.location.origin;
  }

  if (process.env.NEXT_PUBLIC_APP_URL) {
    return process.env.NEXT_PUBLIC_APP_URL;
  }

  return "http://localhost:3000";
}

/**
 * Subscribe to auth state changes
 */
export function onAuthStateChange(
  callback: (event: AuthChangeEvent, session: Session | null) => void,
): (() => void) | null {
  if (!isSupabaseConfigured()) {
    return null;
  }

  const supabase = createBrowserClient();

  const { data } = supabase.auth.onAuthStateChange((event: AuthChangeEvent, session: Session | null) => {
    callback(event, session);
  });

  return () => {
    data?.subscription.unsubscribe();
  };
}
