import { createBrowserClient } from "@/lib/supabase/client";
import type { Database } from "@/lib/supabase/database.types";

export type ThemeMode = "light" | "dark" | "system";
export type DefaultTransactionType = "Income" | "Expense";
export type DefaultClassification = "Business" | "Personal" | "Ask every time";
export type NotificationFrequency = "Immediate" | "Daily" | "Weekly" | "Monthly" | "Off";

export type LearnedPreference = {
  id: string;
  phrase: string;
  category: string;
  classification: "Business" | "Personal" | "Needs Review";
  enabled: boolean;
  approved: boolean;
  createdAt: string;
};

export type SettingsState = {
  profile: {
    name: string;
    email: string;
    businessName: string;
    phone: string;
    country: string;
    currency: string;
    timezone: string;
  };
  financial: {
    defaultCurrency: string;
    defaultTransactionType: DefaultTransactionType;
    defaultClassification: DefaultClassification;
    defaultExpenseCategory: string;
    defaultIncomeCategory: string;
    startOfFinancialYear: string;
    dateFormat: string;
    numberFormat: string;
  };
  businessVsPersonal: {
    trackPersonalExpenses: boolean;
    defaultClassification: DefaultClassification;
  };
  ai: {
    confirmationBeforeSave: boolean;
    expenseCategorization: boolean;
    incomeCategorization: boolean;
    financialInsights: boolean;
    cashFlowAnalysis: boolean;
    anomalyDetection: boolean;
    receiptAnalysis: boolean;
    proactiveRecommendations: boolean;
    learnFromCorrections: boolean;
  };
  notifications: {
    cashFlowAlerts: NotificationFrequency;
    spendingAlerts: NotificationFrequency;
    goalReminders: NotificationFrequency;
    unusualTransactionAlerts: NotificationFrequency;
    aiInsights: NotificationFrequency;
    reportReminders: NotificationFrequency;
    weeklyFinancialSummary: NotificationFrequency;
    monthlyFinancialSummary: NotificationFrequency;
  };
  reporting: {
    defaultReportPeriod: string;
    defaultReportCurrency: string;
    includeBusinessData: boolean;
    includePersonalData: boolean;
    defaultReportType: string;
  };
  privacy: {
    aiDataUsage: boolean;
    financialDataAnalysis: boolean;
    aiLearning: boolean;
    analyticsPreferences: boolean;
  };
  appearance: {
    theme: ThemeMode;
    primaryColor: string;
    secondaryColor: string;
  };
  integrations: {
    apiKey: string;
    webhookUrl: string;
    connectedServices: {
      slack: boolean;
      email: boolean;
      stripe: boolean;
      xero: boolean;
      quickbooks: boolean;
    };
  };
  learnedPreferences: LearnedPreference[];
};

export const defaultSettings: SettingsState = {
  profile: {
    name: "",
    email: "",
    businessName: "",
    phone: "",
    country: "Nigeria",
    currency: "NGN",
    timezone: "Africa/Lagos",
  },
  financial: {
    defaultCurrency: "NGN",
    defaultTransactionType: "Expense",
    defaultClassification: "Business",
    defaultExpenseCategory: "Software",
    defaultIncomeCategory: "Services",
    startOfFinancialYear: "2026-01-01",
    dateFormat: "DD/MM/YYYY",
    numberFormat: "1,234.56",
  },
  businessVsPersonal: {
    trackPersonalExpenses: true,
    defaultClassification: "Business",
  },
  ai: {
    confirmationBeforeSave: true,
    expenseCategorization: true,
    incomeCategorization: true,
    financialInsights: true,
    cashFlowAnalysis: true,
    anomalyDetection: true,
    receiptAnalysis: false,
    proactiveRecommendations: true,
    learnFromCorrections: true,
  },
  notifications: {
    cashFlowAlerts: "Immediate",
    spendingAlerts: "Daily",
    goalReminders: "Weekly",
    unusualTransactionAlerts: "Immediate",
    aiInsights: "Weekly",
    reportReminders: "Monthly",
    weeklyFinancialSummary: "Weekly",
    monthlyFinancialSummary: "Monthly",
  },
  reporting: {
    defaultReportPeriod: "month",
    defaultReportCurrency: "NGN",
    includeBusinessData: true,
    includePersonalData: true,
    defaultReportType: "profit-loss",
  },
  privacy: {
    aiDataUsage: true,
    financialDataAnalysis: true,
    aiLearning: true,
    analyticsPreferences: false,
  },
  appearance: {
    theme: "light",
    primaryColor: "#FFFFFF",
    secondaryColor: "#0F172A",
  },
  integrations: {
    apiKey: "",
    webhookUrl: "",
    connectedServices: {
      slack: false,
      email: true,
      stripe: false,
      xero: false,
      quickbooks: false,
    },
  },
  learnedPreferences: [
    {
      id: "lp-1",
      phrase: "Fuel for delivery van",
      category: "Transportation",
      classification: "Business",
      enabled: true,
      approved: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: "lp-2",
      phrase: "Client lunch",
      category: "Food",
      classification: "Needs Review",
      enabled: true,
      approved: true,
      createdAt: new Date().toISOString(),
    },
    {
      id: "lp-3",
      phrase: "Website hosting",
      category: "Software",
      classification: "Business",
      enabled: true,
      approved: true,
      createdAt: new Date().toISOString(),
    },
  ],
};

function mergeSettings(base: SettingsState, incoming?: Partial<SettingsState>): SettingsState {
  return {
    ...base,
    ...incoming,
    profile: { ...base.profile, ...incoming?.profile },
    financial: { ...base.financial, ...incoming?.financial },
    businessVsPersonal: { ...base.businessVsPersonal, ...incoming?.businessVsPersonal },
    ai: { ...base.ai, ...incoming?.ai },
    notifications: { ...base.notifications, ...incoming?.notifications },
    reporting: { ...base.reporting, ...incoming?.reporting },
    privacy: { ...base.privacy, ...incoming?.privacy },
    appearance: { ...base.appearance, ...incoming?.appearance },
    integrations: {
      ...base.integrations,
      ...incoming?.integrations,
      connectedServices: { ...base.integrations.connectedServices, ...incoming?.integrations?.connectedServices },
    },
    learnedPreferences: incoming?.learnedPreferences ?? base.learnedPreferences,
  };
}

const SETTINGS_KEY = "fabby-user-settings";

function ensureUserSettings(userId?: string): SettingsState {
  if (typeof window === "undefined") return defaultSettings;

  const currentUserId = userId ?? "local-user";
  const raw = window.localStorage.getItem(SETTINGS_KEY);
  const all = raw ? (JSON.parse(raw) as Record<string, Partial<SettingsState>>) : {};

  if (!all[currentUserId]) {
    all[currentUserId] = defaultSettings;
    window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(all));
  }

  return mergeSettings(defaultSettings, all[currentUserId]);
}

export function readSettings(userId?: string): SettingsState {
  if (typeof window === "undefined") return defaultSettings;
  return ensureUserSettings(userId);
}

export function saveSettings(nextSettings: SettingsState, userId?: string): SettingsState {
  if (typeof window === "undefined") return nextSettings;

  const currentUserId = userId ?? "local-user";
  const raw = window.localStorage.getItem(SETTINGS_KEY);
  const all = raw ? (JSON.parse(raw) as Record<string, SettingsState>) : {};
  all[currentUserId] = mergeSettings(defaultSettings, nextSettings);
  window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(all));
  return all[currentUserId];
}

export async function fetchSettings(userId?: string): Promise<SettingsState> {
  if (!userId) {
    return readSettings();
  }

  const supabase = createBrowserClient();
  const { data, error } = await supabase.from("user_settings").select("*").eq("user_id", userId).maybeSingle();

  if (error) {
    console.error("Failed to read user settings:", error);
    return readSettings(userId);
  }

  const next = data ? mergeSettings(defaultSettings, {
    profile: {
      ...defaultSettings.profile,
      currency: data.currency || defaultSettings.profile.currency,
      timezone: data.timezone || defaultSettings.profile.timezone,
    },
    financial: { ...defaultSettings.financial, defaultCurrency: data.currency || defaultSettings.profile.currency },
    reporting: { ...defaultSettings.reporting, defaultReportCurrency: data.currency || defaultSettings.profile.currency },
    appearance: { ...defaultSettings.appearance, theme: (data.theme as ThemeMode) || defaultSettings.appearance.theme },
  }) : defaultSettings;

  saveSettings(next, userId);
  return next;
}

export async function persistSettings(nextSettings: SettingsState, userId?: string): Promise<SettingsState> {
  if (!userId) {
    return saveSettings(nextSettings);
  }

  const supabase = createBrowserClient();
  const payload = {
    user_id: userId,
    currency: nextSettings.profile.currency || "NGN",
    timezone: nextSettings.profile.timezone || "Africa/Lagos",
    language: "en",
    theme: nextSettings.appearance.theme || "light",
    notifications_enabled: true,
    email_notifications: true,
    ai_enabled: nextSettings.ai.confirmationBeforeSave,
    updated_at: new Date().toISOString(),
  };

  const { error } = await supabase.from("user_settings").upsert(payload, { onConflict: "user_id" });
  if (error) {
    console.error("Failed to save settings:", error);
  }

  return saveSettings(nextSettings, userId);
}

export function restoreDefaultSettings() {
  return saveSettings(defaultSettings);
}

export function applyTheme(theme: ThemeMode) {
  if (typeof document === "undefined") return;
  document.documentElement.dataset.theme = theme;
}

export function addLearnedPreference(phrase: string, category: string, classification: LearnedPreference["classification"]) {
  return { ...defaultSettings, learnedPreferences: [{ id: `lp-${Date.now()}`, phrase, category, classification, enabled: true, approved: true, createdAt: new Date().toISOString() }, ...defaultSettings.learnedPreferences] };
}

export function clearLearnedPreferences() {
  return { ...defaultSettings, learnedPreferences: [] };
}
