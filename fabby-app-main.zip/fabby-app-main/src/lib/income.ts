export type IncomeStatus = "Received" | "Pending";
export type MoneyType = "Business" | "Personal" | "Unclassified";

export type IncomeRecord = {
  id: string;
  userId: string;
  amount: number;
  category: string;
  date: string;
  customer: string;
  paymentMethod: string;
  description: string;
  notes: string;
  reference: string;
  status: IncomeStatus;
  moneyType: MoneyType;
  createdAt: string;
  updatedAt: string;
};

export const DEFAULT_INCOME_CATEGORIES = [
  "Sales",
  "Services",
  "Consulting",
  "Product revenue",
  "Subscription revenue",
  "Investment income",
  "Other income",
];

export const DEFAULT_PAYMENT_METHODS = [
  "Bank transfer",
  "Cash",
  "Card",
  "Mobile money",
  "Invoice",
  "Wallet",
  "Other",
];

const STORAGE_KEY = "fabby-income-records";

function toDateOnly(date: Date) {
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000)
    .toISOString()
    .slice(0, 10);
}

function getCurrentUserId(): string {
  if (typeof window === "undefined") return "local-user";
  // TODO: Get user ID from Supabase Auth when available
  return "local-user";
}

export function getStoredIncomeRecords(userId?: string): IncomeRecord[] {
  if (typeof window === "undefined") return [];

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    const value = raw ? (JSON.parse(raw) as Record<string, IncomeRecord[]>) : {};
    const targetUserId = userId ?? getCurrentUserId();
    const records = value[targetUserId] ?? [];
    return Array.isArray(records) ? (records as IncomeRecord[]) : [];
  } catch {
    return [];
  }
}

export function persistIncomeRecords(records: IncomeRecord[], userId?: string) {
  if (typeof window === "undefined") return;

  const targetUserId = userId ?? getCurrentUserId();
  const raw = window.localStorage.getItem(STORAGE_KEY);
  const all: Record<string, IncomeRecord[]> = raw ? JSON.parse(raw) : {};
  all[targetUserId] = records;
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(all));
}

export function createIncomeRecord(input: {
  userId: string;
  amount: number;
  category: string;
  date: string;
  customer: string;
  paymentMethod: string;
  description: string;
  notes: string;
  reference: string;
  status: IncomeStatus;
  moneyType?: MoneyType;
}): IncomeRecord {
  const now = new Date().toISOString();
  return {
    id: `income-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    userId: input.userId,
    amount: Number(input.amount),
    category: input.category.trim() || "Other income",
    date: input.date || toDateOnly(new Date()),
    customer: input.customer.trim() || "Direct customer",
    paymentMethod: input.paymentMethod.trim() || "Bank transfer",
    description: input.description.trim() || "Income received",
    notes: input.notes.trim(),
    reference: input.reference.trim(),
    status: input.status,
    moneyType: input.moneyType ?? "Unclassified",
    createdAt: now,
    updatedAt: now,
  };
}

export function calculateIncomeSummary(records: IncomeRecord[]) {
  const total = records.reduce((sum, item) => sum + item.amount, 0);
  const pending = records
    .filter((item) => item.status === "Pending")
    .reduce((sum, item) => sum + item.amount, 0);
  const count = records.length;

  const now = new Date();
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
  const startOfYear = new Date(now.getFullYear(), 0, 1);

  const monthly = records
    .filter((item) => {
      const itemDate = new Date(`${item.date}T00:00:00`);
      return itemDate >= startOfMonth;
    })
    .reduce((sum, item) => sum + item.amount, 0);

  const yearly = records
    .filter((item) => {
      const itemDate = new Date(`${item.date}T00:00:00`);
      return itemDate >= startOfYear;
    })
    .reduce((sum, item) => sum + item.amount, 0);

  const average = count > 0 ? total / count : 0;

  return {
    total,
    monthly,
    yearly,
    pending,
    average,
    count,
  };
}

export function getIncomeForPeriod(
  records: IncomeRecord[],
  period: "today" | "week" | "month" | "quarter" | "year" | "custom",
  customStart?: string,
  customEnd?: string,
) {
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  let rangeStart: Date | null = null;
  let rangeEnd: Date | null = null;

  if (period === "custom") {
    if (customStart) {
      rangeStart = new Date(`${customStart}T00:00:00`);
    }
    if (customEnd) {
      rangeEnd = new Date(`${customEnd}T23:59:59`);
    }
  } else if (period === "today") {
    rangeStart = startOfToday;
    rangeEnd = new Date(startOfToday.getTime() + 86400000 - 1);
  } else if (period === "week") {
    const day = startOfToday.getDay();
    const diff = (day === 0 ? -6 : 1 - day);
    rangeStart = new Date(startOfToday);
    rangeStart.setDate(startOfToday.getDate() + diff);
    rangeEnd = new Date(rangeStart);
    rangeEnd.setDate(rangeStart.getDate() + 6);
    rangeEnd.setHours(23, 59, 59, 999);
  } else if (period === "month") {
    rangeStart = new Date(now.getFullYear(), now.getMonth(), 1);
    rangeEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0, 23, 59, 59, 999);
  } else if (period === "quarter") {
    const quarter = Math.floor(now.getMonth() / 3);
    rangeStart = new Date(now.getFullYear(), quarter * 3, 1);
    rangeEnd = new Date(now.getFullYear(), quarter * 3 + 3, 0, 23, 59, 59, 999);
  } else if (period === "year") {
    rangeStart = new Date(now.getFullYear(), 0, 1);
    rangeEnd = new Date(now.getFullYear(), 11, 31, 23, 59, 59, 999);
  }

  if (!rangeStart && !rangeEnd) {
    return records;
  }

  return records.filter((record) => {
    const date = new Date(`${record.date}T00:00:00`);
    const matchesStart = rangeStart ? date >= rangeStart : true;
    const matchesEnd = rangeEnd ? date <= rangeEnd : true;
    return matchesStart && matchesEnd;
  });
}
